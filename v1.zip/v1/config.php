<?php

if (isset($_SESSION['LAST_ACTIVITY']) && (time() - $_SESSION['LAST_ACTIVITY'] > 18000)) {
    // last request was more than 30 minutes ago
    session_unset();     // unset $_SESSION variable for the run-time 
    session_destroy();   // destroy session data in storage
		$_SESSION = array();
		header('location:index.php');
}

$_SESSION['LAST_ACTIVITY'] = time(); // update last activity time stamp


$host = "localhost";
$user = "riptid9_myleb";
$pass = "Ver1fyN0w!";
$db = "riptid9_myleb";

$con = mysqli_connect($host,$user,$pass,$db);

?>
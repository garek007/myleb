// JavaScript Document
var monthNames = ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"];
var monthNamesFull = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
function get_one_up_layout_and_populate(block, folder) {	

	var image_url = $(block).closest('.contentarea_container').find('.imagecont').find('img').attr('src');
	var dest_url = $(block).closest('.contentarea_container').find('.headline').attr('href');
	var section_title = $.trim($(block).closest('.contentarea_container').find('.section_title').text());
	var headline = $.trim($(block).closest('.contentarea_container').find('.headline').text());
	var description = $(block).closest('.contentarea_container').find('.description').text();
	var dates = $(block).closest('.contentarea_container').find('.dates').text();
	var dates2 = $(block).closest('.contentarea_container').find('.dates2').text();
	
	$.get('layouts/one-up-image/index.php', function(data) {	
		$('#loadContent').html(data);	
		$('input[name="image_url"]').val(image_url);
		$('input[name="dest_url"]').val(dest_url);
		$('input[name="headline"]').val(headline);	
		$('input[name="section_title"]').val(section_title);
		$('textarea[name="description"]').val(description);	
		$('input[name="dates"]').val(dates);
		$('input[name="dates2"]').val(dates2);	

    });
}
function get_two_up_layout_and_populate(block, folder) {	
	var section_title = $.trim($(block).closest('.contentarea_container').find('.title').text());

	var left_url = $(block).closest('.contentarea_container').find('.imagecont.left').find('a').attr('href');
	var left_image = $(block).closest('.contentarea_container').find('.imagecont.left').find('img').attr('src');
	var left_headline = $.trim($(block).closest('.contentarea_container').find('.left_headline').text());
	var left_description = $(block).closest('.contentarea_container').find('.description.left').text();

	var right_url = $(block).closest('.contentarea_container').find('.right_headline').attr('href');
	var right_image = $(block).closest('.contentarea_container').find('.imagecont.right').find('img').attr('src');
	var right_headline = $.trim($(block).closest('.contentarea_container').find('.right_headline').text());
	var right_description = $(block).closest('.contentarea_container').find('.description.right').text();
	
	$.get('layouts/two-up-image/index.php', function(data) {	
		$('#loadContent').html(data);	

    $('input[name="section_title"]').val(section_title);
		
		$('input[name="left_image"]').val(left_image);
		$('input[name="left_url"]').val(left_url);
		$('input[name="left_headline"]').val(left_headline);	
		$('textarea[name="left_description"]').val(left_description);	
		
		$('input[name="right_url"]').val(right_url);
		$('input[name="right_image"]').val(right_image);
		$('input[name="right_headline"]').val(right_headline);
		$('textarea[name="right_description"]').val(right_description);	
    });
}
function get_540_layout_and_populate(block, folder) {	
	//var section_title = $.trim($(block).closest('.contentarea_container').find('.subheadline').text());

	var image_url = $(block).closest('.contentarea_container').find('.imagecont').find('img').attr('src');
	var headline = $.trim($(block).closest('.contentarea_container').find('.dest_url').text());	
	var description = $(block).closest('.contentarea_container').find('.description').text();
	var dest_url = $(block).closest('.contentarea_container').find('.dest_url').attr('href');
	
	$.get('layouts/'+folder+'/index.php', function(data) {	
		$('#loadContent').html(data);	

    //$('input[name="section_title"]').val(section_title);
				
		$('input[name="image_url"]').val(image_url);
		$('input[name="headline"]').val(headline);
		$('textarea[name="description"]').val(description);
		$('input[name="dest_url"]').val(dest_url);	
    });
}
function get_600_layout_and_populate(block, folder) {	

	var image_url = $(block).closest('.contentarea_container').find('.fullwidth').attr('src');
	var headline = $.trim($(block).closest('.contentarea_container').find('.dest_url').text());	
	var description = $.trim($(block).closest('.contentarea_container').find('.subheadline').text());
	var dest_url = $(block).closest('.contentarea_container').find('.dest_url').attr('href');
	
	$.get('layouts/'+folder+'/index.php', function(data) {	
		$('#loadContent').html(data);	
				
		$('input[name="image_url"]').val(image_url);
		$('input[name="headline"]').val(headline);
		$('textarea[name="description"]').val(description);
		$('input[name="dest_url"]').val(dest_url);	
    });
}
function get_events_layout_and_populate(block, folder) {	

	var headline = $.trim($(block).closest('.contentarea_container').find('.dest_url').text());	
	var description = $(block).closest('.contentarea_container').find('.subheadline').text();
	var dest_url = $(block).closest('.contentarea_container').find('.dest_url').attr('href');
	
	$.get('layouts/'+folder+'/index.php', function(data) {	
		$('#loadContent').html(data);	
				
		
		$('input[name="headline"]').val(headline);
		$('input[name="description"]').val(description);
		$('textarea[name="dest_url"]').val(dest_url);	
    });
}
function getQueryVariable(variable)
{
       var query = window.location.search.substring(1);
       var vars = query.split("&");
       for (var i=0;i<vars.length;i++) {
               var pair = vars[i].split("=");
               if(pair[0] == variable){return pair[1];}
       }
       return(false);
}
$(document).ready(function() {
    $('body').on('click','#add-ga-tags',function() {

        $('#ga-fields').slideDown({
            duration: 1000,
            easing: 'swing'
        });

    });

    $('body').on('change','#utm_campaign',function() {
        //var id = $(this).attr('id');
        var id = this.value;
        var today = new Date();
        console.log(id);

        if (id == "Top Things to Do") {
            var cname = "Top Things to Do";
            //find out 
            var todayDate = today.getDate();
            var dayOfWeek = today.getDay();
            var startDate; //this will be set to Tuesday below.
            var endDate; //this will be set to the Sunday after startDate
            switch (dayOfWeek) {
                case 0:startDate = todayDate + 2;break;
                case 1:startDate = todayDate + 1;break;
                case 2:startDate = todayDate;break;
                case 3:startDate = todayDate - 1;break;
                case 4:startDate = todayDate - 2;break;
                case 5:startDate = todayDate - 3;break;
								case 6:startDate = todayDate - 4;break;
                default:startDate = todayDate;
            }
            endDate = Number(startDate + 5);

            var source = today.getFullYear() + '_' + monthNames[today.getMonth()] + '_' + startDate + '-' + endDate;
            var headline = "TOP THINGS TO DO: " + monthNames[today.getMonth()].toUpperCase() + " " + startDate + "-" + endDate + ", " + today.getFullYear();
        } else {
            var cname = "Consumer Newsletter Monthly";
            var source = monthNames[today.getMonth()+1];
        }

				console.log(headline);
        $('#utm_campaign').val(cname);
        $('#utm_source').val(source);
				if($('input[name="headline"]').hasClass('header-600-wide')){
        	$('input[name="headline"]').val(headline);
				}

    });


    //don't forget to install jQuery UI for this one
    //$( ".draggable" ).draggable();

    //Drag n Drop Stuff
    $(document).delegate(".drop-area", 'dragenter', function(e) {
        e.preventDefault();
        $(this).css('background', '#BBD5B8');
    });
    $(document).delegate(".drop-area", 'dragover', function(e) {
        e.preventDefault();
    });

    $(document).delegate('.drop-area', 'drop', function(e) {
        $(this).css('background', '#D8F9D3');
        e.preventDefault();
        //var image = e.originalEvent.dataTransfer.files;
        //createFormData(image);

        var image = e.originalEvent.dataTransfer.files[0];
        $(this).val('http://image.updates.sandiego.org/lib/fe9e15707566017871/m/4/' + image.name);
        var formData = new FormData();
        formData.append('file', image);
       // console.log(image);
        var xhr = new XMLHttpRequest();
        xhr.open('POST', '/processUploads.php');
        xhr.onload = function() {
            if (xhr.status === 200) {
                console.log('all done: ' + xhr.status + ' ' + xhr.responseText);
								switch(xhr.responseText){
									case '100':alert("Sorry, your filename must be at least 4 characters in length.");break;
									case '200':alert("Sorry, file already exists on GoDaddy server");break;
									case '300':alert("Sorry, only JPG, JPEG, PNG & GIF files are allowed.");break;
									default:break;
									
									
								}

            } else {
                console.log('bad things happened' + xhr.status + xhr.responseText);
            }

        }
        xhr.send(formData);




    });

    $('#twitter_text').on('keyup', function() {
        var charsLeft = 120 - $(this).val().length;
        $('#charcount').text(charsLeft);
        if (charsLeft < 10) {
            $('#charcount').css({
                'color': 'red'
            });
        }
    });


    var w = $(window).width() - 200;
    var h = $(window).height() - 100;
    $('#load').dialog({
        resizable: false,
        height: h,
        width: w,
        dialogClass: 'noTitle',
        modal: true,
        autoOpen: false,
				resizable: true,
				position:{my:"left top", at:"left+20 top+20", of:window},
        close: function(event, ui) {
            $('#loadContent').empty();
						//$(this).dialog('destroy');
        }
    });
		
    $('.fullhtml').click(function(e) {
        e.preventDefault();
        folder = $(this).data('folder');//need to change this to module so it matches
        $(this).closest('.raw').addClass('active ' + folder);


        $('#loadContent').load($(this).attr('href'));
        $('#load').dialog('open');

    });		
		
		


    $('#grabTheCode').click(function() {
        var theCode = '';
        $('.contentarea_container').each(function() {
            //fullHtml += $(this).find('.contentarea').html();
            theCode += $(this).find('.contentarea').wrap('<p/>').parent().html();
            // var x = $('#container').wrap('<p/>').parent().html();
        });
					$('#loadContent').html('<textarea id="rawhtml" cols="130" rows="30" style="font-family:monospace">' + theCode + '</textarea>');
					$('.ui-dialog').addClass('grabcode');
					$('#load').dialog('open');
    });
    $('#saveproject').click(function() {

       var projectHTML = $('#container').html();
			 //var projectHTML = '';
			 //$('.filled').each(function() {
				//	 projectHTML += $(this).wrap('<p/>').parent().html();
			 //});
			 
			 
			 
				var pnum = getQueryVariable("pnum");

					$.ajax({
							type: "POST",
							dataType: "text",
							url: "saveproject.php",
							data: {mydata:projectHTML,pnum:pnum}
					}).done(function(data) {
						alert(data);
						$('.filled').each().unwrap();

					});						
    });		
		$('#pasteYourCode').click(function() {
     $('#loadContent').html('<form id="pasteCodeInput"><textarea id="pastedCode" cols="200" rows="32"></textarea><input type="submit" value="Submit"></form>');
     $('#load').dialog('open');
			
		});
    $(document).delegate('#pasteCodeInput', 'submit', function(event) {
        event.preventDefault();
						var $code = $('#pastedCode').val();
						console.log($code);
						$('#container').append($code);
            $('#load').dialog('close');
            $('#loadContent').empty();
 
    });		
		
		
    $('body').on('click', '.edit', function(e) {
        e.preventDefault();
        var module = $(this).closest('.contentarea_container').data('module');
				console.log(module);
        $(this).closest('.contentarea_container').addClass('active');
        //var folder = "layouts/" + module + "/index.php";
				folder = module;

        switch (module) {
            //if 540 then
            case "header-540-wide":
								get_540_layout_and_populate(this, module);
                break;
            case "header-600-wide":
								get_600_layout_and_populate(this, module);
                break;
            case "two-up-image":
                get_two_up_layout_and_populate(this, module);
                //var left_description = $(this).closest('.block').find('.description').text();
                break;
            case "events":
                get_events_layout_and_populate(this, module);
                //var left_description = $(this).closest('.block').find('.description').text();
                break;	
            case "one-up-image":
                get_one_up_layout_and_populate(this, module);
                //var left_description = $(this).closest('.block').find('.description').text();
                break;															
            default:
                break;

        }

        $('#load').dialog('open');
    });
		
    $('body').on('click', '.remove', function(e) {
        e.preventDefault();
        $(this).closest('.contentarea_container').remove();
    });
		
    $('body').on('click', '.drag', function(e) {
			
					if($(this).closest('.contentarea_container').hasClass('activated')){
						$('.activated').removeClass('activated');
					}else{
						$('.activated').removeClass('activated');
						$(this).closest('.contentarea_container').addClass('activated');
						var $bottomPad = $('.activated').find('.fullpad').css('padding-bottom'); 
						$bottomPad = $bottomPad.replace(/\D/g,'');
						$('#bottom_padding_slider').slider('value',$bottomPad);
						$('#bottom_padding').find('.value').text($bottomPad);
						
						var $topPad = $('.activated').find('.fullpad').css('padding-top'); 
						$topPad = $topPad.replace(/\D/g,'');
						$('#top_padding_slider').slider('value',$bottomPad);
						$('#top_padding').find('.value').text($bottomPad);						
					}
    });		
		$('#minimize_control_panel').click(function(){
			var $cPanel = $(this).parent();
			if($cPanel.hasClass('open')){
				$cPanel.removeClass('open').addClass('minimized');
				$(this).find('.fa').removeClass('fa-chevron-down').addClass('fa-chevron-up');
			}else{
				$cPanel.removeClass('minimized').addClass('open');				
				$(this).find('.fa').removeClass('fa-chevron-up').addClass('fa-chevron-down');
			}
			

			
			});
		
		//CONTROL PANEL
    $('body').on('click', '.bgcolor', function(e) {
        var checked = $(this).is(':checked');
        if (checked == true) {
            //$(this).parent().siblings('.contentarea').find('.fullpad').attr('bgcolor', '#dbe7ef');
						$('.activated').find('.contentarea').find('.fullpad').attr('bgcolor', '#dbe7ef');
        } else {
            //$(this).parent().siblings('.contentarea').find('.fullpad').attr('bgcolor', '#ffffff');
						$('.activated').find('.contentarea').find('.fullpad').attr('bgcolor', '#ffffff');
        }

    });
    $('body').on('click', '.sponsored', function(e) {
        var checked = $(this).is(':checked');
        if (checked == true) {
            //$(this).parent().siblings('.contentarea').find('.calltoaction').text('SPONSORED CONTENT');
						$('.activated').find('.contentarea').find('.calltoaction span').text('SPONSORED CONTENT');
        } else {
           //$(this).parent().siblings('.contentarea').find('.calltoaction').text(' ');
					 $('.activated').find('.contentarea').find('.calltoaction span').text(' ');
        }

    });
		
	$( "#bottom_padding_slider" ).slider({
				range: "min",
				min: 0,
				max: 100,
				step: 10,
				slide: function( event, ui ) {
					//$( "#amount" ).val( ui.value );
					if($('.activated').length){
						$('.activated').find('.fullpad').css({'padding-bottom':ui.value});
						$('#bottom_padding').find('.value').text(ui.value);	
					}else{
						alert("You have not activated any modules");	
					}
				}
			});
	$( "#top_padding_slider" ).slider({
				range: "min",
				min: 0,
				max: 100,
				step: 10,
				slide: function( event, ui ) {
					//$( "#amount" ).val( ui.value );
					if($('.activated').length){
						$('.activated').find('.fullpad').css({'padding-top':ui.value});
						$('#top_padding').find('.value').text(ui.value);	
					}else{
						alert("You have not activated any modules");	
					}
				}
			});		
    //$( "#amount" ).val( $( "#slider-vertical" ).slider( "value" ) );		
		

    //$('.contentarea_container').draggable();
    $('#container').sortable();
		$('.blockme').sortable();
		$( "#resize_control_panel" ).resizable({//on resize, check cpanel width and change image size
			handles:"w"
		});

    $(document).delegate('.moduleform', 'submit', function(event) {
        event.preventDefault();
        //$('#htmlform').submit();
        formData = $(this).serialize();
        $.ajax({
            type: "POST",
            dataType: "text",
            url: "layouts/" + folder + "/make-layout.php",
            data: formData
        }).done(function(data) {
            //console.log(data);
      //$('.active').attr('data-module', folder);
      // $('.active').html(data).removeClass('active').removeClass('raw').addClass('filled');
			if(folder == "freeform"){
				
				var $data = $(data).appendTo('#container');
				$data.filter('.contentarea').wrap('<div class="contentarea_container pasted" data-module="freeform"></div>');
				$('.contentarea_container.pasted').append('<div class="remove"></div><div class="edit"></div><div class="drag"></div>');	
				
			}else{
						$('#container').append(data);
			}
            $('#load').dialog('close');
            $('#loadContent').empty();



        });


    });
		
$('#clearContainer').click(function(){
	$('#container').empty();
	
	
	});		
//don't forget, this adds the google analytics content to the right column for the events module
$('body').on('change','input[name="title[]"]',function(){
		//if tagged == yes
		var item = $(this);
		var content = $(this).val();
		console.log(content);
		//$(this).parent().siblings().find('input[name="ad_content[]"]').val(content.toLowerCase().replace(/[ ]/g,"_"));
			$(this).parent().siblings().find('input[name="ad_content[]"]').val(			
				content.toLowerCase().replace(/&|and|,|:|\./g,"").replace(/san diego/g,"sd").replace(/[ ]/g,"_").replace(/__/g,"_")
			);
	
	});
	
	
$('body').on('click','.grabcode .ui-icon-closethick',function(){
	 	 $('.contentarea_container').find('.contentarea').unwrap();
		 $('.ui-dialog').removeClass('grabcode');
	});
	
	
	
	
$('body').on('click','.subheadline',function(){
		if($(this).hasClass('inactive')){
			$(this).find('span').wrap('<input class="editSubheadline"/>');
			$(this).removeClass('inactive');
			
		}
$('body').on('keypress','.editSubheadline',function(e){
	if (e.which == 13) {
    //var newValue = $(this).find('span').text();
		var newValue = $(this).val();
		
		//console.log(newValue);
	
	$(this).closest('.subheadline').addClass('inactive');
	$(this).find('span').text(newValue).unwrap();

		return false;
		

  }
	
});
		
		   //theCode += $(this).find('.contentarea').wrap('<p/>').parent().html();
	
	
	
	});	
	
		$( "#datepicker" ).datepicker();
		$('#slider').slider({
				min:0,
				max:1440,
				step:15,
				slide:function(event,ui){
					var hours = Math.floor(ui.value/60);
					var minutes = ui.value - (hours*60);
					
					if(hours.toString().length == 1) hours = '0' + hours;
					if(minutes.toString().length == 1) minutes = '0' + minutes
					
					
					$('#time').val(hours+':'+minutes);
					
				}
		
		
		});



});
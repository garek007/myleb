<?php
ob_start();
require_once('config.php'); 

if(mysqli_connect_errno()){
	echo "failed to connect";
	
}else{
	session_start();
	$email_address = $_SESSION['email'];
	$module_name = $_REQUEST['moduleName'];
	$the_code = $_REQUEST['theCode'];	
	$the_code = $con->real_escape_string($the_code);
	$company = 'SDTA';
	
		
		$sql = "INSERT INTO saved_modules(module_name,module_content,saved_by,company)
			VALUES ('".$module_name."','".$the_code."','".$email_address."','".$company."')";		
	
			
		if($con->query($sql) === TRUE){
			echo "Module Saved";
		}else{
			echo "Error: " .$sql . "<br>" . $con->error;
		}		

	
	
}

ob_flush();
?>


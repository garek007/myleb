<?php
ob_start();
require_once('config.php'); 

if(mysqli_connect_errno()){
	echo "failed to connect";
	
}else{
	session_start();
	//if it's a new project create, otherwise, save
	if(isset($_POST['isNew'])){
		$email_address = $_SESSION['email'];
		$project_name = $_POST['project_name'];
		$_SESSION['project_name'] = $project_name;		
		$email_type = $_POST['email_type'];
		$template = $_POST['select_template'];
		
		if($email_type == "type_htmlpaste"){
			$subject = $_POST['subject'];
			include "00-Includes/addUpdate-ET.php";		
			$sql = "INSERT INTO projects(Title,Author,exacttarget_id,Template)
			VALUES ('".$project_name."','".$email_address."', '".$exacttargetID."', '".$template."')";					
		}else{
			$sql = "INSERT INTO projects(Title,Author)
			VALUES ('".$project_name."','".$email_address."')";				
		}			
		
		if($con->query($sql) === TRUE){
			//echo "New record created";
			$project_id = mysqli_insert_id($con);
			$_SESSION['project_id'] = $project_id;
			header("Location: buildemail2.php?pnum=".$project_id);//open project
		}else{
			echo "Error: " .$sql . "<br>" . $conn->error;
		}		
		
	//if not new we just save	
	}else{	
		
			
		//$project_id = isset($_SESSION['project_id']) ? $_SESSION['project_id'] : $_REQUEST['pnum'];
		$project_id = $_REQUEST['pnum'];
		$project_name = $_SESSION['project_name'];
		$tag_4_ga = $_REQUEST['tag_4_ga'];
		$utm_campaign = $_REQUEST['utm_campaign'];
		$utm_source = $_REQUEST['utm_source'];
		$utm_medium = $_REQUEST['utm_medium'];		
		$data = $_REQUEST['mydata'];
		$data = $con->real_escape_string($data);
		$tmp = $_REQUEST['tmp'];
		
		$sql = "UPDATE projects
		SET Body = '".$data."', Tag_4_GA = '".$tag_4_ga."', utm_campaign = '".$utm_campaign."', utm_source = '".$utm_source."', utm_medium = '".		 $utm_medium."',Template = '".$tmp."'
		WHERE Project_Number = '".$project_id."'";
		
		if($con->query($sql) === TRUE){
			echo "Project Saved";
		}else{
			echo "Error: " .$sql . "<br>" . $con->error;
		}		
	}
	
	
}

ob_flush();
?>


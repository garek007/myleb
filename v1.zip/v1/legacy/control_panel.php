<div id="control_panel" class="control_panel">
<div id="resize_control_panel" class="open resize_control_panel">
<div class="drag_handles_w"><p></p><p></p><p></p></div>
<div id="minimize_control_panel" class="minimize_control_panel"><i class="fa fa-chevron-down"></i></div>


<table width="100%" border="0" cellspacing="0" cellpadding="0" id="bottom_padding">
  <tbody>
    <tr>
      <td style="padding-bottom:5px;">Bottom padding</td>
      <td align="right"><div class="value">--</div></td>
    </tr>
    <tr>
      <td colspan="2"><div id="bottom_padding_slider"></div></td>
      </tr>
  </tbody>
</table>

<table width="100%" border="0" cellspacing="0" cellpadding="0" id="top_padding" style="padding-top:20px;">
  <tbody>
    <tr>
      <td style="padding-bottom:5px;">Top padding</td>
      <td align="right"><div class="value">--</div></td>
    </tr>
    <tr>
      <td colspan="2"><div id="top_padding_slider"></div></td>
      </tr>
  </tbody>
</table>
<br>

<?php
$modules = [
"headline",
"header-600-wide",
"header-540-wide",
"two-up-image",
"one-up-image",
"four-up-image",
"divider",
"events",
"events-build",
"numbered-list",
"signatures",
"paragraph",
"freeform"

];

foreach($modules as $module){
	$folder = 'layouts/'.$module.'/';
	switch($module){
		case "events-build":
		case "freeform":$popup = "popup";$link=$folder.'index.php';break;
		default:$link=$folder.'lyt-'.$module.'.php';$popup="";break;
	}
	
	
	echo '<a href="'.$link.'" id="'.$module.'" class="'.$popup.' fullhtml" data-folder="'.$module.'">
	<img src="'.$folder.'icon.gif" /></a>';
	
}



?>




</div>
</div>

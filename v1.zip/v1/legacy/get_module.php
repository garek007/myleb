<?php
ob_start();
require_once('config.php'); 

if(mysqli_connect_errno()){
	echo "failed to connect";
	
}else{
	session_start();
	$email_address = $_SESSION['email'];
	$company = 'SDTA';
	

	$query = "SELECT module_content FROM saved_modules WHERE saved_by='$email_address' and company='$company'";
	$results = mysqli_query($con,$query);	
	//$r = mysqli_fetch_assoc($results);


	while($row = mysqli_fetch_assoc($results)){
				echo '<input type="checkbox">';
				echo '<div class="contentarea_container library">';
				echo $row['module_content'];
				echo '</div>';
				echo '<div style="width:100%;height:10px;"></div>';
	}
	
	
	
	
	
	
	
	
	
	
	
	
			
		//if($con->query($sql) === TRUE){

		//}else{
		//	echo "Error: " .$sql . "<br>" . $con->error;
		//}		

	
	
}

ob_flush();
?>


<?php


//link mapping
/*


--lyt-events.html


--lyt-four-up-image.php



<div class="orange"></div>
<div class="ltblue"></div>
<div class="white"></div>


--freeform n/a wrapped by scripts2.js



*/
$lyt2 = $_REQUEST['module'];


//These are the modules below
//All modules get the core control icons remove, drag, dup and copy HTML to clipboard. 
//To add new core controls add them to the $core array
//Any customizations or additional icons come later in the switch statement
function build_controls($module){
	$bgcolors = 
		'
		<div class="orange"></div>
		<div class="ltblue"></div>
		<div class="white"></div>	
		';
	$faExternal_onecol = '<i class="fa fa-external-link" aria-hidden="true" data-linktype="onecol"></i>';		
	
	$core=[
		["fa-times","remove"],
		["fa-ellipsis-v","drag"],
		["fa-files-o","duplicate"],
		["fa-clipboard"],
		["fa-floppy-o"]
	];

	$html = '<div class="module_controls">';
	foreach($core as $item){
		$html .= '<i class="fa '.implode(' ',$item).'" aria-hidden="true"/>';
	}		
	
	switch($module){
		case "divider":break;
		case "four-up-image":
			$html.='
			<i class="fa fa-external-link f1" aria-hidden="true" data-linktype="fourcol" data-position="one"></i>
			<i class="fa fa-external-link f2" aria-hidden="true" data-linktype="fourcol" data-position="two"></i>
			<i class="fa fa-external-link f3" aria-hidden="true" data-linktype="fourcol" data-position="three"></i>
			<i class="fa fa-external-link f4" aria-hidden="true" data-linktype="fourcol" data-position="four"></i>
			<i class="fa fa-link link f1" aria-hidden="true" data-position="one"></i>
			<i class="fa fa-link link f2" aria-hidden="true" data-position="two"></i>
			<i class="fa fa-link link f3" aria-hidden="true" data-position="three"></i>
			<i class="fa fa-link link f4" aria-hidden="true" data-position="four"></i>
			<i class="fa fa-circle-o toggle" aria-hidden="true"></i>
			';
			$html.= $bgcolors; 
			break;	
		case "headline": $html.='<i class="fa fa-usd toggle_sponsored" aria-hidden="true"></i>';	
		case "paragraph":
			$html.=$bgcolors;			
			break;			
		case "one-up-image":	
			$html.='
			<i class="fa fa-usd toggle_sponsored" aria-hidden="true"></i>
			<i class="fa fa-header remove_headline" aria-hidden="true"></i>
			';		
		case "header-540-wide":
			$html.=$faExternal_onecol.$bgcolors;
			break;		
		case "header-600-wide":
			$html.=$faExternal_onecol; 
			break;		
		case "events":
		  $html.='
			<i class="fa fa-plus addEvent right fa-1x" aria-hidden="true"></i>
			<i class="fa fa-minus removeEvent right fa-1x" aria-hidden="true"></i>
			';
			break;	
		case "numbered-list":
			$html.='
			<i class="fa fa-plus addRow right fa-1x" aria-hidden="true"></i> 
			<i class="fa fa-minus removeRow right fa-1x" aria-hidden="true"></i>
			';
			$html.= $bgcolors; 
			break;					
		case "two-up-image":
			$html.='
			<i class="fa fa-external-link left" aria-hidden="true" data-linktype="twocol-left"></i>
			<i class="fa fa-external-link right" aria-hidden="true" data-linktype="twocol-right"></i>
			';
			$html.= $bgcolors; 
			break;			
		default:break;
	}
	

	
	
	
	
	return $html.'</div>';
}
echo build_controls($lyt2);


/*

	
press-release
signatures
<i class="fa fa-times remove" aria-hidden="true"></i>
<i class="fa fa-ellipsis-v drag" aria-hidden="true"></i>
<i class="fa fa-plus addEvent right fa-1x" aria-hidden="true"></i>
<i class="fa fa-minus removeEvent right fa-1x" aria-hidden="true"></i>
<div id="addSignature">
<span><input type="checkbox" name="celey" />Candice</span>
<span><input type="checkbox" name="rarends" />Robert</span>

<span><input type="checkbox" name="egutierrez" />Edna</span>
<span><input type="checkbox" name="sweinberg" />Sarah</span>
<span><input type="checkbox" name="jterzi" />JT69</span>
<span><input type="checkbox" name="bhilemon" />Brian Hilemon</span>
<span><input type="checkbox" name="ggranados" />Gerry</span>
<span><input type="checkbox" name="nbjork" />Nancy</span>
<span><input type="checkbox" name="jtimko" />Joe Timko</span>
</div>
	
	
lyt-two-up-image.php




controls
insert image link
duplicate
drag
remove
insert hyperlink
drag n drop image upload
save to library
copy module HTML

addevent or person
remove event or person

change headline font size
change subheadline size
change p size

toggle sponsored content

*/
?>
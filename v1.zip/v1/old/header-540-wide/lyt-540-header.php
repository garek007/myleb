
<div class="contentarea_container blockme" data-module="header-540-wide">
<table class="contentarea" width="100%" border="0" cellspacing="0" cellpadding="0">
<!--------------------------------- 540 SECTION START ------------------------------------->
<!----------------------- dont forget to grab the opening table tag above ------------------------->
<!--------------------------------- 540 SECTION START ------------------------------------->
	<tbody>
		<tr>
			<td class="fullpad" style="padding: 0px 30px 15px;" >
			<table width="100%" border="0" cellspacing="0" cellpadding="0">
				<tbody>

					<tr>
						<td style="padding-top: 20px;" class="imagecont"><a class="dest_url" href="#"><img data-width="540" data-height="215"  class="fullwidth editableImage drop-area" src="images/MyLEB-placeholder_540x215.jpg" alt="Happiness is Calling from San Diego" border="0" width="540" style="display: block; height: auto !important;" /></a></td>
					</tr>
					<tr>
						<td style="padding-top: 15px;" class="title" align="left">
						<table width="100%" border="0" cellspacing="0" cellpadding="0">
							<tbody>
								<tr>
									<td>
									<a class="dest_url" style="font-size: 29px; color: #434448; line-height: 32px; text-decoration: none;" href="#">
									<font style="font-family: 'Arial Narrow', Helvetica, sans-serif;"> 
									<!--[if (!mso 14)&(!mso 15)]><!--> 
									<font style="font-family: Oswald, 'Arial Narrow', Helvetica, Arial, sans-serif;"> 
									<!--<![endif]--> 
                  <span class="editable headline maintitle unedited">MAIN TITLE OR HEADLINE</span>  
									 <!--[if (!mso 14)&(!mso 15)]><!--> 
									</font> 
									<!--<![endif]--></font>
									</a>
								  </td>
									<td align="right" valign="top"><a class="dest_url" href="#"><img class="link" src="http://image.exct.net/lib/fe6e15707166047a7715/m/1/sdta_nl_arrow_orange.png" align="baseline" style="vertical-align: baseline; padding-left: 7px;" border="0" /></a><img src="http://image.updates.sandiego.org/lib/fe9e15707566017871/m/2/spacer-10.gif" border="0" /></td>
								</tr>
							</tbody>
						</table>
						</td>
					</tr>
					<tr>
						<td class="description" align="left" style="font-family: Helvetica, Arial, sans-serif; font-size: 14px; color: #434448; padding-top: 5px;"><span class="editable textarea unedited">Description goes here, click here to type. Suggested maximum for this module is 300 characters.</span>
						</td>
					</tr>
				</tbody>
			</table>
			</td>
		</tr>
	</tbody>
<!--------------------------------- 540 SECTION END ------------------------------------->
<!----------------------- dont forget to grab the ending table tag below ------------------------->
<!--------------------------------- 540 SECTION END ------------------------------------->
</table>

<?php include "controls.html"; ?>
</div>

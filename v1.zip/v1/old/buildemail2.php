<?php 
session_start();
require_once('config.php');
if(!$_SESSION['auth']){header('location:index.php');}

include "00-Includes/header2.php"; 
 $pageTitle = "Email Builder"; 
 
 //check if tagging is on
if(isset($_GET['pnum']) && $_SESSION['auth']=='true'){
		
		$query = "SELECT Title, Tag_4_GA, utm_source, utm_medium, utm_campaign, Template, exacttarget_id FROM projects WHERE Project_Number=".$_GET['pnum'];
		$results = mysqli_query($con,$query);	
		
		$r = mysqli_fetch_assoc($results);
		$tagged = $r['Tag_4_GA'];
		$tmp = $r['Template'];
		$utm_source = $r['utm_source'];
		$utm_medium = $r['utm_medium'];		
		$utm_campaign = $r['utm_campaign'];
		$title = $r['Title'];
		$exacttarget_id = $r['exacttarget_id'];
		
}
 $date = date('Y-m-d');
 $subject = "SDTA Board of Directors Update - ".$date;
 
 
 //check if a template is selected
 

 ?>

<div class="first-row row">
  <div class="row">
  <h2><?php echo $title; ?></h2>
    <div class="first-col cols_12-4">
    	<input type="checkbox" name="tag4ga" class="tag4ga" id="tag4ga" <?php if($tagged==1) {echo 'checked'; } ?>>Tag in Google Analytics?
      <br>
      <select id="template">
        <option>&lt;select tagging template&gt;</option>
        <option value="tttd" <?php if($tmp == 'tttd') echo 'selected'; ?>>Top Things to Do</option>
        <option value="monthly" <?php if($tmp == 'monthly') echo 'selected'; ?>>Monthly Consumer</option>
        <option value="nba">Nothing but Ads</option>
        <option value="connect">Connect</option>
        <option value="er">Executive Report</option>
      </select>
      <br>
      

			<div <?php if($tagged==0) {echo 'style="display:none;"'; } ?>  id="gaFields">
        <input name="utm_campaign" id="utm_campaign"value="<?php echo $utm_campaign; ?>" />Campaign<br>
        <input name="utm_source" type="text" id="utm_source" value="<?php echo $utm_source; ?>" size="30">Source<br>
        <input name="utm_medium" type="text" id="utm_medium" value="<?php echo $utm_medium; ?>" size="30">Medium<br>
      </div>    
    </div>
    <div class="cols_12-3">
      


      <?php if($exacttarget_id != 0):?>
      ExactTarget Email ID
      <input type="text" name="exacttarget_id" id="exacttarget_id" class="text" value="<?php echo $exacttarget_id; ?>"> 
      <?php endif; ?>   
    </div>
  </div>




</div>




<div class="row">
<a class="myleb_button" id="grabTheCode">Grab the Code!</a>

<a class="myleb_button" id="saveproject">Save</a>

<?php if($exacttarget_id != 0):?><a class="button" id="syncToET">Sync to ExactTarget</a><?php endif; ?>
     &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a class="myleb_button" id="clearContainer">Clear Container!</a>
</div>


<div id="load" >
<div id="loadContent"></div>
</div>
<div id="texteditor_wrapper">
<div id="richtext_editor"></div>
</div>

<?php include "00-Includes/control_panel.html"; ?>
<div id="cropbox" class="cropbox">
<i class="fa fa-check upload-result fa-4x" aria-hidden="true"></i>
<i class="fa fa-times upload-cancel fa-4x" aria-hidden="true"></i>
<i class="fa fa-spinner fa-pulse fa-3x fa-fw"></i>

<div id="viewport_height" class="viewport_height"></div>
      Height
    <div class="viewport_height_value">--</div>


</div>


<div class="row" style="padding-top:20px;border-top:1px solid #ddd;background:url('http://image.exct.net/lib/fe6e15707166047a7715/m/1/sdta_nl_small_texture.png');">
  <div class="first-col cols_12-12">

    
    
    <?php 
    
      if(isset($_GET['pnum']) && $_SESSION['auth']=='true'){        
        $query = "SELECT Body,Date_Modified,Template FROM projects WHERE Project_Number=".$_GET['pnum'];
        $results = mysqli_query($con,$query);	
        $r = mysqli_fetch_assoc($results);
				
				$dateModified = $r['Date_Modified'];
				$template = $r['Template'];
				if($dateModified == '0000-00-00 00:00:00'){
					$new = "new_project";
					
				}
				
				echo '<main id="container" class="container '.$new.' '.$template.'" data-template="'.$template.'">';
        echo $r['Body'];
				echo '</main>';
        
      }
    
    
    ?>
    
    
  </div>
</div>






</form>





  

<?php include "00-Includes/footer2.php"; ?>

<?php 
session_start();
require_once('config.php');


include "00-Includes/header.php"; 
 $pageTitle = "Email Builder"; 
 
 
 ?>

<div class="first-row row">


</div>


<div class="row">
<a class="button" id="grabTheCode">Grab the Code!</a>

<a class="button" id="saveproject">Save</a>
<a href="https://www.youtube.com/watch?v=WRmBChQjZPs" class="button" id="sendToET">Send to ExactTarget (coming one day....)</a>
     &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a class="button" id="clearContainer">Clear Container!</a>
</div>


<div id="load" >
<div id="loadContent"></div>
</div>










<div id="control_panel" >
<div id="resize_control_panel" class="open">
<div class="drag_handles_w"><p></p><p></p><p></p></div>
<div id="minimize_control_panel"><i class="fa fa-chevron-down"></i></div>

<h5>Styles</h5>
<input type="checkbox" name="bgcolor" class="bgcolor">Toggle BG Color<br>
<input type="checkbox" value="true" name="sponsored" class="sponsored">Toggle Sponsored<br>	<br>



<table width="100%" border="0" cellspacing="0" cellpadding="0" id="bottom_padding">
  <tbody>
    <tr>
      <td style="padding-bottom:5px;">Bottom padding</td>
      <td align="right"><div class="value">--</div></td>
    </tr>
    <tr>
      <td colspan="2"><div id="bottom_padding_slider"></div></td>
      </tr>
  </tbody>
</table>

<table width="100%" border="0" cellspacing="0" cellpadding="0" id="top_padding" style="padding-top:20px;">
  <tbody>
    <tr>
      <td style="padding-bottom:5px;">Top padding</td>
      <td align="right"><div class="value">--</div></td>
    </tr>
    <tr>
      <td colspan="2"><div id="top_padding_slider"></div></td>
      </tr>
  </tbody>
</table>
<br>

<h5>Modules</h5>

<a href="layouts/header-600-wide/index.php" id="header-600" class="fullhtml" data-folder="header-600-wide"><img src="layouts/header-600-wide/icon.gif" width="300" height="183" alt=""/></a>


<a href="layouts/header-540-wide/index.php" id="layouts/540wide-header/index.php" class="fullhtml" data-folder="header-540-wide"><img src="layouts/header-540-wide/icon.gif" width="300" height="183" alt=""/></a>


<a href="layouts/two-up-image/index.php" id="image2up" class="fullhtml" data-folder="two-up-image"><img src="layouts/two-up-image/icon.gif" width="300" height="139" alt=""/></a>
<a href="layouts/one-up-image/index.php" id="image1up" class="fullhtml" data-folder="one-up-image"><img src="layouts/one-up-image/icon.gif" width="300" height="125" alt=""/></a>

<a href="layouts/four-up-image/index.php" id="image4up" class="fullhtml" data-folder="four-up-image"><img src="layouts/four-up-image/icon.gif" width="300" height="121" alt=""/></a>
<a href="layouts/events/index.php" id="events" class="fullhtml" data-folder="events"><img src="layouts/events/icon.gif" width="300" height="139" alt=""/> </a>
<a href="layouts/headline/index.php" id="headline" class="fullhtml" data-folder="headline"><img src="layouts/headline/icon.gif" width="300" height="35" alt=""/></a>

<a href="layouts/divider/index.php" id="divider" class="fullhtml" data-folder="divider"><img src="layouts/divider/icon.gif" width="300" height="35" alt=""/> </a>

<a href="layouts/freeform/index.php" id="freeform" class="fullhtml" data-folder="freeform"><img src="layouts/freeform/icon.gif" width="300" height="35" alt=""/> </a>





</div>
</div>


<div class="row" style="padding-top:20px;border-top:1px solid #ddd;background:url('http://image.exct.net/lib/fe6e15707166047a7715/m/1/sdta_nl_small_texture.png');">
  <div class="first-col cols_12-12">
    <div id="container" class="container">
    <?php 
    
      if(isset($_GET['pnum']) && $_SESSION['auth']=='true'){
        
        $query = "SELECT Body FROM projects WHERE Project_Number=".$_GET['pnum'];
        $results = mysqli_query($con,$query);	
        
        $r = mysqli_fetch_assoc($results);
        echo $r['Body'];

        
      }
    
    
    ?>
    
    </div>
  </div>
</div>






</form>





  

<?php include "00-Includes/footer.php"; ?>

<?php
ob_start();
require_once('config.php'); 
if(mysqli_connect_errno()){
	echo "Sorry, there was a problem connecting to the database.";
	
}else{
	session_start();
	include "00-Includes/header.php";
	$email_address = $_SESSION['email'];
	$project_name = $_POST['project_name'];
	$_SESSION['project_name'] = $project_name;
	
	$email_type = $_POST['email_type'];
	if($email_type == "type_htmlpaste"){
		$subject = $_POST['subject'];
		
		
		include "00-Includes/addUpdate-ET.php";		
		//$exacttargetID = 234567;	
			
		$sql = "INSERT INTO projects(Title,Author,exacttarget_id)
		VALUES ('".$project_name."','".$email_address."', '".$exacttargetID."')";					
		
		//add column for exacttarget ID to database
//		include it in the insert below
	//and retrieve it to an input field on the buildEmail page	
		
		
		
		
	}else{
		
		$sql = "INSERT INTO projects(Title,Author)
		VALUES ('".$project_name."','".$email_address."')";		
		
		
		
		
	}	
		
		
	
	
	

	
	if($con->query($sql) === TRUE){
		//echo "New record created";
		$project_id = mysqli_insert_id($con);
		$_SESSION['project_id'] = $project_id;
		
		header("Location: buildemail2.php?pnum=".$project_id);
		//open project
	
	}else{
		echo "Error: " .$sql . "<br>" . $conn->error;
		
	}
	
	
	
	
}
/*  NEED TO MAKE THIS GRAB THE TITLE FROM THE LAUNCHPAD BEFORE WRITING TO DB, ALSO,
MAKE SURE THAT THE PRIMARY KEY IN DB IS SET TO AUTO INCREMENT.

*/





include "00-Includes/footer.php";
ob_flush();
 ?>

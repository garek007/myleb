<?php
$html = <<<EOT
<div class="contentarea_container" data-module="divider">
<table class="contentarea twocol" width="100%" border="0" cellspacing="0" cellpadding="0">
<!--------------------------------- DIVIDER LINE START ------------------------------------->
<!----------------------- dont forget to grab the table tag above -------------------------->
<!--------------------------------- DIVIDER LINE START ------------------------------------->
	<tbody>
		<tr>
			<td class="fullpad" style="padding: 20px 30px 0px;">
			<table width="100%" border="0" cellspacing="0" cellpadding="0">
				<tbody>
					<tr>
						<td style="border-top-width: 1px; border-top-style: solid; border-top-color: #dfe0e0; padding-top: 20px;">
						</td>
					</tr>
				</tbody>
			</table>
			</td>
		</tr>
	</tbody>
<!--------------------------------- DIVIDER LINE START ------------------------------------->
<!----------------------- dont forget to grab the table tag below -------------------------->
<!--------------------------------- DIVIDER LINE START ------------------------------------->
</table>
<div class="remove"></div><div class="drag"></div>
</div>
EOT;
?>
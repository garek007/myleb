

<div class="row">
<h2>1-up Image with Text Module Builder</h2>
<img class="left" style="border:10px solid #ddd;" src="http://www.enjoysandiego.com/mylittleemailbuilder2/images/lyt-imgleft-textright.jpg" />
</div>


<form class="moduleform" title="tttdform" name="tttdform" action="layouts/one-up-image/make-layout.php" method="post">



 <?php include '../../00-Includes/ga-fields.html'; ?>

<div class="row">

  
  <div class="first-col cols_12-4">
      <label for="medium">Header Text (Don't Miss)</label>
    <input class="text" name="section_title" type="text" size="30"></div>
    
  <div class="cols_12-4">  
      <label for="medium">Subheader Text (See all events)</label>
    <input class="text" name="subheader" type="text" size="30">
  </div>
  <div class="cols_12-4">  
      <label for="medium">Destination URL for Subheader</label>
    <input class="text" name="subheader_url" type="text" size="30">
  </div>
</div><!-- End Row -->

<div class="row">
  <div class="first-col cols_12-4">
  <input class="text drop-area hasHeight" name="image_url" type="text" size="25">
  </div>
  <div class="cols_12-8">
  <label for="dates">Dates</label>
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tbody>
    <tr>
      <td><input class="text" name="dates" type="text"></td>
      <td><input class="text" name="dates2" type="text"></td>
      <td>  <label for="backgroundcolor">
  <input type="checkbox" name="italics">&nbsp;Italicize?</label></td>
    </tr>
  </tbody>
</table>

 

	<div class="first-col cols_12-12">
    <div class="first-col cols_12-9">
      <label for="title">Headline</label>
      <input class="text" name="headline" type="text">
    </div>
    <div class="cols_12-3">
      <label for="fontsize">Title Font Size</label>
      <input class="text" name="font_size" type="text" size="27" value="27">
    </div>
  </div>
  <label for="description">Description</label>
  <textarea class="text" name="description"></textarea>
 <br>

  <label for="Durl">Destination URL</label>
  <input class="text" name="dest_url" type="text">
  </div>
</div><!-- End Row -->



<div class="row">

<input type="submit" value="Generate HTML" class="submit">
</div>





</form>

<?php
$html = <<<EOT
<div class="contentarea_container" data-module="one-up-image">
<table class="contentarea" width="100%" border="0" cellspacing="0" cellpadding="0">
<!--------------------------------- ONE-UP IMAGE SECTION START ------------------------------------->
<!-------------------------------- ONE-UP IMAGE SECTION START ------------------------------------>
	<tbody>
		<tr>
			<td class="fullpad" $bgcolor style="padding: 0px 30px;">
			<table class="imageleft" width="100%" border="0" cellspacing="0" cellpadding="0">
				<tbody>
					<tr>
						<td style="padding-top: 20px; padding-bottom: 20px;">
						<table class="headlinebar" width="100%" border="0" cellspacing="0" cellpadding="0">
							<tbody>
								<tr>
						    <td class="subheadline section_title" align="left" valign="top" style="font-size: 18px; letter-spacing: 0.3px; color: #005f86; border-top-width: 1px; border-top-style: solid; border-top-color: #dfe0e0; padding-top: 15px;"><font style="font-family: 'Arial Narrow', Helvetica, sans-serif;"> 
									<!--[if (!mso 14)&(!mso 15)]><!--> 
									<font style="font-family: Oswald, 'Arial Narrow', Helvetica, Arial, sans-serif;"> 
									<!--<![endif]--> 
								$section_title
									<!--[if (!mso 14)&(!mso 15)]><!--> 
									</font> 
									<!--<![endif]--></font></td>
									<td class="calltoaction" align="right" valign="top" style="font-size: 12px; letter-spacing: 0.5px; color: #979597; border-top-width: 1px; border-top-style: solid; border-top-color: #dfe0e0; padding-top: 15px;"><font style="font-family: 'Arial Narrow', Helvetica, sans-serif;"> 
									<!--[if (!mso 14)&(!mso 15)]><!--> 
									<font style="font-family: Oswald, 'Arial Narrow', Helvetica, Arial, sans-serif;"> 
									<!--<![endif]--> 
									<a href="$subheader_url" style="text-decoration: none; color: #979597;">$subheader</a>
									<!--[if (!mso 14)&(!mso 15)]><!--> 
									</font> 
									<!--<![endif]--></font></td>
								</tr>
							</tbody>
						</table>
						</td>
					</tr>
					<tr>
						<td>
						<table width="100%" border="0" cellspacing="0" cellpadding="0">
							<tbody>
								<tr>
									<td class="blockme imagecont" style="padding-right: 5px;" width="50%" valign="top" align="left"><img class="fullwidth" src="$image_url" border="0" style="display: block; height: auto !important;" width="265" /></td>
									<td class="blockme" style="padding-left: 5px;" width="50%" valign="top" align="left">
									<table width="100%" border="0" cellspacing="0" cellpadding="0">
										<tbody>
											<tr>
												<td class="nopad" style="padding-left: 15px;">
												<table width="100%" border="0" cellspacing="0" cellpadding="0">
													<tbody>
														<tr>
															<td class="date" align="left" style="font-size: 12px; line-height: 14px; letter-spacing: 0.5px; color: #ee7421; padding-bottom: 5px;"><font style="font-family: 'Arial Narrow', Helvetica, sans-serif;"> 
															<!--[if (!mso 14)&(!mso 15)]><!--> 
															<font style="font-family: Oswald, 'Arial Narrow', Helvetica, Arial, sans-serif;"> 
															<!--<![endif]--> 
														<span class="dates">$dates</span> &nbsp; <br /> <span class="dates2" $italics>$dates2</span>
															<!--[if (!mso 14)&(!mso 15)]><!--> 
															</font> 
															<!--<![endif]--></font></td>
														</tr>
														<tr>
															<td class="title" align="left" style="font-size: $font_size; line-height: 34px; padding-bottom: 5px; letter-spacing: 0.3px;"><a class="headline" href="$dest_url" style="color: #434448; text-decoration: none; font-family: Oswald, 'Arial Narrow', Helvetica, Arial, sans-serif;">$headline</a></td>
														</tr>
														<tr>
															<td class="description" align="left" style="font-family: Helvetica, Arial, sans-serif; font-size: 12px; color: #434448; padding-top: 5px;">$description</td>
														</tr>
														<tr>
															<td class="button arrowcorrection" align="left" style="padding-top: 25px;"><a href="$dest_url"><img src="http://image.exct.net/lib/fe6e15707166047a7715/m/1/sdta_nl_arrow_orange.png" align="bottom" style="vertical-align: bottom;" border="0" /></a></td>
														</tr>
													</tbody>
												</table>
												</td>
											</tr>
										</tbody>
									</table>
									</td>
								</tr>
							</tbody>
						</table>
						</td>
					</tr>
				</tbody>
			</table>
			</td>
		</tr>
	</tbody>
	<!--------------------------------- ONE-UP IMAGE SECTION END ------------------------------------->
<!-------------------------------- ONE-UP IMAGE SECTION END ---------------------------------->
</table>

<div class="remove"></div><div class="edit"></div><div class="drag"></div>
</div>
EOT;
?>
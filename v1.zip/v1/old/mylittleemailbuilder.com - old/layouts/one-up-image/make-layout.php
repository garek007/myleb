<?php

//ini_set('display_errors', 0);
//loop to see how many fields are filled out





//check for content
try {
			$headline = stripslashes($_POST['headline']);
			$description = nl2br(trim(stripslashes($_POST["description"])));
			$dest_url = $_POST['dest_url'];
			$image_url = $_POST['image_url'];
			
			
		}catch(Exception $e){
			echo 'ERROR: You must have some content';			
		} 
	






$section_title = isset($_POST['section_title']) ? strtoupper($_POST['section_title']) : '';


$subheader = isset($_POST['subheader']) ? strtoupper($_POST['subheader']) : '';
$subheader_url = isset($_POST['subheader_url']) ? strtoupper($_POST['subheader_url']) : '';


$dates = isset($_POST['dates']) ? strtoupper($_POST['dates']) : '';
$dates2 = isset($_POST['dates2']) ? strtoupper($_POST['dates2']) : '';
$italics = isset($_POST['italics']) ? 'style="font-style:italic;"' : '';




if(isset($_POST['add_ga_tags'])){
	if($_POST['utm_campaign']== 'custom'){
		$utm_campaign = $_POST['custom_campaign_name'];
	}else{
		$utm_campaign = trim($_POST[str_replace(' ','%20','utm_campaign')]);
	}
	
	$utm_term = 'header';
	$utm_source = $_POST['traffic_source'];
	$utm_medium = $_POST['medium'];
	
	$dest_url.= '?utm_campaign='.$utm_campaign.'&utm_source='.$utm_source.'&utm_medium='.$utm_medium.'&utm_term='.$utm_term;
	
}


//style
//$fontSize = '27px';
$font_size = $_POST['font_size'].'px';
$section_title_color = 'color: #005f86;';//434448 is the grey




include 'lyt-1upimage.php';
echo $html;




?>

            
            
            
            
						


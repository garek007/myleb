<?php
session_start();
include "../../00-Includes/header.php";






//ini_set('display_errors', 0);
//loop to see how many fields are filled out

//find campaign name if any

$header = isset($_POST['header']) ? strtoupper($_POST['header']) : '';
$description = isset($_POST['description']) ? nl2br(trim($_POST['description'])) : '';
$sharelink = $_POST['share_link'];
$twitter_text = stripslashes(htmlentities($_POST['twitter_text']));
$linkedin_title = $_POST['linkedin_title'];
$linkedin_source = isset($_POST['linkedin_source']) ? $_POST['linkedin_source'] : '';
$linkedin_summary = isset($_POST['linkedin_summary']) ? $_POST['linkedin_summary'] : '';
$Iurl = $_POST['Iurl'];


	//$campaign = trim($_POST[str_replace(' ','%20','custom_campaign_name')]);
$truncated_link = explode('//', $sharelink);

$twitter_link = 'https://twitter.com/home?status='.str_replace(' ','%20',$twitter_text).'%0Ahttp%3A//'.$truncated_link[1];
$twitter_link = str_replace('#','%23',$twitter_link);
$facebook_link = 'https://www.facebook.com/sharer/sharer.php?u=http%3A//'.$truncated_link[1];
$linkedin_link = 'https://www.linkedin.com/shareArticle?mini=true&url=http%3A//'.$truncated_link[1].'&title='.str_replace(' ','%20',$linkedin_title).'&summary='.$linkedin_summary.'&source='.$linkedin_source;

$googleplus_link = 'https://plus.google.com/share?url=http%3A//'.$truncated_link[1];
//https://twitter.com/home?status=Hey%20check%20out%20my%20twitter%20link%0Ahttp%3A//www.sandiego.org/events
//https://www.facebook.com/sharer/sharer.php?u=http%3A//www.sandiego.org/events

//https://www.facebook.com/sharer/sharer.php?u=http%3A//
//https://www.linkedin.com/shareArticle?mini=true&url=http%3A//www.sandiego.org/events&title=My%20sweet%20LinkedIn%20Link&summary=&source=

if(isset($_POST['whoismakingthis'])){
	$whomadethis = new stdClass();
	if($_POST['whoismakingthis']=="iambrent"){
		$whomadethis->name='Brent Bernasconi';
		$whomadethis->title='Interactive Editor';
		$whomadethis->email = 'bbernasconi@sandiego.org';
		$whomadethis->phone = '619-557-2846';
		$whomadethis->twitterhash = '@bernasconi';
		$whomadethis->twitterlink = 'https://twitter.com/bernasconi';
	}else{
		$whomadethis->name='Nick Karvounis';
		$whomadethis->title='B2B Content Editor';
		$whomadethis->email = 'nkarvounis@sandiego.org';
		$whomadethis->phone = '619-557-2870';
		$whomadethis->twitterhash = '@Nick_Karvounis';
		$whomadethis->twitterlink = 'https://twitter.com/nick_karvounis';
		
	}

	
}

include 'lyt-shareable.php';


$_SESSION['html'] = $html;
$_SESSION['subject'] = stripslashes($_POST['et_subject']);
$_SESSION['email_name'] = $_POST['et_email_name'];
$_SESSION['from_name'] = $whomadethis->name;
$_SESSION['from_email'] = $whomadethis->email;

?>
<div class="first-row row">
<br>

<form action="send_to_ET.php" method="post">

<div class="first-col cols_12-4">
<h3>Select Lists</h3>



<input type="checkbox" name="lists[]" value="583375">&nbsp;SDTA Members List - Research and Connect</label><br>
<input type="checkbox" name="lists[]" value="365324">&nbsp;All Employees</label><br>
<input type="checkbox" name="lists[]" value="299500">&nbsp;Always Send To</label><br>
<input type="checkbox" name="lists[]" value="300512">&nbsp;Nick Only</label><br>
<input type="checkbox" name="lists[]" value="384277">&nbsp;Stan Only</label><br>
<input type="checkbox" name="lists[]" value="307955">&nbsp;Brent Only</label><br>
</div>
<div class="cols_12-8">
Enter Send Date: <input id="datepicker" type="text" name="send_date" /><br>

  <select style="display:none;"  name="send_time" id="send_time">
    <option value="0600">6:00 AM</option>
    <option value="0630">6:30 AM</option>
    <option value="1500">3:08 PM</option>
  </select>
  
  <div style="margin:20px 0 20px;" id="slider"></div>
  <input type="text" name="time" id="time" />

</div>


<input style="clear:both;" type="submit" value="Send Email">

</form>

</div>
<div class="row">
<div class="first-col cols_12-12">
<?php



echo $html;

?>
</div></div>
<?php





include "../../00-Includes/footer.php";

/*





include "../../00-Includes/header.php"; 
echo '<div class="first-row row">
<p>This is your email preview. If you like it, grab the code from the text box at bottom. If you don\'t, never fear, hit the back button and your fields will still be there.</p>
<div class="email_layout">';
echo $html;
echo '</div></div>';
include '../../00-Includes/rawoutput.php';
include "../../00-Includes/footer.php";

*/
?>

            
            
            
            
						


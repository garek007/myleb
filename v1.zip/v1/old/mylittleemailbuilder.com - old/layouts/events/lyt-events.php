<?php
$html = <<<EOT
<div class="contentarea_container" data-module="events">
<table class="contentarea" width="100%" cellspacing="0" cellpadding="0" border="0">
  <tbody>
    <tr>
      <td style="padding-top: 0px;"><table width="100%" cellspacing="0" cellpadding="0" border="0">
          <tbody>
            <tr>
              <td bgcolor="#fddea6" background="http://image.exct.net/lib/fe6e15707166047a7715/m/1/sdta_nl_small_texture_tan.jpg" style="padding: 25px 30px 15px;" class="fullpad"><table width="100%" cellspacing="0" cellpadding="0" border="0" class="headlinebar">
                  <tbody>
                    <tr>
                      <td valign="top" align="left" style="font-size: 18px; color: #005f86;" class="subheadline"><font style="font-family: 'Arial Narrow', Helvetica, sans-serif;"> 
                        <!--[if (!mso 14)&(!mso 15)]><!--> 
                        <font style="font-family: Oswald, 'Arial Narrow', Helvetica, Arial, sans-serif;"> 
                        <!--<![endif]-->
                        $section_title
                          <!--[if (!mso 14)&(!mso 15)]><!--> 
                        </font> 
                        <!--<![endif]--></font></td>
                      <td valign="top" align="right" style="font-size: 12px;" class="calltoaction"><a style="text-decoration: none; color: #979597;" href="$eventurl"> <font style="font-family: 'Arial Narrow', Helvetica, sans-serif;"> 
                        <!--[if (!mso 14)&(!mso 15)]><!--> 
                        <font style="font-family: Oswald, 'Arial Narrow', Helvetica, Arial, sans-serif;"> 
                        <!--<![endif]--> $urltext <!--[if (!mso 14)&(!mso 15)]><!--> 
                        </font> 
                        <!--<![endif]--></font> </a></td>
                    </tr>
                  </tbody>
                </table>
                <table width="100%" cellspacing="0" cellpadding="0" border="0" class="eventcal">
                  <tbody>
EOT;

for($i=0;$i<count($dest_url);$i++){
	if(!empty($dest_url[$i])){
		
		
		
		if($ga_tags){

	$dest_url[$i].= '?utm_campaign='.$ga_tags->campaign.'&utm_source='.$ga_tags->source.'&utm_medium='.$ga_tags->medium.'&utm_term='.$ga_tags->keyword.'&utm_content='.$ga_tags->ad_content[$i];

		}
		
		

		
		if($i%2 ==0){
			
			

			
			
			$html .= leftEvent($month[$i],$date[$i],$dest_url[$i],$title[$i],$i);
			
			
			
			
			
			
			
			
			
		}else{
			$html .= rightEvent($month[$i],$date[$i],$dest_url[$i],$title[$i],$i);
		}
	}
}







$html .= <<<EOT
								<!-- END: FINAL ROW -->
							</tbody>
						</table></td>
					</tr>
				</tbody>
			</table></td>
		</tr>
	</tbody>
</table>
<div class="remove"></div><div class="edit"></div><div class="drag"></div>
</div>
EOT;
?>
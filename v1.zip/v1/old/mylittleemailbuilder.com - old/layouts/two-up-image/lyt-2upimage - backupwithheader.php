<?php
$html = <<<EOT
<table class="contentarea twocol" width="100%" border="0" cellspacing="0" cellpadding="0">
	<tbody>
		<tr>
			<td class="fullpad" style="padding: $top_padding 30px 30px;" $bgcolor>
			<table width="100%" border="0" cellspacing="0" cellpadding="0">
				<tbody>
					<tr>
						<td class="title" align="left" style="font-size: 18px; letter-spacing: 0.3px; padding-bottom: $top_padding; color: #434448;"><font style="font-family: 'Arial Narrow', Helvetica, sans-serif;"> 
						<!--[if (!mso 14)&(!mso 15)]><!--> 
						<font style="font-family: Oswald, 'Arial Narrow', Helvetica, Arial, sans-serif;"> 
						<!--<![endif]--> 
						<span class="section_title">$section_title</span>
						<!--[if (!mso 14)&(!mso 15)]><!--> 
						</font> 
						<!--<![endif]--></font></td>
						<td class="calltoaction" align="right" valign="top" style="font-size: 12px;"><a href="#" style="color: #88b6ca; font-family: Oswald, 'Arial Narrow', Helvetica, Arial, sans-serif; text-decoration: none;">$sponsored</a></td>
					</tr>
				</tbody>
			</table>
			<table width="100%" border="0" cellspacing="0" cellpadding="0">
				<tbody>
					<tr>
						<td class="blockme" style="padding-right: 5px;" width="50%" valign="top" align="left">
						<table width="100%" border="0" cellspacing="0" cellpadding="0">
							<tbody>
								<tr>
									<td class="imagecont left" style="padding-bottom: 10px;"><a href="$left_url"><img class="fullwidth" src="$left_image" border="0" style="display: block; height: auto !important;" width="265" /></a></td>
								</tr>
								<tr>
									<td class="title" align="left"><table width="100%" border="0" cellspacing="0" cellpadding="0">
									  <tbody>
									    <tr>
									      <td><a class="left_headline" href="$left_url" style="font-size: 18px; color: #434448; text-decoration: none;">
									<font style="font-family: 'Arial Narrow', Helvetica, sans-serif;"> 
									<!--[if (!mso 14)&(!mso 15)]><!--> 
									<font style="font-family: Oswald, 'Arial Narrow', Helvetica, Arial, sans-serif;"> 
									<!--<![endif]--> 
						$left_headline

									<!--[if (!mso 14)&(!mso 15)]><!--> 
									</font> 
									<!--<![endif]-->
									</font>
								</a></td>
									      <td valign="top" align="right"><a href="$left_url"><img src="http://image.exct.net/lib/fe6e15707166047a7715/m/1/sdta_nl_arrow_dark.png" vspace="0" width="20" border="0" /></a><img src="http://image.updates.sandiego.org/lib/fe9e15707566017871/m/2/spacer-13.gif" border="0" /></td>
								        </tr>
								      </tbody>
								    </table></td>
								</tr>
								<tr>
									<td class="description left" align="left" style="font-family: Helvetica, Arial, sans-serif; font-size: 12px; color: #434448; padding-top: 5px;">$left_description

									</td>
								</tr>
							</tbody>
						</table>
						</td>
						<td class="blockme" style="padding-left: 5px;" width="50%" valign="top" align="left">
EOT;
            
           if(!empty($_POST['right_url'])){
$html .= <<<EOT
	<table width="100%" border="0" cellspacing="0" cellpadding="0">
							<tbody>
								<tr>
									<td class="imagecont right" style="padding-bottom: 10px;"><a href="$right_url"><img class="fullwidth" src="$right_image" border="0" style="display: block; height: auto !important;" width="265" /></a></td>
								</tr>
								<tr>
									<td class="title" align="left"><table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tbody>
    <tr>
      <td><a class="right_headline" href="$right_url" style="font-size: 18px; color: #434448; text-decoration: none;">
									<font style="font-family: 'Arial Narrow', Helvetica, sans-serif;"> 
									<!--[if (!mso 14)&(!mso 15)]><!--> 
									<font style="font-family: Oswald, 'Arial Narrow', Helvetica, Arial, sans-serif;"> 
									<!--<![endif]--> 
				$right_headline
									<!--[if (!mso 14)&(!mso 15)]><!--> 
									</font> 
									<!--<![endif]-->
									</font>
									</a></td>
      <td valign="top" align="right"><a href="$right_url"><img src="http://image.exct.net/lib/fe6e15707166047a7715/m/1/sdta_nl_arrow_dark.png" vspace="0" width="20" border="0" /></a><img src="http://image.updates.sandiego.org/lib/fe9e15707566017871/m/2/spacer-13.gif" border="0" /></td>
    </tr>
  </tbody>
</table>
</td>
								</tr>
								<tr>
									<td class="description right" align="left" style="font-family: Helvetica, Arial, sans-serif; font-size: 12px; color: #434448; padding-top: 5px;">$right_description
									</td>
								</tr>
							</tbody>
						</table>
EOT;
           }
$html .= <<<EOT
					</td>
					</tr>
				</tbody>
			</table>
			</td>
		</tr>
	</tbody>
</table>
EOT;
?>
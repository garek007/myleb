<div class="first-row row">
<h2>2-up Module Builder</h2>

</div>


<form class="moduleform" title="tttdform" name="tttdform" action="layouts/two-up-image/make-layout.php" method="post">



 <?php include '../../00-Includes/ga-fields.html'; ?>



<div class="row">
<div class="first-col cols_12-6">
<h4>Left Slot</h4>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tbody>
    <tr>
      <td>Image URL</td>
      <td>
        <input class="text drop-area" name="left_image" id="left_image" type="text" size="25">
      </td>
    </tr>
    <tr>
      <td>Headline</td>
      <td><input class="text" name="left_headline" id="left_headline" type="text" size="25"></td>
    </tr>
    <tr>
      <td>Description</td>
      <td>
      <textarea name="left_description" id="left_description"></textarea>
      </td>
    </tr>
    <tr>
      <td>Destination URL</td>
      <td><input class="text" name="left_url" type="text" id="textfield2" size="25"></td>
    </tr>
  </tbody>
</table>

</div>

<div class="cols_12-6">
<h4>Right Slot</h4>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tbody>
    <tr>
      <td>Image URL</td>
      <td>
        <input class="text drop-area" name="right_image" type="text" id="textfield2" size="25">
      </td>
    </tr>
    <tr>
      <td>Headline</td>
      <td><input class="text" name="right_headline" type="text" id="textfield2" size="25"></td>
    </tr>
    <tr>
      <td>Description</td>
      <td><textarea name="right_description" id="right_description"></textarea></td>
    </tr>
    <tr>
      <td>Destination URL</td>
      <td><input class="text" name="right_url" type="text" id="textfield2" size="25"></td>
    </tr>
  </tbody>
</table>
</div>
<input type="submit" value="Generate HTML" class="submit">
</div>





</form>

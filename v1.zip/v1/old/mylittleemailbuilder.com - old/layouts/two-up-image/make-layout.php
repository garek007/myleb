<?php

ini_set('display_errors', 0);
//loop to see how many fields are filled out



//$section_title = $_POST['section_title'];




//style
//$fontSize = '27px';
$font_size = $_POST['font_size'].'px';
//$sponsored = isset($_POST['sponsored']) ? 'SPONSORED CONTENT' : '';
//$bgcolor =  isset($_POST['bgcolor']) ? 'bgcolor="#dbe7ef"' : '';
$top_padding =  isset($_POST['top_padding']) ? '0' : '20px';
//$divider =  isset($_POST['divider']) ? '0' : 'border-top-width: 1px; border-top-style: solid; border-top-color: #dfe0e0;';
//$section_title_color = 'color: #005f86;';//434448 is the grey



//check for content
try {
			$left_headline = strtoupper($_POST['left_headline']);
			$left_description = nl2br(trim(stripslashes($_POST["left_description"])));
			$left_url = $_POST['left_url'];
			$left_image = $_POST['left_image'];
		}catch(Exception $e){
			echo 'ERROR: You must have content for the left side';			
		} 
		
try {
			$right_headline = strtoupper($_POST['right_headline']);
			$right_description = trim(stripslashes($_POST["right_description"]));
			$right_url = $_POST['right_url'];
			$right_image = $_POST['right_image'];
		}catch(Exception $e){
			$right_headline = '';
			$right_description = '';	
			$right_url = '';
			$right_image = '';
		}



if(isset($_POST['add_ga_tags'])){
	if($_POST['campaign_name']== 'custom'){
		$utm_campaign = $_POST['custom_campaign_name'];
	}else{
		$utm_campaign = trim($_POST[str_replace(' ','%20','utm_campaign')]);
	}
	
	//$utm_term = 'header';
	$utm_source = $_POST['traffic_source'];
	$utm_medium = $_POST['medium'];
	
	$dest_url.= '?utm_campaign='.$utm_campaign.'&utm_source='.$utm_source.'&utm_medium='.$utm_medium;
	
}






include 'lyt-2upimage.php';
echo $html;

?>

            
            
            
            
						


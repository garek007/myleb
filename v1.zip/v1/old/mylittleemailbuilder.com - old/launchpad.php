<?php
session_start();
require_once('config.php');
include "00-Includes/header.php";  

$email = $_SESSION['email'];

if($_POST){
	$deleteprojects = $_POST['delete'];
	foreach($deleteprojects as $projid){
		//echo $projid;
		$query = "DELETE FROM projects WHERE Project_Number='$projid'";
		$results = mysqli_query($con,$query);	
		
	}
	
}


?>

<div class="first-row row">
  <div class="cols_12-12">
  <?php if($_SESSION['auth']=='true'): ?>
      <h3>
      Hello <?php echo $email;  ?> 
    </h3>
    <h4>Start a new project or select from your existing projects.</h4>
  </div>
</div>
<div class="row">
  <div class="first-col cols_12-6">
    


    <h4>Your saved projects</h4>
    <?php
			$query = "SELECT Title,Project_Number FROM projects where
				Author='$email'";
		$results = mysqli_query($con,$query);	?>
			
		<form action="launchpad.php" method="post">
    <table><tbody>
<?php
		while($row = mysqli_fetch_assoc($results)){
		echo '<tr><td><input type="checkbox" name="delete[]" value="'.$row['Project_Number'].'" />&nbsp;</td><td><a href="buildemail.php?pnum='.$row['Project_Number'].'">'.$row['Title'].'</a></td></tr>';
		}
	?>
  </tbody></table>
	<br />
	<input type="submit" value="Delete checked projects" />
	</form>

  </div>
  <div class="cols_12-6">
  <h4>Start a new project.</h4>
      <form action="addproject.php" method="post">
      <input style="width:100%;" name="project_name" type="text"/>
      <input class="button" type="submit" value="New project" />
    </form>
    
    
    
    <h3>OR</h3>
    
    <strong><p>Create Shareable Content</p></strong>

<a href="layouts/shareablecontent/index.php"><img src="images/shareable.jpg" width="400" alt=""/> </a>
    
    
    
    
    <?php else: ?>
    You are not logged in, please go back and login. <a href="index.php"><- Back</a>
    <?php endif; ?>
  </div>
</div>
<?php include "00-Includes/footer.php"; ?>
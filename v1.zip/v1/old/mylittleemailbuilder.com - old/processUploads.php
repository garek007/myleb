<?php
//$uploadedFiles = $_FILES['file']['tmp_name'];
//echo $uploadedFiles;
//move_uploaded_file($uploadedFiles, "http://www.enjoysandiego.com/upload/new_whale.jpg");








$filename = explode(".",basename($_FILES["file"]["name"]));
$filename = $filename[0];

$fnamelength = strlen($filename);
//echo "basename is ".$filename." and length is ".$fnamelength;

if($fnamelength < 4){
	echo "100";
	return;
}


$target_dir = "upload/";

$target_file = $target_dir . basename($_FILES["file"]["name"]);

//echo 'target file is '.$target_file;

$uploadOk = 1;
$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
// Check if image file is a actual image or fake image

// Check if file already exists
if (file_exists($target_file)) {
    echo "200";
    $uploadOk = 0;
		return;
}
// Check file size
//if ($_FILES["file"]["size"] > 50000000) {
  //  echo "Sorry, your file is too large.";
    //$uploadOk = 0;
//}
// Allow certain file formats
if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
&& $imageFileType != "gif" ) {
    echo "300";
    $uploadOk = 0;
		return;
}
// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
    echo "Sorry, your file was not uploaded.";
// if everything is ok, try to upload file
} else {
    if (move_uploaded_file($_FILES["file"]["tmp_name"], $target_file)) {
        echo "The file ". basename( $_FILES["file"]["name"]). " has been uploaded.";
				$DisplayName = basename( $_FILES["file"]["name"]);
				$ET_file = "http://www.mylittleemailbuilder.com/upload/".basename( $_FILES["file"]["name"]);
				include '00-Includes/puttoportfolio.php';
				//add later error handling
				//if status ok, then return image url
				
				
    } else {
        echo "Sorry, there was an error uploading your file.";
    }
}





?>
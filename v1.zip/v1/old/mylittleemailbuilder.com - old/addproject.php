<?php
ob_start();
require_once('config.php'); 
if(mysqli_connect_errno()){
	echo "Sorry, there was a problem connecting to the database.";
	
}else{
	session_start();
	include "00-Includes/header.php";
	$email = $_SESSION['email'];
	$project_name = $_POST['project_name'];
	$_SESSION['project_name'] = $project_name;
	$sql = "INSERT INTO projects(Title,Author)
	VALUES ('".$project_name."','".$email."')";
	
	if($con->query($sql) === TRUE){
		//echo "New record created";
		$_SESSION['project_id'] = mysqli_insert_id($con);
		header('location:buildemail.php');
		//open project
	
	}else{
		echo "Error: " .$sql . "<br>" . $conn->error;
		
	}
	
	
	
	
}
/*  NEED TO MAKE THIS GRAB THE TITLE FROM THE LAUNCHPAD BEFORE WRITING TO DB, ALSO,
MAKE SURE THAT THE PRIMARY KEY IN DB IS SET TO AUTO INCREMENT.

*/





include "00-Includes/footer.php";
ob_flush();
 ?>

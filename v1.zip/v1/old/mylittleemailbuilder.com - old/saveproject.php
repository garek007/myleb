<?php
ob_start();
require_once('config.php'); 

if(mysqli_connect_errno()){
	echo "failed to connect";
	
}else{
	session_start();
	
	
	
	$project_id = isset($_SESSION['project_id']) ? $_SESSION['project_id'] : $_REQUEST['pnum'];
	$project_name = $_SESSION['project_name'];
	$data = $_REQUEST['mydata'];
	$data = $con->real_escape_string($data);
	
	$sql = "UPDATE projects
	SET Body = '".$data."'
	WHERE Project_Number = '".$project_id."'";
	
	if($con->query($sql) === TRUE){
		//echo $data;
		echo "Project Saved";

		//echo $data;
		//echo "pname is ".$project_name;
	}else{
		echo "Error: " .$sql . "<br>" . $con->error;
		
	}

	
	
	
	 }

ob_flush();
?>


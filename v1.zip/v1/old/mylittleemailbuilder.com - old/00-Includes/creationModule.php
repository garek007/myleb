<?php
$create = <<<EOT
<div class="raw block">



<p style="width:100%;">Add new module.....</p>

<p><a href="layouts/header-600-wide/index.php" id="header-600" class="fullhtml" data-folder="header-600-wide">600 Wide Header</a>
<a href="layouts/header-540-wide/index.php" id="layouts/540wide-header/index.php" class="fullhtml" data-folder="header-540-wide">540 Wide Header</a>
<a href="layouts/events/index.php" id="events" class="fullhtml" data-folder="events">Events</a>
<a href="layouts/four-up-image/index.php" id="image4up" class="fullhtml" data-folder="four-up-image">4 Up Image</a>
<a href="layouts/two-up-image/index.php" id="image2up" class="fullhtml" data-folder="two-up-image">2 Up Image</a>
<a href="layouts/one-up-image/index.php" id="image1up" class="fullhtml" data-folder="one-up-image">1 Up Image</a>
<a href="layouts/divider/index.php" id="divider" class="fullhtml" data-folder="divider">Divider Line</a>
<a href="layouts/headline/index.php" id="headline" class="fullhtml" data-folder="headline">Section Headline</a>


</p>

</div>
EOT;
?>
<div class="first-row row">
<h2>4-up Module Builder</h2>
<img class="left" src="/mylittleemailbuilder2/images/4uplayout.jpg" />
</div>


<form class="moduleform" title="tttdform" name="tttdform" action="layouts/<?php echo $_GET['module'] ?>/make-layout.php" method="post">


 <?php include '../../00-Includes/ga-fields.html'; ?>

<div class="row">

<br>


<div class="first-col cols_12-6">

<p>    <label for="medium">Header Text</label>
  <input name="header" type="text" size="50" value="FROM THE SAN DIEGO TRAVEL BLOG"></p>
</div>

</div>

<div class="row">
<div class="first-col cols_12-3">
<h4>Slot 1</h4>
<label for="url">Image URL</label>
<input class="text drop-area" name="ImageUrl[]" type="text" size="25">
<label for="Desc">Description</label>
<input class="text" name="Description[]" type="text"  size="25">
<label for="Durl">Destination URL</label>
<input class="text" name="Durl[]" type="text" id="textfield2" size="25">
</div>

<div class="cols_12-3">
<h4>Slot 2</h4>
<label for="url">Image URL</label>
<input class="text drop-area" name="ImageUrl[]" type="text" size="25">
<label for="Desc">Description</label>
<input class="text" name="Description[]" type="text"  size="25">
<label for="Durl">Destination URL</label>
<input class="text" name="Durl[]" type="text" id="textfield2" size="25">
</div>

<div class="cols_12-3">
<h4>Slot 3</h4>
<label for="url">Image URL</label>
<input class="text drop-area" name="ImageUrl[]" type="text" size="25">
<label for="Desc">Description</label>
<input class="text" name="Description[]" type="text"  size="25">
<label for="Durl">Destination URL</label>
<input class="text" name="Durl[]" type="text" id="textfield2" size="25">
</div>

<div class="cols_12-3">
<h4>Slot 4</h4>
<label for="url">Image URL</label>
<input class="text drop-area" name="ImageUrl[]" type="text" size="25">
<label for="Desc">Description</label>
<input class="text" name="Description[]" type="text"  size="25">
<label for="Durl">Destination URL</label>
<input class="text" name="Durl[]" type="text" id="textfield2" size="25">
</div>




<input type="submit" value="Generate HTML" class="submit">
</div>





</form>

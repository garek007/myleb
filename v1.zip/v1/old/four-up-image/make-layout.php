<?php

function make_127wide_block($url,$description,$imageUrl){
	return '
<table width="100%" border="0" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td class="imagecont" style="padding-bottom: 10px;"><a href="'.$url.'"><img class="fullwidth" src="'.$imageUrl.'" border="0" style="display: block; height: auto !important;" width="127" /></a></td>
</tr>
<tr>
<td class="description" align="left" style="font-family: Helvetica, Arial, sans-serif; font-size: 12px; padding-top: 5px;"><a href="'.$url.'" style="color: #434448;">'.$description.'</a></td>
</tr>
</tbody>
</table>	
	';	
}

ini_set('display_errors', 0);
//loop to see how many fields are filled out









//check for content
try {
	
			$Desc = $_POST['Description'];
			$dest_url = $_POST['Durl'];
			$Iurl = $_POST['ImageUrl'];
		}catch(Exception $e){
			echo 'ERROR: You must have some content';			
		} 
		
		
$slot= array();		
for($i=0;$i<count($dest_url);$i++){
	if(isset($_POST['add_ga_tags'])){
		if($_POST['campaign_name']== 'custom'){
			$utm_campaign = $_POST['custom_campaign_name'];
		}else{
			$utm_campaign = trim($_POST[str_replace(' ','%20','utm_campaign')]);
		}
		
		//$utm_term = 'header';
		$utm_source = $_POST['traffic_source'];
		$utm_medium = $_POST['medium'];
		
		$dest_url[$i].= '?utm_campaign='.$utm_campaign.'&utm_source='.$utm_source.'&utm_medium='.$utm_medium;
	
	}
	
	
	$slot[$i] = make_127wide_block($dest_url[$i],$Desc[$i],$Iurl[$i]);
	

}
		








include 'lyt-4upimage.php';
echo $html;


?>

            
            
            
            
						


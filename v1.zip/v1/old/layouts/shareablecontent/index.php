<?php 


$pageTitle = "Shareable Content Complete Email Builder"; 
$date = date('md');

 include "../../00-Includes/header.php"; 
?>

<div class="first-row row">
<h2><?php echo $pageTitle; ?></h2>
<img class="left" src="images/shareable.jpg" />
</div>


<form title="tttdform" name="tttdform" action="make-layout.php" method="post">






<div class="row">
<div class="first-col cols_12-6 column">
	<label for="medium">ExactTarget Email Name<span class="required">*</span></label>
  <input name="et_email_name" type="text" size="30" value="SHAREABLE-CONTENT-2016<?php echo $date; ?>">
</div>



<div class="cols_12-6 column">
	<label for="medium">ExactTarget Email Subject<span class="required">*</span></label>
  <input name="et_subject" type="text" size="30" value="Shareable Content:">
</div>
<div class="cols_12-4"></div>


</div>

<div class="row">
	<div class="first-col cols_12-4 column">    
	<label for="medium">Title<span class="required">*</span></label>
  <input name="header" type="text" size="30">
  </div>
  <div class="cols_12-4 column">
    <label for="medium">Link to Share<span class="required">*</span></label>
  	<input name="share_link" type="text" size="30">
  </div>
  <div class="cols_12-4 column">
  <label for"whoismakingthis">I am</label>
  <select style="float:left;" name="whoismakingthis" id="whoismakingthis">
    <option value="custom">--who are you--</option>
    <option value="iambrent" id="iambrent">Brent</option>
    <option value="iamnick" id="iamnick" >Nick</option>
  </select>
	</div>
</div>

<div class="row">
  <div class="first-col cols_12-8 column">    
    <label for="medium">Description</label>
    <textarea name="description" cols="60" rows="5"></textarea></div>  
  </div>
</div>
<div class="row">
  <div class="first-col cols_12-12 column">
    <label for="medium">Twitter Lead-in<span class="required">*</span></label>
  	<textarea name="twitter_text" cols="60" rows="2" id="twitter_text" type="text"></textarea>
    <div><span id="charcount">120</span> Characters Remaining</div>
  </div> 
</div>
<div class="row">
  <div class="first-col cols_12-4 column">
    <label for="medium">LinkedIn Title<span class="required">*</span></label>
  	<input name="linkedin_title" type="text" size="30">
  </div>  
  <div class="cols_12-4 column"> 
    <label for="medium">LinkedIn Source</label>
  	<input name="linkedin_source" type="text" size="30">
  </div>    
  <div class="cols_12-4 column">    
  <label for="medium">LinkedIn Summary</label>
  <textarea name="linkedin_summary" cols="60" rows="5"></textarea>
  </div> 
</div>

<div class="row">
  <div class="first-col cols_12-6 column">
  <label for="medium">Image URL (must be precropped to 540 pixels wide)</label>
          <input class="text drop-area" name="Iurl" type="text" size="25">
  </div>
</div>

<div class="row">
<input style="clear:both;float:none;" type="submit" value="Generate HTML" class="submit">
</div>



</form>
<?php include "../../00-Includes/footer.php"; ?>

<div class="contentarea_container" data-module="two-up-image">
<table class="contentarea twocol" width="100%" border="0" cellspacing="0" cellpadding="0">
	<tbody>
		<tr>
			<td class="fullpad bgcolor toppad" style="padding:15px 30px 30px;">
			<table width="100%" border="0" cellspacing="0" cellpadding="0">
				<tbody>
					<tr>
						<td class="blockme droppable" style="padding-right: 5px;" width="50%" valign="top" align="left">
            
            
            
            
						<table width="100%" border="0" cellspacing="0" cellpadding="0" class="draggable">
							<tbody>
								<tr>
									<td class="imagecont left" style="padding-bottom: 10px;">
                  <a class="dest_url left" href="#"><img data-width="265" data-height="150" class="fullwidth editableImage drop-area left" src="/images/MyLEB-placeholder_265x150.jpg" border="0" style="display: block; height: auto !important;" width="265" /></a></td>
								</tr>
								<tr>
									<td class="title" align="left"><table width="100%" border="0" cellspacing="0" cellpadding="0">
									  <tbody>
									    <tr>
									      <td><a class="left_headline dest_url left" href="$left_url" style="font-size: 18px; color: #434448; text-decoration: none;">
									<font style="font-family: 'Arial Narrow', Helvetica, sans-serif;"> 
									<!--[if (!mso 14)&(!mso 15)]><!--> 
									<font style="font-family: Oswald, 'Arial Narrow', Helvetica, Arial, sans-serif;"> 
									<!--<![endif]--> 
						<span class="editable headline maintitle unedited">LEFT HEADLINE OR TITLE</span>

									<!--[if (!mso 14)&(!mso 15)]><!--> 
									</font> 
									<!--<![endif]-->
									</font>
								</a></td>
									      <td valign="top" align="right"><a class="dest_url left" href="#"><img class="link" src="http://image.exct.net/lib/fe6e15707166047a7715/m/1/sdta_nl_arrow_dark.png" vspace="0" width="20" border="0" /></a><img src="http://image.updates.sandiego.org/lib/fe9e15707566017871/m/2/spacer-13.gif" border="0" /></td>
								        </tr>
								      </tbody>
								    </table></td>
								</tr>
								<tr>
									<td class="description left" align="left" style="font-family: Helvetica, Arial, sans-serif; font-size: 12px; color: #434448; padding-top: 5px;">
                  
                  <span class="editable textarea left unedited">Left Description goes here, click here to type. Suggested maximum for this module is 300 characters.</span>

									</td>
								</tr>
							</tbody>
						</table>
						</td>
						<td class="blockme droppable" style="padding-left: 5px;" width="50%" valign="top" align="left">





	<table width="100%" border="0" cellspacing="0" cellpadding="0" class="right_table draggable">
							<tbody>
								<tr>
									<td class="imagecont right" style="padding-bottom: 10px;">
                 
                  <a class="dest_url right" href="#"><img data-width="265" data-height="150" class="fullwidth editableImage drop-area right" src="/images/MyLEB-placeholder_265x150.jpg" border="0" style="display: block; height: auto !important;" width="265" /></a></td>
								</tr>
								<tr>
									<td class="title" align="left"><table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tbody>
    <tr>
      <td><a class="right_headline dest_url right" href="#" style="font-size: 18px; color: #434448; text-decoration: none;">
									<font style="font-family: 'Arial Narrow', Helvetica, sans-serif;"> 
									<!--[if (!mso 14)&(!mso 15)]><!--> 
									<font style="font-family: Oswald, 'Arial Narrow', Helvetica, Arial, sans-serif;"> 
									<!--<![endif]--> 
				<span class="editable headline maintitle unedited">RIGHT HEADLINE OR TITLE</span>
									<!--[if (!mso 14)&(!mso 15)]><!--> 
									</font> 
									<!--<![endif]-->
									</font>
									</a></td>
      <td valign="top" align="right"><a class="dest_url right" href="#"><img class="link" src="http://image.exct.net/lib/fe6e15707166047a7715/m/1/sdta_nl_arrow_dark.png" vspace="0" width="20" border="0" /></a><img src="http://image.updates.sandiego.org/lib/fe9e15707566017871/m/2/spacer-13.gif" border="0" /></td>
    </tr>
  </tbody>
</table>
</td>
								</tr>
								<tr>
									<td class="description right" align="left" style="font-family: Helvetica, Arial, sans-serif; font-size: 12px; color: #434448; padding-top: 5px;"><span class="editable textarea right unedited">Right description goes here, click here to type. Suggested maximum for this module is 300 characters.</span>
									</td>
								</tr>
							</tbody>
						</table>










					</td>
					</tr>
				</tbody>
			</table>
			</td>
		</tr>
	</tbody>
</table>

<?php include "controls.html"; ?>
</div>

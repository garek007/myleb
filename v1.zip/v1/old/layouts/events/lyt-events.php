<?php $layout = "divider"; ?>
<div class="contentarea_container" data-module="events">
<table class="contentarea" width="100%" cellspacing="0" cellpadding="0" border="0">
  <tbody>
    <tr>
      <td style="padding-top: 0px;"><table width="100%" cellspacing="0" cellpadding="0" border="0">
          <tbody>
            <tr>
              <td bgcolor="#fddea6" background="http://image.exct.net/lib/fe6e15707166047a7715/m/1/sdta_nl_small_texture_tan.jpg" style="padding: 25px 30px 15px;" class="fullpad"><table width="100%" cellspacing="0" cellpadding="0" border="0" class="headlinebar">
                  <tbody>
                    <tr>
                      <td valign="top" align="left" style="font-size: 18px; color: #005f86;" class="section_title"><font style="font-family: 'Arial Narrow', Helvetica, sans-serif;"> 
                        <!--[if (!mso 14)&(!mso 15)]><!--> 
                        <font style="font-family: Oswald, 'Arial Narrow', Helvetica, Arial, sans-serif;"> 
                        <!--<![endif]--> 
                        <span class="editable">UPCOMING EVENTS</span> 
                        <!--[if (!mso 14)&(!mso 15)]><!--> 
                        </font> 
                        <!--<![endif]--></font></td>
                      <td valign="top" align="right" style="font-size: 12px;" class="calltoaction"><a style="text-decoration: none; color: #979597;" href="#"> <font style="font-family: 'Arial Narrow', Helvetica, sans-serif;"> 
                        <!--[if (!mso 14)&(!mso 15)]><!--> 
                        <font style="font-family: Oswald, 'Arial Narrow', Helvetica, Arial, sans-serif;"> 
                        <!--<![endif]--> 
                        
                        <span class="editable">SEE ALL TOP THINGS TO DO</span> 
                        
                        <!--[if (!mso 14)&(!mso 15)]><!--> 
                        </font> 
                        <!--<![endif]--></font> </a></td>
                    </tr>
                  </tbody>
                </table>
                <table width="100%" cellspacing="0" cellpadding="0" border="0" class="eventcal">
                  <tbody>
                    <!-- START: ROW -->
                    <tr>
                      <td width="50%" valign="top" align="left" style="padding-right: 5px; padding-top: 20px; padding-bottom: 20px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: #dec79e;" class="blockme left">
                      
                      
                      
                      
                      
                      <table cellspacing="0" cellpadding="0" border="0" class="event draggable">
                      
                          <tbody>
                            <tr>
                              <td width="60" align="center" valign="top">
                              <i class="fa fa-link link left fa-1x" aria-hidden="true"></i>
                              <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                  <tbody>
                                    <tr>
                                      <td width="60" bgcolor="#ee7421" align="center" style="font-size: 15px; letter-spacing: 0.5px; line-height: 20px; color: #ffffff; padding: 10px 0px; width: 60px;">
                                      <div class="eventDatepicker fa fa-calendar"></div>
                                      <div class="eventDatepickerRange fa fa-calendar-minus-o"></div>
                                      <font style="font-family: 'Arial Narrow', Helvetica, sans-serif;"> 
                                     	
                                        <!--[if (!mso 14)&(!mso 15)]><!--> 
                                        <font style="font-family: Oswald, 'Arial Narrow', Helvetica, Arial, sans-serif;"> 
                                        <!--<![endif]--> 
                                        <span class="date editable textarea">THRU<br>
                                        JUL 7</span><!--[if (!mso 14)&(!mso 15)]><!--> 
                                        </font> 
                                        <!--<![endif]--></font></td>
                                    </tr>
                                  </tbody>
                                </table></td>
                              <td style="padding-left: 15px; padding-right: 7px;"><table width="100%" cellspacing="0" cellpadding="0" border="0">
                                  <tbody>
                                    <tr>
                                      <td align="left" class="title"><a style="font-size: 16px; letter-spacing: 0.3px; line-height: 22px; color: #434448; text-decoration: none;" href="http://www.sandiego.org/members/theatre/the-old-globe/events/first-folio-the-book-that-gave-us-shakespeare.aspx?utm_campaign=Top%20Things%20to%20Do&utm_source=2016_jun_7-12&utm_medium=email&utm_term=event&utm_content=first_folio_the_book_that_gave_us_shakespeare"> <font style="font-family: 'Arial Narrow', Helvetica, sans-serif;"> 
                                        <!--[if (!mso 14)&(!mso 15)]><!--> 
                                        <font style="font-family: Oswald, 'Arial Narrow', Helvetica, Arial, sans-serif;"> 
                                        <!--<![endif]--> <span class="editable textarea eventname">EVENT TITLE</span><!--[if (!mso 14)&(!mso 15)]><!--> 
                                        </font> 
                                        <!--<![endif]--></font> </a></td>
                                    </tr>
                                  </tbody>
                                </table></td>
                            </tr>
                          </tbody>
                        </table></td>
                      <td width="50%" valign="top" align="left" style="padding-left: 5px; padding-top: 20px; padding-bottom: 20px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: #dec79e;" class="blockme right">
                      
                      
                      
                      
                      <table cellspacing="0" cellpadding="0" border="0" class="event draggable">
                      
                          <tbody>
                            <tr>
                              <td width="60" align="center" valign="top">
                              <i class="fa fa-link link left fa-1x" aria-hidden="true"></i>
                         
                              <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                  <tbody>
                                    <tr>
                                      <td width="60" bgcolor="#ee7421" align="center" style="font-size: 15px; letter-spacing: 0.5px; line-height: 20px; color: #ffffff; padding: 10px 0px; width: 60px;">
                                      <div class="eventDatepicker fa fa-calendar"></div>
                                      <div class="eventDatepickerRange fa fa-calendar-minus-o"></div>
                                      <font style="font-family: 'Arial Narrow', Helvetica, sans-serif;"> 
                                    
                                        <!--[if (!mso 14)&(!mso 15)]><!--> 
                                        <font style="font-family: Oswald, 'Arial Narrow', Helvetica, Arial, sans-serif;"> 
                                        <!--<![endif]--><span class="date editable textarea">JUN<br>
                                        9-12</span> 
                                        
                                        <!--[if (!mso 14)&(!mso 15)]><!--> 
                                        </font> 
                                        <!--<![endif]--></font></td>
                                    </tr>
                                  </tbody>
                                </table></td>
                              <td style="padding-left: 15px; padding-right: 7px;"><table width="100%" cellspacing="0" cellpadding="0" border="0">
                                  <tbody>
                                    <tr>
                                      <td align="left" class="title"><a style="font-size: 16px; letter-spacing: 0.3px; line-height: 22px; color: #434448; text-decoration: none;" href="http://www.sandiego.org/events/sports/surfing-america.aspx?utm_campaign=Top%20Things%20to%20Do&utm_source=2016_jun_7-12&utm_medium=email&utm_term=event&utm_content=surfing_america_2016_usa_surfing_championships"> <font style="font-family: 'Arial Narrow', Helvetica, sans-serif;"> 
                                        <!--[if (!mso 14)&(!mso 15)]><!--> 
                                        <font style="font-family: Oswald, 'Arial Narrow', Helvetica, Arial, sans-serif;"> 
                                        <!--<![endif]--> <span class="editable textarea eventname">EVENT TITLE</span><!--[if (!mso 14)&(!mso 15)]><!--> 
                                        </font> 
                                        <!--<![endif]--></font> </a></td>
                                    </tr>
                                  </tbody>
                                </table></td>
                            </tr>
                          </tbody>
                        </table></td>
                    </tr>
                    <!-- END: ROW --> 
                  </tbody>
                </table></td>
            </tr>
          </tbody>
        </table></td>
    </tr>
  </tbody>
</table>
<?php include $_SERVER['DOCUMENT_ROOT']."/00-Includes/controlsmap.php"; ?>


</div>
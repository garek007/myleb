<?php

//ini_set('display_errors', 0);
//loop to see how many fields are filled out

//find campaign name if any



$section_title = $_POST['section_title'];



$section_title_color = 'color: #005f86;';//434448 is the grey





include 'lyt-headline.php';

echo $html;
/*
include "../../00-Includes/header.php"; 
echo '<div class="first-row row">
<p style="clear:both;display:block;padding-top:30px;">This is your email preview. If you like it, grab the code from the text box at bottom. If you don\'t, never fear, hit the back button and your information will still be there.</p>
<div class="email_layout">';

echo '</div></div>';
include '../../00-Includes/rawoutput.php';
include "../../00-Includes/footer.php";
*/
?>

            
            
            
            
						


<?php $pageTitle = "540 Wide Image Header Builder"; ?>

<div class="first-row row">
<h2><?php echo $pageTitle; ?></h2>

</div>

<form class="moduleform" title="tttdform" name="tttdform" id="htmlform" action="make-layout.php" method="post">









<div class="row">
<label for="section_title">Section Title</label>
<input class="text" name="section_title" type="text" size="50" value="INSIDE SCOOP">

<input type="submit" value="Generate HTML" class="submit">
</div>




</form>

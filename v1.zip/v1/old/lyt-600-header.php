<?php
$html = <<<EOT
<div class="contentarea_container" data-module="header-600-wide">
<table class="contentarea" width="100%" border="0" cellspacing="0" cellpadding="0">
	<tbody>
		<tr>
			<td><a href="$dest_url"><img class="fullwidth" src="$image_url" border="0" style="display: block; height: auto !important;" /></a></td>
		</tr>
		<tr>
			<td class="fullpad" bgcolor="#005f86" style="padding: 15px 30px;" background="http://image.exct.net/lib/fe6e15707166047a7715/m/1/sdta_nl_small_texture_blue.jpg">
			<table width="100%" border="0" cellspacing="0" cellpadding="0">
				<tbody>
					<tr>
						<td class="headline" align="left" valign="top" style="font-size: $font_size; line-height: 31px; letter-spacing: 0.3px;"><table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tbody>
    <tr>
      <td style="font-size: $font_size; line-height: 31px; letter-spacing: 0.3px;"><a class="dest_url" href="$dest_url" style="color: #ffffff; text-decoration: none;">

			  <font style="font-family: 'Arial Narrow', Helvetica, sans-serif;"> 
				<!--[if (!mso 14)&(!mso 15)]><!--> 
				<font style="font-family: Oswald, 'Arial Narrow', Helvetica, Arial, sans-serif;"> 
				<!--<![endif]--> 
				$headline          
				<!--[if (!mso 14)&(!mso 15)]><!--> 
				</font> 
				<!--<![endif]-->
				</font>

			</a></td>
      <td align="right" valign="top"><a href="$dest_url" style="text-decoration: none;">
   
      <img src="http://image.updates.sandiego.org/lib/fe9e15707566017871/m/2/spacer-13.gif" width="15" border="0" /><img src="http://image.exct.net/lib/fe6e15707166047a7715/m/1/sdta_nl_arrow_white.png" vspace="6" align="bottom" style="vertical-align: bottom;" border="0" /></a></td>
    </tr>
  </tbody>
</table>
</td>
					</tr>
					<tr>
						<td class="subheadline" align="justify" style="font-size: 18px; color: #80b8cb; letter-spacing: 0.3px; padding-top: 5px; text-align: justify;"><font style="font-family: 'Arial Narrow', Helvetica, sans-serif;"> 
						<!--[if (!mso 14)&(!mso 15)]><!--> 
						<font style="font-family: Oswald, 'Arial Narrow', Helvetica, Arial, sans-serif;"> 
						<!--<![endif]--> 
		 $description
						<!--[if (!mso 14)&(!mso 15)]><!--> 
						</font> 
						<!--<![endif]--></font></td>
					</tr>
				</tbody>
			</table>
			</td>
		</tr>
	</tbody>
</table>
<div class="remove"></div><div class="edit"></div><div class="drag"></div>
</div>
EOT;
?>
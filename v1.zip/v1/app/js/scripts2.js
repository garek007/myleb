// JavaScript Document


//my code


var monthNames = ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"];
var monthNums = ["01","02","03","04","05","06","07","08","09","10","11","12"];
var monthNamesFull = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
var d = new Date();
var todaysDate = d.getDate();
var todaysWeekday = d.getDay();
var monthAbbr = monthNames[d.getMonth()];
var monthNum = monthNums[d.getMonth()];
var nextMonthAbbr = monthNames[d.getMonth() + 1];
var fullMonthName = monthNamesFull[d.getMonth()];
var year = d.getFullYear();
var startDate = getNearestTuesday(todaysDate, todaysWeekday);
var nextFriday = getNearestFriday(todaysDate,todaysWeekday);
var endDate = Number(startDate + 5);
var yearMonDay = year+"-"+(monthNums[d.getMonth()])+"-"+todaysDate;
var monDayYear = fullMonthName + " " + todaysDate + ", " + year;

function getNearestTuesday(t, wd) {
    var sDate; //this will be set to Tuesday below.
    switch (wd) {
        case 0:
            sDate = t + 2;
            break;
        case 1:
            sDate = t + 1;
            break;
        case 2:
            sDate = t;
            break;
        case 3:
            sDate = t - 1;
            break;
        case 4:
            sDate = t - 2;
            break;
        case 5:
            sDate = t - 3;
            break;
        case 6:
            sDate = t - 4;
            break;
        default:
            Date = t;
    }
    return sDate;
}
function getNearestFriday(t, wd) {
    var sDate; //this will be set to Friday below.
    switch (wd) {
        case 0:
            sDate = t + 5;
            break;
        case 1:
            sDate = t + 4;
            break;
        case 2:
            sDate = t+3;
            break;
        case 3:
            sDate = t + 2;
            break;
        case 4:
            sDate = t + 1;
            break;
        case 5:
            sDate = t;
            break;
        case 6:
            sDate = t - 1;
            break;
        default:
            Date = t;
    }
    return sDate;
}
function pad(n) {
    return (n < 10) ? ("0" + n) : n;
}


function tagForGA(url, tmp) {
    var today = new Date();
    if (tmp == "tttd") {
        var cname = "Top Things to Do";
        var source = $('#utm_source').val();//year + '_' + monthAbbr + '_' + startDate + '-' + endDate;
    } else if (tmp == "monthly") {
        var cname = "Consumer Newsletter Monthly";
        var source = monthNames[d.getMonth() + 1];
    }
    var taggedURL = url + '?utm_campaign=' + cname + '&utm_source=' + source + '&utm_medium=email';
    return taggedURL;
}

function getQueryVariable(variable) {
    var query = window.location.search.substring(1);
    var vars = query.split("&");
    for (var i = 0; i < vars.length; i++) {
        var pair = vars[i].split("=");
        if (pair[0] == variable) {
            return pair[1];
        }
    }
    return (false);
}
//maybe there's a better way to do this, I need to call this function 
//every.single.time an event happens because even after a drag N drop
//jquery doesn't see the new draggable items without initializing them again
function doDraggable() {
    $('.numbered-list').find('.numbered-list-container').sortable({
        handle: ".drag",
        stop: function(event, ui) {
            var $listItem = $(this).find('.numbered-list-item');
            $.each($listItem, function(index) {      
                $(this).find('.number').text(index + 1);
            });
        }
    });
    $(".draggable").draggable({
        revert: function(event, ui) {
            $('.draggedFrom').removeClass('draggedFrom');
            return true;
        },
        start: function(event, ui) {
            var $p = $(this).parent();
            $p.addClass('draggedFrom');
            var $html = $p.html();

            //$p.droppable('disable');

            $('.blockme, .nopad').not($p).droppable({
                hoverClass: "activated",
                drop: function(event, ui) {
									if(ui.draggable.find('.nopad').hasClass("padLeft")){
										ui.draggable.find('.nopad').css({'padding-right':'15px','padding-left':'0'}).addClass('padRight').removeClass('padLeft');
									}else if(ui.draggable.find('.nopad').hasClass("padRight")){
										ui.draggable.find('.nopad').css({'padding-left':'15px','padding-right':'0'}).addClass('padLeft');
									}
									
							
                    var $html = $(this).html();
                    $(this).empty();
                    //ui.draggable.detach().appendTo($(this)).removeAttr('style');
                    ui.draggable.detach().appendTo($(this)).css({
                        top: 0,
                        left: 0,
                        position: 'relative'
                    });
                    $('.draggedFrom').html($html).removeClass('draggedFrom');
                    $('.ui-droppable').droppable("destroy");
                    //$(this).removeClass('activated');
                    doDraggable();
                }
            });
            //console.log($html);
        }




    });
}
$(document).ajaxComplete(function() {
    doDraggable();
});
$(document).ready(function() {
    doDraggable();
	var $container = $("#container");

	if($container.hasClass("new_project")){
		
		var $tmp = $container.data("template");
		$.get("templates/"+$tmp+".html", function(data) {
				
					$container.append(data);	
					$container.removeClass("new_project");
					$(".senddate").text(fullMonthName + " " + nextFriday + ", " + year);		
					
					
		});
		
		
	}
	$('body').on('click', '#add-ga-tags', function() {

			$('#ga-fields').slideDown({
					duration: 1000,
					easing: 'swing'
			});

	});

    $('body').on('change', '#template', function() {
        var id = this.value;
        if (id == "tttd") {
            var cname = "Top Things to Do";
            var source = year + "_" + monthAbbr + "_" + startDate + "-" + endDate;
        } else {
            var cname = "Consumer Monthly";
            var source = nextMonthAbbr;

        }
        $("#utm_campaign").val(cname);
        $("#utm_source").val(source);

    });
		$("#project_list").tablesorter();

    $('body').on('change', '#tag4ga', function() {
        if (!$('#gaFields').is(':visible')) {
            $('#gaFields').fadeIn();


        } else {
            $('#gaFields').fadeOut();

        }
    });
    //Drag n Drop Stuff
    $(document).delegate(".drop-area", 'dragenter', function(e) {
        e.preventDefault();
        //$(this).css('background', '#BBD5B8');
        $(this).css('border', '1px solid red');
    });
    $(document).delegate(".drop-area", 'dragleave', function(e) {
        e.preventDefault();
        $(this).css('border', 'none');
    });
    $(document).delegate(".drop-area", 'dragover', function(e) {
        e.preventDefault();
    });
		var $uploadCrop;
		var imageName;
		var $uploadLocation = 'exacttarget';
    $(document).delegate('.drop-area', 'drop', function(e) {
			if($(this).is('.cloudinary')){$uploadLocation = 'cloudinary';}
        //$(this).css('background', '#D8F9D3');
        $(this).css('border', 'none');
        e.preventDefault();
        //var image = e.originalEvent.dataTransfer.files;
				console.log(e.originalEvent.dataTransfer.files);
        //createFormData(image);
        $(this).addClass('activeImage');
        var $w = $(this).data('width');
        var $h = $(this).data('height');
        var image = e.originalEvent.dataTransfer.files[0];
        //console.log(e.originalEvent.dataTransfer.files[0]);
        //console.log(e.originalEvent.dataTransfer.files[1]);
        imageName = Date.now() + image.name;
        
        $('#cropbox').show();
				
        $uploadCrop = $('#cropbox').croppie({
            viewport: {
                width: $w,
                height: $h
            },
            boundary: {
                width: $w + 100,
                height: $h + 100
            }
        });
				$('#viewport_height').slider('value', $(".cr-viewport").outerHeight());
				$(".viewport_height_value").text($(".cr-viewport").outerHeight());
        // if (input.files && input.files[0]) {
        var reader = new FileReader();
				console.log(reader);
        reader.onload = function(e) {
						console.log('wtf '+imageName);
            $uploadCrop.croppie('bind', {
                url: e.target.result
            });
        }
        reader.readAsDataURL(image);
        // }

        $('.upload-cancel').on('click', function(ev) {
            $('#cropbox').fadeOut('fast');
            $uploadCrop.croppie('destroy');
            $('.activeImage').css('border', 'none');
            $('.activeImage').removeClass('activeImage');

        });
    });

		$('.upload-result').on('click', function(ev) {
				$uploadCrop.croppie('result', {
						type: 'canvas',
						size: 'viewport',
						format: 'jpeg'
				}).then(function(resp) {
					console.log(typeof imageName);
						console.log("right after then "+imageName);

						$('.fa-spinner').fadeIn();
						$.ajax({
								url: "/processUploads2.php",
								type: "POST",
								data: {
										'file': resp,
										'imagename': imageName,
										'uploadLocation':$uploadLocation
								},
								dataType : 'json',
						}).done(function(data) {
								console.log("inside done function "+data);
									console.log("my var is "+data['url']);
								$('#cropbox').fadeOut('slow', function() {
										//$('.activeImage').attr('src', 'http://image.updates.sandiego.org/lib/fe9e15707566017871/m/4/' + imageName);
										$('.activeImage').attr('src', data['url']);
										$('.activeImage').removeClass('activeImage');
										$uploadCrop.croppie('destroy');
										$('.fa-spinner').fadeOut();
								});
						}).fail(function(data) {
								alert("there was a problem uploading your image");
								console.log(data);
						});
				});
		});


    $('#twitter_text').on('keyup', function() {
        var charsLeft = 120 - $(this).val().length;
        $('#charcount').text(charsLeft);
        if (charsLeft < 10) {
            $('#charcount').css({
                'color': 'red'
            });
        }
    });


    var w = $(window).width() - 200;
    var h = $(window).height() - 100;
    $('#load').dialog({
        resizable: false,
        height: h,
        width: w,
        dialogClass: 'noTitle',
        modal: true,
        autoOpen: false,
        resizable: true,
        position: {
            my: "left top",
            at: "left+20 top+20",
            of: window
        },
        close: function(event, ui) {
            $('#loadContent').empty();
            //$(this).dialog('destroy');
        }
    });

    $("body").on("click","#grabTheCode, .fa-clipboard",function() {
			if($("#container").find(".unedited").length){
				alert("Whoa, it looks like you have some unfilled content areas");
				return;
			}
			var theCode = '';
			if($(this).is("#grabTheCode")){
				$('.contentarea_container').each(function() {
						$(this).addClass("wrapped");
						theCode += $(this).find('.contentarea').wrap('<p/>').parent().html();
				});
			}else{
				$(this).parent().addClass("wrapped");
				theCode = $(this).parent().find('.contentarea').wrap('<p/>').parent().html();
			}	
			$('#loadContent').html('<textarea id="rawhtml" cols="130" rows="30" style="font-family:monospace">' + theCode + '</textarea>');
			$('.ui-dialog').addClass('grabcode');
			$('#load').dialog('open');			
    });
    $('body').on('click', '.grabcode .ui-icon-closethick', function() {
        $('.wrapped').removeClass("wrapped").find('.contentarea').unwrap();
        $('.ui-dialog').removeClass('grabcode');
    });		
    $('#syncToET').click(function() {
		
        var theCode = '';
        $('.contentarea_container').each(function() {
            theCode += $(this).find('.contentarea').wrap('<p/>').parent().html();
        });

			$.ajax({
					type: "POST",
					dataType: "text",
					url: "00-Includes/addUpdate-ET.php",
					data: {
						html:theCode,
						update:true,
						et_id:$("#exacttarget_id").val()
					}
			}).done(function(data) {
					console.log(data);
			});					
    });		
	$(".type").click(function(){
		console.log($(this).is("#type_htmlpaste"));
		
		if($(this).is("#type_htmlpaste") &&  !$(".hidden").is(":visible")){
			$(".hidden").fadeIn();
		}else{
			$(".hidden").fadeOut();
		}
		});
var folderID;		
	$("#select_template").change(function(e){
			var $val = $(this).val()	;
			switch($val){
				case "Press Release": 
					$("#project_name").val(yearMonDay+" - Press Release - ");
					$("#et_folder_input").val(40560);
					$("#template").val("pressrelease");
					break;				
				case "execReport": 
					$("#project_name").val(year +"-"+monthNum+"-"+pad(nextFriday)+"-Executive-Update-Email");
					$("#subject").val("SDTA Board of Directors Update - "+fullMonthName+" "+nextFriday+", "+year);
					$("#et_folder_input").val(343713);
					break;
				case "Top Things to Do":
					$("#project_name").val(yearMonDay+" TTTD");
					$("#subject").val("San Diego's Top Things to Do This Weekend");			
					$("#et_folder_input").val(324989);
					$("#template").val("tttd");	
					break;
				case "Consumer News":
					$("#project_name").val(year + " " + nextMonthAbbr.toUpperCase() + " Consumer News");
					$("#subject").val("Next Month in San Diego");
					$("#et_folder_input").val(40559);
					$("#template").val("monthly");			
					break;							
				default:break;
			}
		});		
			
		
    $('#saveproject').click(function() {

        var projectHTML = $('#container').clone().find('.draggable').removeClass('ui-draggable-handle ui-draggable').end().html();
        var pnum = getQueryVariable("pnum");
        var tag_4_ga = +$("#tag4ga").is(":checked");
        var template = $("#template").val();
				var utm_source = $('#utm_source').val();
				var utm_campaign = $('#utm_campaign').val();
				var utm_medium = $('#utm_medium').val();
        if (template == "<select tagging template>") {
            template = "none";
        }


        $.ajax({
            type: "POST",
            dataType: "text",
            url: "saveproject.php",
            data: {
                mydata: projectHTML,
                pnum: pnum,
                tag_4_ga: tag_4_ga,
                tmp: template,
								utm_source: utm_source,
								utm_medium: utm_medium,
								utm_campaign: utm_campaign
            }
        }).done(function(data) {
            alert(data);
            $('.filled').each().unwrap();

        });
    });

    $('body').on('click', '.remove', function(e) {
        e.preventDefault();
        $(this).closest('.contentarea_container').remove();
    });

    $('body').on('click', '.drag', function(e) {

        if ($(this).closest('.contentarea_container').hasClass('activated')) {
            $('.activated').removeClass('activated');
        } else {
            $('.activated').removeClass('activated');
            $(this).closest('.contentarea_container').addClass('activated');
            var $bottomPad = $('.activated').find('.fullpad').css('padding-bottom');
            $bottomPad = $bottomPad.replace(/\D/g, '');
            $('#bottom_padding_slider').slider('value', $bottomPad);
            $('#bottom_padding').find('.value').text($bottomPad);

            var $topPad = $('.activated').find('.fullpad').css('padding-top');
            $topPad = $topPad.replace(/\D/g, '');
            $('#top_padding_slider').slider('value', $bottomPad);
            $('#top_padding').find('.value').text($bottomPad);
        }
    });
    $('#minimize_control_panel').click(function() {
        var $cPanel = $(this).parent();
        if ($cPanel.hasClass('open')) {
            $cPanel.removeClass('open').addClass('minimized');
            $(this).find('.fa').removeClass('fa-chevron-down').addClass('fa-chevron-up');
        } else {
            $cPanel.removeClass('minimized').addClass('open');
            $(this).find('.fa').removeClass('fa-chevron-up').addClass('fa-chevron-down');
        }



    });

    //CONTROL PANEL
    $("#viewport_height").slider({
				range: "min",
				orientation: "vertical",
			  min: 0,
        max: 250,
        step: 5,
        slide: function(event, ui) {
            //$( "#amount" ).val( ui.value );
 
					$('.cr-viewport').css({
							'height': ui.value
					});
					$('.viewport_height_value').text(ui.value);

        }
    });
    $("#bottom_padding_slider").slider({
        range: "min",
        min: 0,
        max: 100,
        step: 10,
        slide: function(event, ui) {
            //$( "#amount" ).val( ui.value );
            if ($('.activated').length) {
                $('.activated').find('.fullpad').css({
                    'padding-bottom': ui.value
                });
                $('#bottom_padding').find('.value').text(ui.value);
            } else {
                alert("You have not activated any modules");
            }
        }
    });
    $("#top_padding_slider").slider({
        range: "min",
        min: 0,
        max: 100,
        step: 10,
        slide: function(event, ui) {
            //$( "#amount" ).val( ui.value );
            if ($('.activated').length) {
                $('.activated').find('.fullpad').css({
                    'padding-top': ui.value
                });
                $('#top_padding').find('.value').text(ui.value);
            } else {
                alert("You have not activated any modules");
            }
        }
    });
    //$( "#amount" ).val( $( "#slider-vertical" ).slider( "value" ) );		


    //$('.contentarea_container').draggable();
    $('#container').sortable({
        handle: ".drag"
    });
    //$('.blockme').sortable();
    $("#resize_control_panel").resizable({ //on resize, check cpanel width and change image size
        handles: "w"
    });

    $("body").on("click", ".duplicate", function() {
			var $dad = $(this).closest(".contentarea_container");
			var $moduleHTML = $dad.wrap("</p>").parent().html();
			$dad.addClass("duplicated");
			$('#container').append($moduleHTML);
			$(".duplicated").unwrap().removeClass("duplicated");
		});
    $('.fullhtml').click(function(e) {
			e.preventDefault();
			folder = $(this).data('folder'); //need to change this to module so it matches
			$(this).closest('.raw').addClass('active ' + folder);
			var isPopup = $(this).hasClass("popup");
			var $data = $(this).attr('href');
			//var $r = $.load($(this).attr('href'));
			//$('#container').append($r);
			//$('#load').dialog('open');

			if (isPopup == true) {
					var $utm_medium = $("#utm_medium").val();
					var $utm_source = $("#utm_source").val();
					var $utm_campaign = $("#utm_campaign").val();
					$('#loadContent').load($(this).attr('href'),{"utm_medium":$utm_medium,"utm_source":$utm_source,"utm_campaign":$utm_campaign});
					$('#load').dialog('open');
			}else{
				$.get($data, function(data) {
				
					$('#container').append(data);
					if (folder == "header-600-wide" || folder == "headline") {
					
					var $tmp = $("#template").val();
					console.log($tmp);
					switch ($tmp) {
						case "tttd":
							var headline = "TOP THINGS TO DO: " + monthAbbr.toUpperCase() + " " + startDate + "-" + endDate + ", " + year;
							var desc = "Spend the upcoming weekend in San Diego enjoying everything California’s\
													Beach City has to offer including these top things to do.";
							$('.maintitle').text(headline);
							$(".subheadline").find(".textarea").text(desc);
							break;
						case "monthly":
							break;
						case "press-release":
						$(".subheadline").find(".editable").text("PRESS RELEASE");
							break;
						default:
							break;
					}
					}
				});
			}
			//check template and autofill title, desc, etc.
			//autoFill(folder);	
    });
    $(document).delegate('.moduleform', 'submit', function(event) {
        event.preventDefault();
        //$('#htmlform').submit();
        formData = $(this).serialize();
        $.ajax({
            type: "POST",
            dataType: "text",
            url: "layouts/" + folder + "/make-layout.php",
            data: formData
        }).done(function(data) {
            //console.log(data);
            //$('.active').attr('data-module', folder);
            // $('.active').html(data).removeClass('active').removeClass('raw').addClass('filled');
            if (folder == "freeform") {
                var $data = $(data).appendTo('#container');
                $data.filter('.contentarea').wrap('<div class="contentarea_container pasted" data-module="freeform"></div>');
                $('.contentarea_container.pasted').append('<div class="remove"></div><div class="edit"></div><div class="drag"></div>');
            } else {
                $('#container').append(data);
            }
            $('#load').dialog('close');
            $('#loadContent').empty();
        });
    });

    $('#clearContainer').click(function() {
        $('#container').empty();
    });
    //don't forget, this adds the google analytics content to the right column for the events module
    $('body').on('change', 'input[name="title[]"]', function() {
        //if tagged == yes
        var item = $(this);
        var content = $(this).val();
        console.log(content);
        //$(this).parent().siblings().find('input[name="ad_content[]"]').val(content.toLowerCase().replace(/[ ]/g,"_"));
        $(this).parent().siblings().find('input[name="ad_content[]"]').val(
            content.toLowerCase().replace(/&|and|,|:|\.|!|\u2013|\u2014|\u002d/g, "").replace(/san diego/g, "sd").replace(/[ ]/g, "_").replace(/__/g, "_")
						);
    });
    $('body').on('click', '.link', function(e) {
				e.preventDefault();
        //$activeUrl = $(this).parent().find('.dest_url');
        //$('#linkbox').fadeIn();
        //$('#linkbox').find('input').addClass('editing');
				var $link = $(this).closest("a").attr("href");
				console.log($link);
        $(this).removeClass('linked');
        $(this).closest('.blockme, .first_buffer_row, .pasted').prepend('<input autofocus class="editing link-input"/>');
        $('.editing').val($link).focus();
        $(this).addClass('linking');
    });
    $('body').on('click', '.fa-italic', function() {
			var $dates2 = $(this).closest(".contentarea_container").find(".dates2");
			if($dates2.parent("em").length){
				$dates2.unwrap("</em>");
			}else{
				$dates2.wrap("<em>");
			}
			
		});
    $('body').on('click', '.fa-external-link', function() {
        //$activeUrl = $(this).parent().find('.dest_url');
        //$('#linkbox').fadeIn();
        //$('#linkbox').find('input').addClass('editing');
				if($(this).hasClass("findImg")){
					$(this).closest('.imagecont').prepend('<input autofocus class="editing img-input2"/>');
				}else{
        	$(this).closest('.blockme').prepend('<input autofocus class="editing img-input"/>');
				}
    });

    $('body').on('click', '.editable', function(event) {

        event.preventDefault();
        var $content = $(this).text();

        if (!$(this).hasClass('editing')) {
            if ($(this).hasClass('textarea')) {
                $(this).wrap('<textarea autofocus class="editing"/>');

            } else {
                $(this).wrap('<input autofocus class="editing"/>');
            }
            $(this).closest(".editing").val($content);
        }
    });
    $('body').on('click', '.editing', function(event) {
        event.preventDefault();
    });
    $('body').on('keydown', '.editing', function(e) {


        if (e.which == 9) { //9 is tab key, 13 is enter key
            var $newValue = $(this).val();

            if ($(this).hasClass('link-input')) {

                //decided to only tag if a campaign is selected	we don't rely enough on tagging to make 
                //it important to tag every email and it would overcomplicate this app
                var $template = $('#template').val();

                if ($template == "tttd") {
                    $newValue = tagForGA($newValue, $template);
                } else if ($template == "monthly") {

                }
                $(this).closest('.blockme, .numbered-list-item, .pasted').find('a').attr('href', $newValue);
                $('.linking').addClass('linked').removeClass('linking');
                $(this).remove();

            } else if ($(this).hasClass('img-input')) {
                $(this).closest('.blockme').find('.editableImage').attr('src', $newValue);
                $(this).remove();
						} else if ($(this).hasClass('img-input2')) {
                $(this).closest('.imagecont').find('.editableImage').attr('src', $newValue);
                $(this).remove();							
            } else {
                if ($(this).find('span').is('.maintitle, .date, .eventname')) {
                    $newValue = $newValue.toUpperCase();
                }
                $(this).find('span').removeClass('unedited').html($newValue.replace(/(?:\r\n|\r|\n)/g, '<br />')).unwrap();
                return false;
            }

        }

    });


    $('body').on('click', '.addEvent', function(event) {
        var $numEvents = $(this).parent().find('.event').length;
        var $dad = $(this).parent();
        var isOdd = ($numEvents % 2) == 1;


        if (isOdd) {
            $.get("layouts/events/lyt-singleEvent.html", function(data) {

                $dad.find('.eventcal tr:last-child .blockme:last-child').html(data);
            })
        } else {
            $.get("layouts/events/lyt-eventRow.html", function(data) {
                $dad.find('.eventcal >tbody').append(data);
            })
        }

    });

    $('body').on('click', '.removeEvent', function(event) {
        var $numEvents = $(this).parent().find('.event').length;
        var $dad = $(this).parent();
        var isOdd = ($numEvents % 2) == 1;
        var $lastTD = $dad.find('.eventcal tr:last-child .blockme:last-child');
        console.log($lastTD.hasClass('right'));
        if ($lastTD.hasClass('empty')) {
            $lastTD.parent().remove();
        } else {

            $lastTD.empty().addClass('empty');
        }

    });
    $('body').on('click', '.addRow', function(event) {
        var $dad = $(this).parent().find('.numbered-list-container');
        var $numRows = $dad.find('.numbered-list-item').length;
        console.log($dad);
        $.get("layouts/numbered-list/lyt-number-row.html", function(data) {
            $dad.find('.numbered-list-item').last().after(data);
            $dad.find('.number').last().text($numRows + 1);
        })


    });
    $('body').on('click', '.removeRow', function(event) {
        var $dad = $(this).parent().find('.numbered-list-container');
        var $last = $dad.find('.numbered-list-item').last().remove();
    });
    $('body').on('click', '.ltblue', function(event) {
        $(this).parent().find('.fullpad').attr('bgcolor', '#dbe7ef').attr('background', 'none');

    });
    $('body').on('click', '.white', function(event) {
        $(this).parent().find('.fullpad').attr('bgcolor', '#ffffff').attr('background', 'none');

    });
    $('body').on('click', '.orange', function(event) {
        $(this).parent().find('.fullpad').attr('bgcolor', '#fddea6').attr('background', 'http://image.exct.net/lib/fe6e15707166047a7715/m/1/sdta_nl_small_texture_tan.jpg');

    });




		
		$(".fa-calendar").click(function() {
       $(".eventDatepicker").show(); 
    });

      $('body').delegate('.eventDatepicker', 'click', function(event) {
				$(this).parent().find(".date").addClass("active");
				$(this).datepicker(
				"dialog",
				"",
				function(v){
					
					//var cleanDate = v.split("/");
					
					//v = v.replace(/\//g, "\n");
					$(".active").html(v.toUpperCase()).removeClass("active");
					
				},
				{
					minDate: -1,
					showButtonPanel: true,					
					dateFormat: "M<br>dd"
				}
				);
				//$(this).datepicker( "dialog", "10/12/2012" );

    });
var $r1, m1, d1, date1;
     $('body').delegate('.eventDatepickerRange', 'click', function(event) {
				$(this).parent().find(".date").addClass("active");
				$(this).datepicker(
				{
					minDate: -1,
					showButtonPanel: true,
					onSelect:function(v){
						//console.log(m);
						var dPickerDate = $(this).datepicker( "getDate" );
						if($r1 == undefined){
							var dTime = d.getTime();
							m1 = monthNames[dPickerDate.getMonth()];
							d1 = dPickerDate.getDate();
							var vTime = dPickerDate.getTime();	
							console.log(vTime<dTime);							
							if(vTime<dTime){							
								date1 = "THRU";
							}else{
								date1 = m1.toUpperCase() + " " + d1;
							}
							
							
							
							$r1 = v;		
							
							
							
							
							
											
						}else{
		
							var m2 = monthNames[dPickerDate.getMonth()];
							var d2 = dPickerDate.getDate();
							if(m1 != m2 || date1 == "THRU"){
								//different months
								
									//var string = "THRU<br>" + m2.toUpperCase() + " " + d2;

								var string = date1 + "<br>-" + m2.toUpperCase() + " " + d2;
							
								$(".active").html(  string ).removeClass("active");
							//	$(this).find(".ui-datepicker").hide();		
							}else{
								//same month
								var string = m2.toUpperCase();
								string+= "<br>" + d1 + "-" + d2;
								$(".active").html(  string ).removeClass("active");
								//$(this).hide();						
							}
							
						$(".eventDatepickerRange").datepicker("destroy");	
						$r1 = undefined;	
							
						}
						console.log(v);
						
						
						
					}
				}
				);
				//$(this).datepicker( "dialog", "10/12/2012" );

    });

//SCREENSHOT STUFF
		$("body").on("click", ".saveToLibrary", function(){
				var $theCode = $(this).parent().html();
				console.log($theCode);
			 $("body").append('<input autofocus class="savemodule" style="position:absolute;top:50px;left:50px;" />');
				
				
				
				/*	
				//window.open('',t.toDataURL());
				//so the SVG method sort of works. It works with simple HTML, but the complex HTML
				//in the modules is breaking it somehow so for now this is parked, we'll use a simple name instead
				$("#canvas").fadeIn();
				var canvas = document.getElementById('canvas');
				var ctx = canvas.getContext('2d');
				//var $theCode = '<table><tr><td>what the fuck</td></tr></table>';

				var data = '<svg xmlns="http://www.w3.org/2000/svg" width="200" height="200">' +
           '<foreignObject width="100%" height="100%">' +
           '<div xmlns="http://www.w3.org/1999/xhtml" style="font-size:40px">' +
            $theCode+
						 
           '</div>' +
					 
           '</foreignObject>' +
           '</svg>';

				var DOMURL = window.URL || window.webkitURL || window;
				
				var img = new Image();
				var svg = new Blob([data], {type: 'image/svg+xml;charset=utf-8'});
				var url = DOMURL.createObjectURL(svg);
				
				img.onload = function () {
					ctx.drawImage(img, 0, 0);
					DOMURL.revokeObjectURL(url);
				}
				
				img.src = url;
				*/
		
		

	});


//PR functions
//$('#richtext_editor').trumbowyg();
	$('body').on('change', '#addSignature input', function(e) {
		var $name = e.target.name;
		
		var $dad = $(this).closest(".contentarea_container");
		var $numSigs = $dad.find('.signature').length;
		var isOdd = ($numSigs % 2) == 1;		
		if (isOdd) {
				$.get("layouts/signatures/sig-"+$name+".html", function(data) {
						$dad.find('.eventcal tr:last-child .blockme:last-child').html(data);
				})
		} else {
				$.get("layouts/signatures/lyt-sigRow.html", function(data) {
					$dad.find('.eventcal >tbody').append(data);
					$.get("layouts/signatures/sig-"+$name+".html", function(data) {
							$dad.find('.eventcal tr:last-child .blockme:first-child').html(data);
					});					
						
				})
		}		
		
		

		
		
		
		
		
		//var $nextEmpty = $(this).closest("contentarea_container").find(".empty");
		
	});



//SHAREABLE STUFF BELOW  dsfsdf dsf sff sd


    $("#datepicker").datepicker();

		
    $('#slider').slider({
        min: 0,
        max: 1440,
        step: 15,
        slide: function(event, ui) {
            var hours = Math.floor(ui.value / 60);
            var minutes = ui.value - (hours * 60);

            if (hours.toString().length == 1) hours = '0' + hours;
            if (minutes.toString().length == 1) minutes = '0' + minutes


            $('#time').val(hours + ':' + minutes);

        }

    });



});
//yoyoyo!yoyo!
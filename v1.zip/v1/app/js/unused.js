	$("body").on("click", ".saveToLibrary", function(){
				var $theCode = $(this).parent().html();
				console.log($theCode);
			 $("body").append('<input autofocus class="savemodule" style="position:absolute;top:50px;left:50px;" />');
				
				
				
				/*	
				//window.open('',t.toDataURL());
				//so the SVG method sort of works. It works with simple HTML, but the complex HTML
				//in the modules is breaking it somehow so for now this is parked, we'll use a simple name instead
				$("#canvas").fadeIn();
				var canvas = document.getElementById('canvas');
				var ctx = canvas.getContext('2d');
				//var $theCode = '<table><tr><td>what the fuck</td></tr></table>';

				var data = '<svg xmlns="http://www.w3.org/2000/svg" width="200" height="200">' +
           '<foreignObject width="100%" height="100%">' +
           '<div xmlns="http://www.w3.org/1999/xhtml" style="font-size:40px">' +
            $theCode+
						 
           '</div>' +
					 
           '</foreignObject>' +
           '</svg>';

				var DOMURL = window.URL || window.webkitURL || window;
				
				var img = new Image();
				var svg = new Blob([data], {type: 'image/svg+xml;charset=utf-8'});
				var url = DOMURL.createObjectURL(svg);
				
				img.onload = function () {
					ctx.drawImage(img, 0, 0);
					DOMURL.revokeObjectURL(url);
				}
				
				img.src = url;
				*/
		
		

	});

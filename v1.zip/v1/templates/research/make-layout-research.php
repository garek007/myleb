<?php
session_start();
include "../../00-Includes/header.php";
$user = $_SESSION['email'];





//ini_set('display_errors', 0);
//loop to see how many fields are filled out

//find campaign name if any

//$header = isset($_POST['header']) ? strtoupper($_POST['header']) : '';



$full_month_name = date('F');
$full_year = date('Y');
$description = isset($_POST['description']) ? nl2br(trim($_POST['description'])) : '';
$visitors = isset($_POST['visitors']) ? trim($_POST['visitors']) : '';
$visitors_chg = isset($_POST['visitors_chg']) ? trim($_POST['visitors_chg']) : '';

$spending = isset($_POST['spending']) ? trim($_POST['spending']) : '';
$spending_chg = isset($_POST['spending_chg']) ? trim($_POST['spending_chg']) : '';

$attendance = isset($_POST['attendance']) ? trim($_POST['attendance']) : '';
$attendance_chg = isset($_POST['attendance_chg']) ? trim($_POST['attendance_chg']) : '';

$arrivals = isset($_POST['arrivals']) ? trim($_POST['arrivals']) : '';
$arrivals_chg = isset($_POST['arrivals_chg']) ? trim($_POST['arrivals_chg']) : '';

$occupancy = isset($_POST['occupancy']) ? trim($_POST['occupancy']) : '';
$occupancy_chg = isset($_POST['occupancy_chg']) ? trim($_POST['occupancy_chg']) : '';

$adr = isset($_POST['adr']) ? trim($_POST['adr']) : '';
$adr_chg = isset($_POST['adr_chg']) ? trim($_POST['adr_chg']) : '';

$yoy_growth_title = isset($_POST['yoy_growth_title']) ? trim($_POST['yoy_growth_title']) : 'JAN - NOW YOY GROWTH';
$forecast_title = isset($_POST['forecast_title']) ? trim($_POST['forecast_title']) : 'SAN DIEGO TRAVEL FORECAST';
$yoy_img = $_POST['yoy_img'];
$forecast_img = $_POST['forecast_img'];

$funfact = isset($_POST['funfact']) ? nl2br(trim($_POST['funfact'])) : '';
$funfact_img = $_POST['funfact_img'];

$all_visitors = isset($_POST['all_visitors']) ? nl2br(trim($_POST['all_visitors'])) : '';
$all_visitor_spending = isset($_POST['all_visitor_spending']) ? nl2br(trim($_POST['all_visitor_spending'])) : '';

  include 'lyt-research.php';



$_SESSION['html'] = $html;
$_SESSION['subject'] = stripslashes($_POST['et_subject']);
$_SESSION['email_name'] = $_POST['et_email_name'];
$_SESSION['from_name'] = $whomadethis->name;
$_SESSION['from_email'] = $whomadethis->email;



include '../../00-Includes/scheduler.php';


?>






<div class="row">
<div class="first-col cols_12-12">
<?php



echo $html;

?>
</div></div>
<?php





include "../../00-Includes/footer.php";


?>

            
            
            
            
						


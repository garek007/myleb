<?php
ob_start();
include '../../00-Includes/corp_template_start.html';
$htmlstart = ob_get_contents();
ob_end_clean();

ob_start();
include '../../00-Includes/corp_template_end.html';
$htmlend = ob_get_contents();
ob_end_clean();




$html = <<<EOT
{$htmlstart}
<table class="contentarea twocol" width="100%" border="0" cellspacing="0" cellpadding="0">
	<tbody>
		<tr>
			<td class="fullpad" style="padding: 20px 30px 30px;" bgcolor="#dbe7ef">
			
			
			
			<table width="100%" border="0" cellspacing="0" cellpadding="0">
				<tbody>
					<tr>
						<td class="title" align="left" style="font-size: 23px; letter-spacing: 0.3px; padding-bottom: 5px; color: #434448;">
						
						
					<font style="font-family: 'Arial Narrow', Helvetica, sans-serif;"> 
									<!--[if (!mso 14)&(!mso 15)]><!--> 
									<font style="font-family: Oswald, 'Arial Narrow', Helvetica, Arial, sans-serif;"> 
									<!--<![endif]--> 	SAN DIEGO COUNTY VISITOR INDUSTRY&nbsp;PERFORMANCE          <!--[if (!mso 14)&(!mso 15)]><!--> 
									</font> 
									<!--<![endif]--></font>
						
						
						</td>
					</tr>
				</tbody>
			</table>
			<table width="100%" border="0" cellspacing="0" cellpadding="0">
				<tbody>
					<tr>
						<td class="title" align="left" style="font-size: 18px; letter-spacing: 0.3px; padding-bottom: 20px; color: #434448;">
						
						
						<font style="font-family: 'Arial Narrow', Helvetica, sans-serif;"> 
									<!--[if (!mso 14)&(!mso 15)]><!--> 
									<font style="font-family: Oswald, 'Arial Narrow', Helvetica, Arial, sans-serif;"> 
									<!--<![endif]--> $full_month_name $full_year          <!--[if (!mso 14)&(!mso 15)]><!--> 
									</font> 
									<!--<![endif]--></font>
						
			
						
						</td>
					</tr>
					<tr>
						<td colspan="2" align="left" valign="top" class="blockme" style="padding-right: 0px; padding-top: 0px; padding-bottom: 30px; text-align: justify;font-family: Helvetica, Arial, sans-serif;line-height:20px;">
	$description
	
						</td>
					</tr>
				</tbody>
			</table>
			<table width="100%" border="0" cellspacing="0" cellpadding="0">
				<tbody>
					<tr>
						<td class="blockme" style="padding-right: 5px;" width="50%" valign="top" align="left">
						<table bgcolor="#E37222" width="100%" border="0" cellspacing="0" cellpadding="0">
							<tbody>
								<tr>
									<td align="center" style="font-size: 60px; line-height: 60px; color: #ffffff; padding: 20px 0px 10px; margin: 0px;">
							
								<font style="font-family: 'Arial Narrow', Helvetica, sans-serif;"> 
									<!--[if (!mso 14)&(!mso 15)]><!--> 
									<font style="font-family: Oswald, 'Arial Narrow', Helvetica, Arial, sans-serif;"> 
									<!--<![endif]--> 	$visitors <!--[if (!mso 14)&(!mso 15)]><!--> 
									</font> 
									<!--<![endif]--></font>
								
									</td>
								</tr>
								<tr>
									<td align="center" class="blockme" style="font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif; font-size: 18px; line-height: 20px; padding: 0px 0px 20px; margin: 0px; color: #ffffff;">All Visitors ( $visitors_chg ) </td>
								</tr>
							</tbody>
						</table>
						</td>
						<td class="blockme" style="padding-left: 5px;" width="50%" valign="top" align="left">
						<table bgcolor="#F3CF45" width="100%" border="0" cellspacing="0" cellpadding="0">
							<tbody>
								<tr>
									<td align="center" style="font-size: 60px; line-height: 60px; color: #ffffff; padding: 20px 0px 10px; margin: 0px;">
						
									<font style="font-family: 'Arial Narrow', Helvetica, sans-serif;"> 
									<!--[if (!mso 14)&(!mso 15)]><!--> 
									<font style="font-family: Oswald, 'Arial Narrow', Helvetica, Arial, sans-serif;"> 
									<!--<![endif]--> $spending        <!--[if (!mso 14)&(!mso 15)]><!--> 
									</font> 
									<!--<![endif]--></font>
									
									</td>
								</tr>
								<tr>
									<td align="center" class="blockme" style="font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif; font-size: 18px; line-height: 20px; padding: 0px 0px 20px; margin: 0px; color: #ffffff;">Visitor Spending ( $spending_chg ) </td>
								</tr>
							</tbody>
						</table>
						</td>
					</tr>
					<tr>
						<td class="blockme" style="padding-right: 5px; padding-top: 10px;" width="50%" valign="top" align="left">
						<table bgcolor="#9E3039" width="100%" border="0" cellspacing="0" cellpadding="0">
							<tbody>
								<tr>
									<td align="center" style="font-size: 60px; line-height: 60px; color: #ffffff; padding: 20px 0px 10px; margin: 0px;">
					
								<font style="font-family: 'Arial Narrow', Helvetica, sans-serif;"> 
									<!--[if (!mso 14)&(!mso 15)]><!--> 
									<font style="font-family: Oswald, 'Arial Narrow', Helvetica, Arial, sans-serif;"> 
									<!--<![endif]--> 	$attendance          <!--[if (!mso 14)&(!mso 15)]><!--> 
									</font> 
									<!--<![endif]--></font>
									
									</td>
								</tr>
								<tr>
									<td align="center" class="blockme" style="font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif; font-size: 18px; line-height: 20px; padding: 0px 0px 20px; margin: 0px; color: #ffffff;">Attraction Attendance ( $attendance_chg ) </td>
								</tr>
							</tbody>
						</table>
						</td>
						<td class="blockme" style="padding-left: 5px; padding-top: 10px;" width="50%" valign="top" align="left">
						<table bgcolor="#00759A" width="100%" border="0" cellspacing="0" cellpadding="0">
							<tbody>
								<tr>
									<td align="center" style="font-size: 60px; line-height: 60px; color: #ffffff; padding: 20px 0px 10px; margin: 0px;">
						
								<font style="font-family: 'Arial Narrow', Helvetica, sans-serif;"> 
									<!--[if (!mso 14)&(!mso 15)]><!--> 
									<font style="font-family: Oswald, 'Arial Narrow', Helvetica, Arial, sans-serif;"> 
									<!--<![endif]--> 	$arrivals         <!--[if (!mso 14)&(!mso 15)]><!--> 
									</font> 
									<!--<![endif]--></font>
									
									</td>
								</tr>
								<tr>
									<td align="center" class="blockme" style="font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif; font-size: 18px; line-height: 20px; padding: 0px 0px 20px; margin: 0px; color: #ffffff;">Airport Arrivals ( $arrivals_chg ) </td>
								</tr>
							</tbody>
						</table>
						</td>
					</tr>
					<tr>
						<td class="blockme" style="padding-right: 5px; padding-top: 10px;" width="50%" valign="top" align="left">
						<table bgcolor="#70A489" width="100%" border="0" cellspacing="0" cellpadding="0">
							<tbody>
								<tr>
									<td align="center" style="font-size: 60px; line-height: 60px; color: #ffffff; padding: 20px 0px 10px; margin: 0px;">
						
								<font style="font-family: 'Arial Narrow', Helvetica, sans-serif;"> 
									<!--[if (!mso 14)&(!mso 15)]><!--> 
									<font style="font-family: Oswald, 'Arial Narrow', Helvetica, Arial, sans-serif;"> 
									<!--<![endif]--> 	$occupancy         <!--[if (!mso 14)&(!mso 15)]><!--> 
									</font> 
									<!--<![endif]--></font>
									
									</td>
								</tr>
								<tr>
									<td align="center" class="blockme" style="font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif; font-size: 18px; line-height: 20px; padding: 0px 0px 20px; margin: 0px; color: #ffffff;">Occupancy ( $occupancy_chg ) </td>
								</tr>
							</tbody>
						</table>
						</td>
						<td class="blockme" style="padding-left: 5px; padding-top: 10px;" width="50%" valign="top" align="left">
						<table bgcolor="#3095B4" width="100%" border="0" cellspacing="0" cellpadding="0">
							<tbody>
								<tr>
									<td align="center" style="font-size: 60px; line-height: 60px; color: #ffffff; padding: 20px 0px 10px; margin: 0px;">
					
								<font style="font-family: 'Arial Narrow', Helvetica, sans-serif;"> 
									<!--[if (!mso 14)&(!mso 15)]><!--> 
									<font style="font-family: Oswald, 'Arial Narrow', Helvetica, Arial, sans-serif;"> 
									<!--<![endif]--> 	$adr        <!--[if (!mso 14)&(!mso 15)]><!--> 
									</font> 
									<!--<![endif]--></font>
									
									</td>
								</tr>
								<tr>
									<td align="center" class="blockme" style="font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif; font-size: 18px; line-height: 20px; padding: 0px 0px 20px; margin: 0px; color: #ffffff;">Average Daily Rate ( $adr_chg ) </td>
								</tr>
							</tbody>
						</table>
						</td>
					</tr>
					<tr>
						<td colspan="2" align="left" valign="top" class="blockme" style="padding-right: 0px; padding-top: 20px; text-align: justify;">
						</td>
					</tr>
				</tbody>
			</table>
			
			
			
			
			</td>
		</tr>
	</tbody>
</table>


<!------------------------------------------------------------->
<!--------------- YEAR OVER YEAR GROWTH SECTION --------------->
<!------------------------------------------------------------->

<table class="contentarea" width="100%" border="0" cellspacing="0" cellpadding="0">
<!--------------------------------- SECTION HEADLINE START ------------------------------------->
<!----------------------- dont forget to grab the opening table tag above ------------------------->
<!--------------------------------- SECTION HEADLINE START ------------------------------------->
	<tbody>
		<tr>
			<td class="fullpad" style="padding: 0 30px 0;">
			<table width="100%" border="0" cellspacing="0" cellpadding="0">
				<tbody>
					<tr>
						<td style="padding-top: 20px;">
						

						<table class="headlinebar" width="100%" border="0" cellspacing="0" cellpadding="0">
							<tbody>
								<tr>
										
										<td valign="top" align="left" style="font-size: 18px; letter-spacing: 0.3px; color: #005f86;" class="subheadline inactive">
													
												<font style="font-family: 'Arial Narrow',Helvetica,sans-serif;"> 
												<!--[if (!mso 14)&(!mso 15)]><!--> 
												<font style="font-family: Oswald,'Arial Narrow',Helvetica,Arial,sans-serif;"> 
												<!--<![endif]--> 
												<span class="editable">YEAR TO DATE PERFORMANCE</span>
												<!--[if (!mso 14)&(!mso 15)]><!--> 
												</font> 
												<!--<![endif]--></font></td>

									
										<td valign="top" align="right" style="font-size: 12px;" class="calltoaction"><a style="color: #88b6ca; font-family: Oswald,'Arial Narrow',Helvetica,Arial,sans-serif; text-decoration: none;" href="#">
										
										<font style="font-family: 'Arial Narrow', Helvetica, sans-serif;"> 
									<!--[if (!mso 14)&(!mso 15)]><!--> 
									<font style="font-family: Oswald, 'Arial Narrow', Helvetica, Arial, sans-serif;"> 
									<!--<![endif]-->
									<span class="editable sponsored"> </span>
									          <!--[if (!mso 14)&(!mso 15)]><!--> 
									</font> 
									<!--<![endif]--></font>
									
										
										</a></td>
					
	
								</tr>
							</tbody>
						</table>
						</td>
					</tr>
					
					
					
				</tbody>
			</table>
			</td>
		</tr>
	</tbody>
<!--------------------------------- SECTION HEADLINE END ------------------------------------->
<!-------------------- dont forget to grab the closing table tag below ----------------------->
<!--------------------------------- SECTION HEADLINE END ------------------------------------->
</table>







<!-- WHATS NEW 1 -->
<table width="100%" border="0" cellspacing="0" cellpadding="0">
	<tbody>
		<tr>
			<td class="fullpad" style="padding: 20px 30px 30px;">
			<table width="100%" border="0" cellspacing="0" cellpadding="0">
				<tbody>
					<tr>
						<td>
						<table class="headlinebar" width="100%" border="0" cellspacing="0" cellpadding="0">
							<tbody>
								<tr>
									<td class="subheadline" align="left" valign="top" style="font-size: 16px; letter-spacing: 0.3px; color: #007298; line-height: 18px;font-family: Helvetica, Arial, sans-serif;">
                  
        <strong>All Visitors: </strong> $all_visitors <br>
        <strong>Visitor Spending: </strong> $all_visitor_spending
								
                  
            </td>
									<td class="calltoaction" align="right" valign="top">&nbsp;</td>
								</tr>
								<tr>
									<td class="subheadline" align="left" valign="top" style="font-size: 16px; letter-spacing: 0.3px; color: #333333; line-height: 18px;"><font style="font-family: "Arial Narrow", Helvetica, sans-serif;">
									<!--[if (!mso 14)&(!mso 15)]><!-->
									<font style="font-family: Oswald, "Arial Narrow", Helvetica, Arial, sans-serif;">
									<!--<![endif]-->
									&nbsp;&nbsp;&nbsp;
									<!--[if (!mso 14)&(!mso 15)]><!-->
									</font>
									<!--<![endif]-->
									</font></td>
									<td class="calltoaction" align="right" valign="top">&nbsp;</td>
								</tr>
								<tr>
									<td class="subheadline" align="left" valign="top" style="font-size: 18px; letter-spacing: 0.3px; color: #007298; line-height: 18px; padding-top: 30px;"><font style="font-family: "Arial Narrow", Helvetica, sans-serif;">
						
								<font style="font-family: 'Arial Narrow', Helvetica, sans-serif;"> 
									<!--[if (!mso 14)&(!mso 15)]><!--> 
									<font style="font-family: Oswald, 'Arial Narrow', Helvetica, Arial, sans-serif;"> 
									<!--<![endif]--> 	$yoy_growth_title          <!--[if (!mso 14)&(!mso 15)]><!--> 
									</font> 
									<!--<![endif]--></font>
						
            
            
            </td>
									<td class="calltoaction" align="right" valign="top">&nbsp;</td>
								</tr>
							</tbody>
						</table>
						</td>
					</tr>
					<tr>
						<td style="padding-top: 5px;"><img class="fullwidth" src="$yoy_img" width="540" border="0" style="display: block; height: auto !important;" /></td>
					</tr>
					<tr>
						<td style="padding-top: 16px;">
						<table width="100%" border="0" cellspacing="0" cellpadding="0">
							<tbody>
								<tr>
								</tr>
								<tr>
									<td class="description" align="left" style="font-family: Helvetica, Arial, sans-serif; font-size: 12px; color: #434448; padding-top: 5px;"><a href="https://www.sandiego.org/about/industry-research.aspx#industryperformance">Click here to see additional details regarding industry performance.</a></td>
								</tr>
							</tbody>
						</table>
						</td>
					</tr>
				</tbody>
			</table>
			</td>
		</tr>
	</tbody>
</table>




<!------------------------------------------------------------->
<!------------------ TRAVEL FORECAST SECTION ------------------>
<!------------------------------------------------------------->


<!-- WHATS NEW 1 -->
<table width="100%" border="0" cellspacing="0" cellpadding="0">
	<tbody>
		<tr>
			<td class="fullpad" style="padding: 20px 30px 30px;">
			<table border="0" width="100%" cellspacing="0" cellpadding="0">
				<tbody>
					<tr>
						<td>
						<table class="headlinebar" width="100%" border="0" cellspacing="0" cellpadding="0">
							<tbody>
								<tr>
									<td class="subheadline" align="left" valign="top" style="font-size: 18px; letter-spacing: 0.3px; color: #007298; line-height: 18px;"><font style="font-family: 'Arial Narrow', Helvetica, sans-serif;">
									<!--[if (!mso 14)&(!mso 15)]><!-->
									<font style="font-family: Oswald, 'Arial Narrow', Helvetica, Arial, sans-serif;">
									<!--<![endif]-->
								$forecast_title
									<!--[if (!mso 14)&(!mso 15)]><!-->
									</font>
									<!--<![endif]-->
									</font></td>
									<td class="calltoaction" align="right" valign="top">&nbsp;</td>
								</tr>
							</tbody>
						</table>
						</td>
					</tr>
					<tr>
						<td style="padding-top: 0px;"><a href="#"><img class="fullwidth" src="$forecast_img" width="540" border="0" style="display: block; height: auto !important;" /></a></td>
					</tr>

					
				</tbody>
			</table>
			</td>
		</tr>
	</tbody>
</table>




<!------------------------------------------------------------->
<!---------------------- FUN FACT SECTION --------------------->
<!------------------------------------------------------------->



<table class="contentarea twocol" width="100%" border="0" cellspacing="0" cellpadding="0">
	<tbody>
		<tr>
			<td class="fullpad" style="padding: 20px 30px 30px;" >
			<table width="100%" border="0" cellspacing="0" cellpadding="0">
				<tbody>
					<tr>
						<td class="title" align="left" style="font-size: 19px; padding-bottom: 20px; color: #434448;">
						<font style="font-family: 'Arial Narrow', Helvetica, Arial, sans-serif;"> 
						<!--[if (!mso 14)&(!mso 15)]><!--> 
						<font style="font-family: Oswald, 'Arial Narrow', Helvetica, Arial, sans-serif;"> 
						<!--<![endif]--> 
					
						<!--[if (!mso 14)&(!mso 15)]><!--> 
						</font> 
						<!--<![endif]--> 
						</font>                        
						</td>
					</tr>
				</tbody>
			</table>
			<table width="100%" border="0" cellspacing="0" cellpadding="0">
				<tbody>
					<tr>
						<td class="blockme" style="padding-right: 5px;" width="50%" valign="top" align="left">
						<table width="100%" border="0" cellspacing="0" cellpadding="0">
							<tbody>
								<tr>
									<td class="imagecont" style="padding-bottom: 10px;"><img class="fullwidth" src="$funfact_img" border="0" style="display: block; height: auto !important;" width="265" /></td>
								</tr>
								
							</tbody>
						</table>
						</td>
						<td class="blockme" style="padding-left: 5px;" width="50%" valign="top" align="left">
						<table width="100%" border="0" cellspacing="0" cellpadding="0">
							<tbody>
								
							  <tr>
									<td class="title" align="left" style="font-size: 22px; color: #434448;">
									<font style="font-family: 'Arial Narrow', Helvetica, Arial, sans-serif;"> 
									<!--[if (!mso 14)&(!mso 15)]><!--> 
									<font style="font-family: Oswald, 'Arial Narrow', Helvetica, Arial, sans-serif;"> 
									<!--<![endif]--> 
										VISITOR PROFILE FUN-FACT
									<!--[if (!mso 14)&(!mso 15)]><!--> 
									</font> 
									<!--<![endif]--> 
									</font></td>
								</tr>
								<tr>
									<td class="description" align="left" style="font-family: Helvetica, Arial, sans-serif; font-size: 18px; color: #434448; padding-top: 5px;">$funfact</td>
								</tr>
							</tbody>
						</table>
						</td>
					</tr>
				</tbody>
			</table>
			</td>
		</tr>
	</tbody>
</table>















$htmlend;
EOT;

?>
?>
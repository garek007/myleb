<form title="tttdform" name="tttdform" action="make-layout-research.php" method="post">

<div class="row">
<div class="first-col cols_12-6 column">
	<label for="medium">ExactTarget Email Name<span class="required">*</span></label>

  <input name="et_email_name" type="text" size="30" value="<?php echo $year; ?>Research Email">

</div>



<div class="cols_12-6 column">
	<label for="medium">ExactTarget Email Subject<span class="required">*</span></label>

  <input name="et_subject" type="text" size="30" value="San Diego County Visitor Industry Performance Update">

</div>
<div class="cols_12-4"></div>


</div>

<div class="row">


  <div class="first-col cols_12-4 column">
  <label for"whoismakingthis">I am</label>
  <select style="float:left;" name="whoismakingthis" id="whoismakingthis">
    <option value="custom">--who are you--</option>
    <option value="iamsue" id="iamjamil" selected >Jamil</option>
  </select>
	</div>
</div>

<div class="row">
  <div class="first-col cols_12-8 column">    
    <label for="medium">Intro</label>
    <textarea name="description" cols="60" rows="5"></textarea></div>  
  </div>
</div>

<div class="row">
  <div class="first-col cols_12-6 column">
    <label for="medium">Visitors<span class="required">*</span></label>
  	<input name="visitors" type="text">
  </div>    
  <div class="cols_12-6 column"> 
    <label for="medium">All Visitors Change %</label>
  	<input name="visitors_chg" type="text" size="30">
  </div>    
</div>

<div class="row">
  <div class="first-col cols_12-6 column">
    <label for="medium">Visitor Spending<span class="required">*</span></label>
  	<input name="spending" type="text">
  </div>    
  <div class="cols_12-6 column"> 
    <label for="medium">Visitor Spending Change %</label>
  	<input name="spending_chg" type="text" size="30">
  </div>    
</div>

<div class="row">
  <div class="first-col cols_12-6 column">
    <label for="medium">Attraction Attendance<span class="required">*</span></label>
  	<input name="attendance" type="text">
  </div>    
  <div class="cols_12-6 column"> 
    <label for="medium">Attraction Attendance Change %</label>
  	<input name="attendance_chg" type="text" size="30">
  </div>    
</div>

<div class="row">
  <div class="first-col cols_12-6 column">
    <label for="medium">Airport Arrivals<span class="required">*</span></label>
  	<input name="arrivals" type="text">
  </div>    
  <div class="cols_12-6 column"> 
    <label for="medium">Airport Arrivals Change %</label>
  	<input name="arrivals_chg" type="text" size="30">
  </div>    
</div>

<div class="row">
  <div class="first-col cols_12-6 column">
    <label for="medium">Occupancy<span class="required">*</span></label>
  	<input name="occupancy" type="text">
  </div>    
  <div class="cols_12-6 column"> 
    <label for="medium">Occupancy Change %</label>
  	<input name="occupancy_chg" type="text" size="30">
  </div>    
</div>



<div class="row">
  <div class="first-col cols_12-6 column">
    <label for="medium">Average Daily Rate<span class="required">*</span></label>
  	<input name="adr" type="text">
  </div>    
  <div class="cols_12-6 column"> 
    <label for="medium">Average Daily Rate Change %</label>
  	<input name="adr_chg" type="text" size="30">
  </div>    
</div>



<div class="row">
 <h3>YOY Growth and Travel Forecast</h3>
  <div class="first-col cols_12-6 column">
    <label for="medium">YOY Section Title<span class="required">*</span></label>
  	<input class="text" name="yoy_growth_title" type="text" placeholder="JANUARY-[enter month] YOY GROWTH">
  </div>   
  <div class="cols_12-6 column">
  <label for="medium">YOY Growth Chart Image (drag image here)</label>
          <input class="input text drop-area" name="yoy_img" type="text" size="25" data-width="540" data-height="285">
  </div>
  
     
  
</div>



<div class="row">

  <div class="first-col cols_12-6 column">
    <label for="medium">Forecast Section Title<span class="required">*</span></label>
  	<input class="text" name="forecast_title" type="text" placeholder="SAN DIEGO TRAVEL FORECAST AS OF [MONTH] [YEAR]">
  </div>  
  <div class="cols_12-6 column">
  <label for="medium">Travel Forecast Image (drag image here)</label>
          <input class="input text drop-area" name="forecast_img" type="text" size="25" data-width="540" data-height="300">
  </div>    

</div>





<div class="row">
 <h3>Fun Fact</h3>
  <div class="first-col cols_12-6 column">
  <label for="medium">Fun Fact Text</label>
    <textarea class="input text" name="funfact" type="text" size="25"></textarea>
  </div> 
  <div class="cols_12-6 column">
  <label for="medium">Fun Fact Image (drag image here)</label>
          <input class="input text drop-area" name="funfact_img" type="text" size="25" data-width="540" data-height="300">
  </div>
</div>



<div class="row">
<input style="clear:both;float:none;" type="submit" value="Generate HTML" class="submit">
</div>



</form>
<?php 
session_start();

$pageTitle = "Shareable Content Complete Email Builder"; 
$date = date('md');
$year = date('Y-m-');

 include $_SERVER['DOCUMENT_ROOT']."/header.php"; 

$user = $_SESSION['email'];
?>

<div class="first-row row">
<h2><?php echo $pageTitle; ?></h2>

</div>
<div id="cropbox" class="cropbox">
<i class="fa fa-check upload-result fa-4x" aria-hidden="true"></i>
<i class="fa fa-times upload-cancel fa-4x" aria-hidden="true"></i>
<i class="fa fa-spinner fa-pulse fa-3x fa-fw"></i>

<div id="viewport_height" class="viewport_height"></div>
      Height
    <div class="viewport_height_value">--</div>
</div>

<?php
if($user == "jpatiag@sandiego.org"){
  include "forms/frm-research.php";
}else{
  include "forms/frm-sharethis.php";
}

include $_SERVER['DOCUMENT_ROOT']."/footer.php"; ?>
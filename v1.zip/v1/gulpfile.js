var gulp = require('gulp');
var autoprefixer = require('autoprefixer');
var cssnext = require('cssnext');
var cssnano = require('cssnano');
var precss = require('precss');
var stylelint = require('stylelint');
var uglify = require('gulp-uglify');
var pump = require('pump');
var prettify = require('gulp-js-prettify');
var prettify2 = require('gulp-jsbeautifier');
var postcss = require('gulp-postcss');
var importcss = require('postcss-import');
var concat = require('gulp-concat');




gulp.task('build', ['compress', 'css']);

gulp.task('css',function(){
	var processors = [
		autoprefixer,
		cssnext,
		importcss,
		cssnano				
	];
	return gulp.src('app/**/*.css')
		.pipe(postcss(processors))
		.pipe(concat('style.min.css'))
		.pipe(gulp.dest('./dist/'));
});
gulp.task('compress', function() {
  return gulp.src(
	[
	'app/js/jquery.min.js',
	'app/js/jquery-ui.min.js',
	'app/js/croppie.js',
	'app/js/jquery.tablesorter.min.js',
	'app/js/scripts2.js'
	]) //return gulp.src('./app/js/*.js')
		.pipe(uglify())
		.pipe(concat('all.min.js'))
    .pipe(gulp.dest('./dist'));
});

gulp.task('compress-old', function (cb) {
  pump([
        gulp.src('app/**/all.js'),//gulp.src('app/**/*.js'),
        uglify(),
        gulp.dest('./dist')
    ],
    cb
  );
});

gulp.task('prettify', function() {
  gulp.src('app/**/*.js')
    .pipe(prettify({
			collapseWhitespace: true
		}))
    .pipe(gulp.dest('./src')) // edit in place 
});
gulp.task('prettify2', function() {
  gulp.src(['app/**/*.js', 'app/**/*.css'])
    .pipe(prettify())
    .pipe(gulp.dest('./src')) // edit in place 
});
//gulp.watch('app/**/*.css', ['css']); 
gulp.task('watch', function(){
  gulp.watch('app/**/*.css', ['css']); 
	gulp.watch('app/**/*.js', ['compress']); 

});

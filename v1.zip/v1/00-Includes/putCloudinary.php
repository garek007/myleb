<?php
require('Cloudinary.php');
require('Uploader.php');
require('Api.php');


\Cloudinary::config(array( 
  "cloud_name" => "dg1dra99r", 
  "api_key" => "684459863288884", 
  "api_secret" => "vStWv4wgbvoXIsBLA8NiolO11X8" 
));



try {
	 //file_put_contents("upload/".$filename, $data);
	 
	\Cloudinary\Uploader::upload("data:image/jpg;base64,".$data, array("public_id" => $filename));
	//Cloudinary::Uploader.upload("data:image/png;base64,".$data);

	$myvar = 	array(
		'url'=> cloudinary_url($filename)
	);
	echo json_encode($myvar);
		
} catch (SoapFault $e) {
	echo '<pre>';
    print_r($e);
		echo '</pre>';
}

?>
<?php


//link mapping
/*


--lyt-events.html


--lyt-four-up-image.php
<i class="fa fa-external-link f1" aria-hidden="true" data-linktype="fourcol" data-position="one"></i>
<i class="fa fa-external-link f2" aria-hidden="true" data-linktype="fourcol" data-position="two"></i>
<i class="fa fa-external-link f3" aria-hidden="true" data-linktype="fourcol" data-position="three"></i>
<i class="fa fa-external-link f4" aria-hidden="true" data-linktype="fourcol" data-position="four"></i>
<i class="fa fa-link link f1" aria-hidden="true"></i>
<i class="fa fa-link link f2" aria-hidden="true"></i>
<i class="fa fa-link link f3" aria-hidden="true"></i>
<i class="fa fa-link link f4" aria-hidden="true"></i>


<div class="orange"></div>
<div class="ltblue"></div>
<div class="white"></div>


--freeform n/a wrapped by scripts2.js



*/
$bgcolors = 
	'
	<div class="orange"></div>
	<div class="ltblue"></div>
	<div class="white"></div>	
	';
//These are the modules below
//All modules get the core control icons remove, drag, dup and copy HTML to clipboard. 
//To add new core controls add them to the $controls array
//Any customizations or additional icons come later in the switch statement
function build_controls($module){
	$controls=[
		["fa-times","remove"],
		["fa-ellipsis-v","drag"],
		["fa-files-o","duplicate"],
		["fa-clipboard"]
	];
	$data = array();
	
	
	switch($module){
		case "divider":break;
		case "events":
			$controls.= 
			[
				["fa-plus","addEvent","right"],
				["fa-minus","removeEvent","right"]
			];
			break;
		case "four-up-image":
			$controls.= 
			[
				["fa-external-link","f1"],
				["fa-external-link","f2"],
				["fa-external-link","f3"],
				["fa-external-link","f4"],
				["fa-link","f1"],
				["fa-link","f2"],
				["fa-link","f3"],
				["fa-link","f4"]
			];
			$data = 
			[
				['data-linktype="fourcol"','data-position="one"'],
				['data-linktype="fourcol"','data-position="two"'],
				['data-linktype="fourcol"','data-position="three"'],
				['data-linktype="fourcol"','data-position="four"']
			];
			break;	
				
		case "header-540-wide":
			$controls.= 
			[
				["fa-external-link"]
			];
			$data = 
			[
				['data-linktype="onecol"']
			];
			break;		
		case "header-600-wide":
		case "headline":
		case "numbered-list":
		case "one-up-image":
		case "paragraph":
		case "signatures":
		case "two-up-image":
		default:break;
	}
	
	$html;
	foreach($core as $item){
		$html .= '<i class="fa '.implode(' ',$item).'" aria-hidden="true"/>';
	}	
	
	
	
	
	return $html;
}



/*
<i class="fa fa-external-link" aria-hidden="true" data-linktype="onecol"></i>


<div class="orange"></div>
<div class="ltblue"></div>
<div class="white"></div>

	
--lyt-header-600-wide.php
<i class="fa fa-times remove" aria-hidden="true"></i>
<i class="fa fa-ellipsis-v drag" aria-hidden="true"></i>
<i class="fa fa-files-o duplicate" aria-hidden="true"></i>
<i class="fa fa-clipboard" aria-hidden="true" ></i>

<i class="fa fa-external-link" aria-hidden="true" data-linktype="onecol"></i>


--lyt-headline.php
<i class="fa fa-times remove" aria-hidden="true"></i>
<i class="fa fa-ellipsis-v drag" aria-hidden="true"></i>
<i class="fa fa-files-o duplicate" aria-hidden="true"></i>
<div class="orange"></div>
<div class="ltblue"></div>
<div class="white"></div> 
<i class="fa fa-floppy-o saveToLibrary" aria-hidden="true"></i>  
<i class="fa fa-clipboard" aria-hidden="true" ></i>

--lyt-numbered-list.php
<i class="fa fa-times remove" aria-hidden="true"></i>
<i class="fa fa-ellipsis-v drag" aria-hidden="true"></i>
<i class="fa fa-plus addRow right fa-1x" aria-hidden="true"></i> <i class="fa fa-minus removeRow right fa-1x" aria-hidden="true"></i>
<i class="fa fa-files-o duplicate" aria-hidden="true"></i>
<div class="orange"></div>
<div class="ltblue"></div>
	
lyt-one-up-image.php
<i class="fa fa-times remove" aria-hidden="true"></i>
<i class="fa fa-ellipsis-v drag" aria-hidden="true"></i>
<i class="fa fa-external-link" aria-hidden="true" data-linktype="onecol"></i>
<i class="fa fa-files-o duplicate" aria-hidden="true"></i>
<div class="orange"></div>
<div class="ltblue"></div>
<div class="white"></div>
<i class="fa fa-clipboard" aria-hidden="true" ></i>
	
lyt-paragraph.html
<i class="fa fa-times remove" aria-hidden="true"></i>
<i class="fa fa-ellipsis-v drag" aria-hidden="true"></i>
<i class="fa fa-link link left " aria-hidden="true"></i>
<i class="fa fa-external-link" aria-hidden="true"></i>
<i class="fa fa-files-o duplicate" aria-hidden="true"></i>
<div class="orange"></div>
<div class="ltblue"></div>
<div class="white"></div>
<i class="fa fa-clipboard" aria-hidden="true" ></i>	
	
press-release
signatures
<i class="fa fa-times remove" aria-hidden="true"></i>
<i class="fa fa-ellipsis-v drag" aria-hidden="true"></i>
<i class="fa fa-plus addEvent right fa-1x" aria-hidden="true"></i>
<i class="fa fa-minus removeEvent right fa-1x" aria-hidden="true"></i>
<div id="addSignature">
<span><input type="checkbox" name="celey" />Candice</span>
<span><input type="checkbox" name="rarends" />Robert</span>

<span><input type="checkbox" name="egutierrez" />Edna</span>
<span><input type="checkbox" name="sweinberg" />Sarah</span>
<span><input type="checkbox" name="jterzi" />JT69</span>
<span><input type="checkbox" name="bhilemon" />Brian Hilemon</span>
<span><input type="checkbox" name="ggranados" />Gerry</span>
<span><input type="checkbox" name="nbjork" />Nancy</span>
<span><input type="checkbox" name="jtimko" />Joe Timko</span>
</div>
	
	
lyt-two-up-image.php
<i class="fa fa-external-link left" aria-hidden="true" data-linktype="twocol-left"></i>
<i class="fa fa-external-link right" aria-hidden="true" data-linktype="twocol-right"></i>
<i class="fa fa-times remove" aria-hidden="true"></i>
<i class="fa fa-ellipsis-v drag" aria-hidden="true"></i>
<div class="orange"></div>
<div class="ltblue"></div>
<div class="white"></div>
<i class="fa fa-files-o duplicate" aria-hidden="true"></i>
<i class="fa fa-clipboard" aria-hidden="true" ></i>






controls
insert image link
duplicate
drag
remove
insert hyperlink
drag n drop image upload
save to library
copy module HTML

addevent or person
remove event or person

change headline font size
change subheadline size
change p size

toggle sponsored content

*/
?>


  <table width="100%" cellspacing="0" cellpadding="0" border="0" class="contentarea twocol">
    <tbody>
      <tr>
        <td class="fullpad" bgcolor="#fddea6" background="http://image.exct.net/lib/fe6e15707166047a7715/m/1/sdta_nl_small_texture_tan.jpg" style="padding: 15px 30px;"><table width="100%" cellspacing="0" cellpadding="0" border="0">
            <tbody>
              <tr>
                <td colspan="3" style="font-size: 18px; letter-spacing: 0.3px; line-height: 24px; color: #005f86;"><font style="font-family: 'Arial Narrow', Helvetica, sans-serif;"> 
                  <!--[if (!mso 14)&(!mso 15)]><!--> 
                  <font style="font-family: Oswald, 'Arial Narrow', Helvetica, Arial, sans-serif;"> 
                  <!--<![endif]--> 
                  
                  <span class="editable">5 IDEA FORECAST</span> 
                  
                  <!--[if (!mso 14)&(!mso 15)]><!--> 
                  </font> 
                  <!--<![endif]--> 
                  </font></td>
              </tr>
              <tr>
                <td colspan="3">&nbsp;</td>
              </tr>
              <tr>
                <td colspan="3" style="font-size: 27px; line-height: 34px; color: #ef7622; padding: 0px 0px 16px;"><font style="font-family: 'Arial Narrow', Helvetica, sans-serif;"> 
                  <!--[if (!mso 14)&(!mso 15)]><!--> 
                  <font style="font-family: Oswald, 'Arial Narrow', Helvetica, Arial, sans-serif;"> 
                  <!--<![endif]--> 
                  
                  <span class="editable">SECTION HEADLINE HERE</span> 
                  
                  <!--[if (!mso 14)&(!mso 15)]><!--> 
                  </font> 
                  <!--<![endif]--> 
                  </font></td>
              </tr>
              <tr>
                <td colspan="3"><p style="font-family: Arial, sans-serif; font-size: 13px; color: #55565a; letter-spacing: 0.3px; margin: 0px; padding: 0px;"> <span class="editable">Sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt.</span> </p></td>
              </tr>
              <tr>
                <td colspan="3">
                
                <table width="100%" border="0" cellpadding="0" cellspacing="0" class="numbered-list">
               
                <tbody>
                <tr><td valign="top" class="numbered-list-container">
                
                
                <!-- BEGIN ROW -->
                  <table width="100%" border="0" cellpadding="0" cellspacing="0" class="numbered-list-item" style="position:relative;">
                    <tr class="first_buffer_row">
                      <td width="68">&nbsp; <i class="fa fa-ellipsis-v drag" aria-hidden="true"></i></td>
                      <td width="10">&nbsp;</td>
                      <td valign="top"></td>
                    </tr>
                    <tr>
                      <td valign="top">
                        <table width="100%" border="0">
  <tbody>
    <tr>
      <td valign="top"><table width="100%" cellspacing="0" cellpadding="0" border="0">
                          <tbody>
                            <tr>
                              <td align="center" valign="top" bgcolor="#ee7421" style="font-size: 18px; line-height: 24px; color: #ffffff; padding: 12px 0px; width: 46px;"><font style="font-family: 'Arial Narrow', Helvetica, sans-serif;"> 
                                <!--[if (!mso 14)&(!mso 15)]><!--> 
                                <font style="font-family: Oswald, 'Arial Narrow', Helvetica, Arial, sans-serif;"> 
                                <!--<![endif]--> 
                                
                                <span class="editable number">1</span> 
                                
                                <!--[if (!mso 14)&(!mso 15)]><!--> 
                                </font> 
                                <!--<![endif]--></font></td>
                              <td>&nbsp;</td>
                            </tr>
                          </tbody>
                        </table></td>
    </tr>
  </tbody>
</table>
</td>
                      <td>&nbsp;</td>
                      <td valign="top"><table width="100%" cellspacing="0" cellpadding="0" border="0">
                          <tbody>
                            <tr>
                              <td class="linkinput" style="font-size: 18px; letter-spacing: 0.3px; margin: 0px; padding: 0px;"><a href="#" style="text-decoration: none; display: block; color: #55565a;"> <font style="font-family: 'Arial Narrow', Helvetica, sans-serif;"> 
                                <!--[if (!mso 14)&(!mso 15)]><!--> 
                                <font style="font-family: Oswald, 'Arial Narrow', Helvetica, Arial, sans-serif;"> 
                                <!--<![endif]--> 
                                
                                <span class="editable maintitle">LOREM IPSUM DOLOR DOLORUM</span> 
                                
                                <!--[if (!mso 14)&(!mso 15)]><!--> 
                                </font> 
                                <!--<![endif]--></font> <img src="http://image.updates.sandiego.org/lib/fe9e15707566017871/m/2/spacer-13.gif" border="0" /><img class="link" src="http://image.exct.net/lib/fe6e15707166047a7715/m/1/sdta_nl_arrow_orange.png" vspace="3" align="bottom" style="vertical-align: bottom;" width="20" border="0" /></a></td>
                            </tr>
                            <tr>
                              <td style="font-family: Arial, sans-serif; font-size: 13px; color: #55565a; letter-spacing: 0.3px; margin: 0px; padding: 0px;"><span class="editable textarea">Lorem ipsum dolor sit amet.</span></td>
                            </tr>
                          </tbody>
                        </table></td>
                    </tr>
                    <tr class="last_buffer_row">
                      <td style="border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: #d9be8e;">&nbsp;</td>
                      <td style="border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: #d9be8e;">&nbsp;</td>
                      <td style="border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: #d9be8e;">&nbsp;</td>
                    </tr>
                  </table>
                  <!-- END ROW -->
                  
                  </td></tr>
                  </tbody>
                </table>
                  
                </td>
              </tr>
              <tr>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
                <td valign="top">&nbsp;</td>
              </tr>
            </tbody>
          </table></td>
      </tr>

    </tbody>
  </table>


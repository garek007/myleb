<?php

include 'eventFunctions.php';

//loop to see how many fields are filled out

//if(isset($_POST['add_ga_tags'])){
	if($_POST['utm_campaign']== 'custom'){
		$utm_campaign = $_POST['custom_campaign_name'];
	}else{
		$utm_campaign = trim($_POST[str_replace(' ','%20','utm_campaign')]);
	}
	
	$ga_tags = new StdClass;
	
	$utm_campaign = trim($_POST['utm_campaign']);
	$ga_tags->campaign = str_replace(' ','%20',$utm_campaign);
	
	$ga_tags->source = $_POST['utm_source'];
	$ga_tags->medium = $_POST['utm_medium'];
	
	
	$ga_tags->ad_content = $_POST['ad_content'];
	
	$ga_tags->keyword = $_POST['keyword'];

	
	
	//$section_title = $_POST['section_title'];
	//for other modules we get this from an input on the form page
	//consider modifying the code structure to do that, but not sure it makes sense.

	
//}
	if($utm_campaign == "Top Things to Do"){
		$section_title = 'UPCOMING EVENTS';
		if(isset($_POST['blogposturl'])){
		
		$eventurl = $_POST['blogposturl'].'?utm_campaign='.$ga_tags->campaign.'&utm_source='.$ga_tags->source.'&utm_medium='.$ga_tags->medium.'&utm_term=eventlink&utm_content=text';
			}
		$urltext = "SEE ALL TOP THINGS TO DO";	
		
	}else{
		$section_title = 'MORE FROM SANDIEGO.ORG';
		$eventurl = '#';
		$urltext = '';
	}



$dest_url = $_POST['dest_url'];//if it's blank an error will happen


$date = $_POST['date'];


$title = $_POST['title'];
$month = $_POST['month'];




































$layout = "events"; 
include 'lyt-events-build.php';
echo $html;

include $_SERVER['DOCUMENT_ROOT']."/00-Includes/controlsmap.php"; 
echo '</div>';












?>





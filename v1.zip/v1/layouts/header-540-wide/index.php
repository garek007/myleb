<?php $pageTitle = "540 Wide Image Header Builder"; ?>

<div class="first-row row">
<h2><?php echo $pageTitle; ?></h2>

</div>

<form class="moduleform" title="tttdform" name="tttdform" id="htmlform" action="make-layout.php" method="post">



 <?php include '../../00-Includes/ga-fields.html'; ?>



<div class="row">



<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tbody>
    <tr>
      <td>Image URL</td>
      <td colspan="3">
        <input class="text drop-area" name="image_url" type="text" size="25">
      </td>
      </tr>
    <tr>
      <td>Headline</td>
      <td><input class="text" id="headline" name="headline" type="text" size="25"></td>
      <td width="100" align="center">Font Size</td>
      <td width="60"><input class="text" name="font_size" type="text" size="3" value="29"></td>
      
    </tr>
    <tr>
      <td>Description</td>
      <td colspan="3">
        <textarea name="description"  cols="65" rows="4"></textarea>
        
        
      </td>
      </tr>
    <tr>
      <td>Destination URL</td>
      <td colspan="3"><input class="text" name="dest_url" type="text" id="textfield2" size="25"></td>
      </tr>
  </tbody>
</table>
<input type="submit" value="Generate HTML" class="submit">
</div>




</form>

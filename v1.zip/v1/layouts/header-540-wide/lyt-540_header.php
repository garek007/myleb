<?php
$html = <<<EOT
<div class="contentarea_container" data-module="header-540-wide">
<table class="contentarea" width="100%" border="0" cellspacing="0" cellpadding="0">
<!--------------------------------- 540 SECTION START ------------------------------------->
<!----------------------- dont forget to grab the opening table tag above ------------------------->
<!--------------------------------- 540 SECTION START ------------------------------------->
	<tbody>
		<tr>
			<td class="fullpad" style="padding: 0px 30px 15px;" $bgcolor>
			<table width="100%" border="0" cellspacing="0" cellpadding="0">
				<tbody>

					<tr>
						<td style="padding-top: 20px;" class="imagecont"><a href="$dest_url"><img class="fullwidth" src="$image_url" alt="Happiness is Calling from San Diego" border="0" width="540" style="display: block; height: auto !important;" /></a></td>
					</tr>
					<tr>
						<td style="padding-top: 15px;" class="title" align="left">
						<table width="100%" border="0" cellspacing="0" cellpadding="0">
							<tbody>
								<tr>
									<td>
									<a class="dest_url" style="font-size: $font_size; color: #434448; line-height: 32px; text-decoration: none;" href="$dest_url">
									<font style="font-family: 'Arial Narrow', Helvetica, sans-serif;"> 
									<!--[if (!mso 14)&(!mso 15)]><!--> 
									<font style="font-family: Oswald, 'Arial Narrow', Helvetica, Arial, sans-serif;"> 
									<!--<![endif]--> $headline
									 <!--[if (!mso 14)&(!mso 15)]><!--> 
									</font> 
									<!--<![endif]--></font>
									</a>
								  </td>
									<td align="right" valign="top"><a href="$dest_url"><img src="http://image.exct.net/lib/fe6e15707166047a7715/m/1/sdta_nl_arrow_orange.png" align="baseline" style="vertical-align: baseline; padding-left: 7px;" border="0" /></a><img src="http://image.updates.sandiego.org/lib/fe9e15707566017871/m/2/spacer-10.gif" border="0" /></td>
								</tr>
							</tbody>
						</table>
						</td>
					</tr>
					<tr>
						<td class="description" align="left" style="font-family: Helvetica, Arial, sans-serif; font-size: 14px; color: #434448; padding-top: 5px;"> $description
						</td>
					</tr>
				</tbody>
			</table>
			</td>
		</tr>
	</tbody>
<!--------------------------------- 540 SECTION END ------------------------------------->
<!----------------------- dont forget to grab the ending table tag below ------------------------->
<!--------------------------------- 540 SECTION END ------------------------------------->
</table>
<div class="remove"></div><div class="edit"></div><div class="drag"></div>
</div>
EOT;
?>
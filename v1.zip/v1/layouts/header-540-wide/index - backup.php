<?php $pageTitle = "540 Wide Image Header Builder"; ?>

<div class="first-row row">
<h2><?php echo $pageTitle; ?></h2>

</div>

<form title="tttdform" name="tttdform" id="htmlform" action="make-layout.php" method="post">



 <?php include '../../00-Includes/ga-fields.html'; ?>

<div class="row style">

<br>
<label for="sponsored">
<input type="checkbox" name="sponsored">&nbsp;Sponsored content?</label><br>

<label for="backgroundcolor">
<input type="checkbox" name="bgcolor">&nbsp;Background color?</label><br>


<label for="top_padding">
<input type="checkbox" name="top_padding">&nbsp;Remove Top Padding?</label>

<label for="divider">
<input type="checkbox" name="divider">&nbsp;Add Separating Divider Line? (Not recommended if you have a background color)</label>




</div>





<div class="row">
<label for="section_title">Section Title</label>
<input class="text" name="section_title" type="text" size="50" value="INSIDE SCOOP">
<label for="font_size">Font Size</label>
<input class="text" name="font_size" type="text" size="25" value="29">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tbody>
    <tr>
      <td>Image URL</td>
      <td>
        <input class="text drop-area" name="image_url" type="text" size="25">
      </td>
    </tr>
    <tr>
      <td>Headline</td>
      <td><input class="text" id="headline" name="headline" type="text" size="25"></td>
    </tr>
    <tr>
      <td>Description</td>
      <td>
<textarea name="description"  cols="65" rows="3"></textarea>
      
      
      </td>
    </tr>
    <tr>
      <td>Destination URL</td>
      <td><input class="text" name="dest_url" type="text" id="textfield2" size="25"></td>
    </tr>
  </tbody>
</table>
<input type="submit" value="Generate HTML" class="submit">
</div>




</form>

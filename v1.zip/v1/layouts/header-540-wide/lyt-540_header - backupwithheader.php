<?php
$html = <<<EOT
<table class="contentarea" width="100%" border="0" cellspacing="0" cellpadding="0">
	<tbody>
		<tr>
			<td class="fullpad" style="padding: 0px 30px 15px;" $bgcolor>
			<table width="100%" border="0" cellspacing="0" cellpadding="0">
				<tbody>
					<tr>
						<td style="padding-top: 20px;">
						

						<table class="headlinebar" width="100%" border="0" cellspacing="0" cellpadding="0">
							<tbody>
								<tr>
										
										<td valign="top" align="left" style="font-size: 18px; letter-spacing: 0.3px; $section_title_color" class="subheadline">
													
												<font style="font-family: 'Arial Narrow',Helvetica,sans-serif;"> 
												<!--[if (!mso 14)&(!mso 15)]><!--> 
												<font style="font-family: Oswald,'Arial Narrow',Helvetica,Arial,sans-serif;"> 
												<!--<![endif]--> 
												$section_title
												<!--[if (!mso 14)&(!mso 15)]><!--> 
												</font> 
												<!--<![endif]--></font></td>
									
									
									
										<td valign="top" align="right" style="font-size: 12px;" class="calltoaction"><a style="color: #88b6ca; font-family: Oswald,'Arial Narrow',Helvetica,Arial,sans-serif; text-decoration: none;" href="#">$sponsored</a></td>
									
									
	
									
								</tr>
							</tbody>
						</table>
						</td>
					</tr>
					<tr>
						<td style="padding-top: 20px;" class="imagecont"><a href="$dest_url"><img class="fullwidth" src="$image_url" alt="Happiness is Calling from San Diego" border="0" width="540" style="display: block; height: auto !important;" /></a></td>
					</tr>
					<tr>
						<td style="padding-top: 15px;" class="title" align="left">
						<table width="100%" border="0" cellspacing="0" cellpadding="0">
							<tbody>
								<tr>
									<td>
									<a class="dest_url" style="font-size: $font_size; color: #434448; line-height: 32px; text-decoration: none;" href="$dest_url">
									<font style="font-family: 'Arial Narrow', Helvetica, sans-serif;"> 
									<!--[if (!mso 14)&(!mso 15)]><!--> 
									<font style="font-family: Oswald, 'Arial Narrow', Helvetica, Arial, sans-serif;"> 
									<!--<![endif]--> $headline
									 <!--[if (!mso 14)&(!mso 15)]><!--> 
									</font> 
									<!--<![endif]--></font>
									</a>
								  </td>
									<td align="right" valign="top"><a href="$dest_url"><img src="http://image.exct.net/lib/fe6e15707166047a7715/m/1/sdta_nl_arrow_orange.png" align="baseline" style="vertical-align: baseline; padding-left: 7px;" border="0" /></a><img src="http://image.updates.sandiego.org/lib/fe9e15707566017871/m/2/spacer-10.gif" border="0" /></td>
								</tr>
							</tbody>
						</table>
						</td>
					</tr>
					<tr>
						<td class="description" align="left" style="font-family: Helvetica, Arial, sans-serif; font-size: 14px; color: #434448; padding-top: 5px;"> $description
						</td>
					</tr>
				</tbody>
			</table>
			</td>
		</tr>
	</tbody>
</table>
EOT;
?>
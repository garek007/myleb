<?php $layout = "four-up-image"; ?>
<div class="contentarea_container" data-module="signatures">
<table class="contentarea" width="100%" cellspacing="0" cellpadding="0" border="0">
  <tbody>
    <tr>
      <td style="padding-top: 0px;"><table width="100%" cellspacing="0" cellpadding="0" border="0">
          <tbody>
            <tr>
              <td bgcolor="#FFFFFF" style="padding: 25px 30px 15px;" class="fullpad"><table width="100%" cellspacing="0" cellpadding="0" border="0" class="headlinebar">
                  <tbody>
                    <tr>
                      <td valign="top" align="left" style="font-size: 18px; color: #005f86;" class="section_title"><font style="font-family: 'Arial Narrow', Helvetica, sans-serif;"> 
                        <!--[if (!mso 14)&(!mso 15)]><!--> 
                        <font style="font-family: Oswald, 'Arial Narrow', Helvetica, Arial, sans-serif;"> 
                        <!--<![endif]--> 
                        <span class="editable">YOUR LOCAL CONTACTS</span> 
                        <!--[if (!mso 14)&(!mso 15)]><!--> 
                        </font> 
                        <!--<![endif]--></font></td>
                      <td valign="top" align="right" style="font-size: 12px;" class="calltoaction"><a style="text-decoration: none; color: #979597;" href="#"> <font style="font-family: 'Arial Narrow', Helvetica, sans-serif;"> 
                        <!--[if (!mso 14)&(!mso 15)]><!--> 
                        <font style="font-family: Oswald, 'Arial Narrow', Helvetica, Arial, sans-serif;"> 
                        <!--<![endif]--> 
                        
                        <span class="editable">&nbsp;</span> 
                        
                        <!--[if (!mso 14)&(!mso 15)]><!--> 
                        </font> 
                        <!--<![endif]--></font> </a></td>
                    </tr>
                  </tbody>
                </table>
                <table width="100%" cellspacing="0" cellpadding="0" border="0" class="eventcal">
                  <tbody>
                    <!-- START: ROW -->
                    <tr>
                      <td width="50%" valign="top" align="left" style="padding-right: 5px; padding-top: 20px; padding-bottom: 20px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: #dddddd;" class="blockme left">
                      
                      
                      
                      
                      
                      <table class="draggable celey signature" width="100%" border="0" cellspacing="0" cellpadding="0">
  <tbody>
    <tr>
      <td width="109" align="left" valign="top"><img src="http://image.updates.sandiego.org/lib/fe9e15707566017871/m/4/celey-99x99.jpg" width="99" height="99" style="display: block;" /></td>
      <td><p style="font-family: Helvetica, Arial, sans-serif; font-size: 12px; color: #434448; padding: 0px; margin: 0px;"> <strong>CANDICE ELEY</strong><br />
          Director of Communications<br />
          <a href="mailto:celey@sandiego.org">celey@sandiego.org</a><br />
          619.557.2889 Office </p></td>
    </tr>
  </tbody>
</table>
</td>
                      <td width="50%" valign="top" align="left" style="padding-left: 5px; padding-top: 20px; padding-bottom: 20px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: #dddddd;" class="blockme right empty">
                      
                      
                      
                      
                      







</td>




                    </tr>
                    <!-- END: ROW --> 
                  </tbody>
                </table></td>
            </tr>
          </tbody>
        </table></td>
    </tr>
  </tbody>
</table>


<?php 
include $_SERVER['DOCUMENT_ROOT']."/00-Includes/controlsmap.php";
echo build_controls($layout);

?>
</div>
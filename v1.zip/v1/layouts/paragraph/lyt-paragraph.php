
<table class="contentarea" width="100%" border="0" cellspacing="0" cellpadding="0">
<!--------------------------------- OPEN CONTENT SECTION START ------------------------------------->
<!----------------------- dont forget to grab the opening table tag above ------------------------->
<!--------------------------------- OPEN CONTENT SECTION START ------------------------------------->
	<tbody>
		<tr>
			<td class="fullpad" style="padding: 15px 30px 15px;" >
			<table width="100%" border="0" cellspacing="0" cellpadding="0">
				<tbody>
					<tr>
						<td class="description" align="left" style="font-family: Helvetica, Arial, sans-serif; font-size: 14px; color: #434448; padding-top: 5px;"><span class="editable textarea unedited">
            
            Description goes here, click here to type. Suggested maximum for this module is 300 characters.
            
            
            </span>
						</td>
					</tr>
				</tbody>
			</table>
			</td>
		</tr>
	</tbody>
<!--------------------------------- OPEN CONTENT SECTION END ------------------------------------->
<!----------------------- dont forget to grab the ending table tag below ------------------------->
<!--------------------------------- OPEN CONTENT SECTION END ------------------------------------->
</table>

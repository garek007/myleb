<?php
session_start();
include "../../00-Includes/header.php";







$dest_url = "http://www.google.com";

$image_url = $_POST['image_url'];



include 'lyt-sweepstakes.php';


$_SESSION['html'] = $html;
$_SESSION['subject'] = stripslashes($_POST['et_subject']);
$_SESSION['email_name'] = $_POST['et_email_name'];
$_SESSION['from_name'] = $whomadethis->name;
$_SESSION['from_email'] = $whomadethis->email;

?>
<div class="first-row row">
<br>

<form action="send_to_ET.php" method="post">

<div class="first-col cols_12-4">
<h3>Select Lists</h3>



<input type="checkbox" name="lists[]" value="583375">&nbsp;SDTA Members List - Research and Connect</label><br>
<input type="checkbox" name="lists[]" value="365324">&nbsp;All Employees</label><br>
<input type="checkbox" name="lists[]" value="299500">&nbsp;Always Send To</label><br>
<input type="checkbox" name="lists[]" value="300512">&nbsp;Nick Only</label><br>
<input type="checkbox" name="lists[]" value="384277">&nbsp;Stan Only</label><br>
<input type="checkbox" name="lists[]" value="307955">&nbsp;Brent Only</label><br>
</div>
<div class="cols_12-8">
Enter Send Date: <input id="datepicker" type="text" name="send_date" /><br>

  <select style="display:none;"  name="send_time" id="send_time">
    <option value="0600">6:00 AM</option>
    <option value="0630">6:30 AM</option>
    <option value="1500">3:08 PM</option>
  </select>
  
  <div style="margin:20px 0 20px;" id="slider"></div>
  <input type="text" name="time" id="time" />

</div>


<input style="clear:both;" type="submit" value="Send Email">

</form>

</div>
<div class="row">
<div class="first-col cols_12-12">
<?php



echo $html;

?>
</div></div>
<?php





include "../../00-Includes/footer.php";

/*





include "../../00-Includes/header.php"; 
echo '<div class="first-row row">
<p>This is your email preview. If you like it, grab the code from the text box at bottom. If you don\'t, never fear, hit the back button and your fields will still be there.</p>
<div class="email_layout">';
echo $html;
echo '</div></div>';
include '../../00-Includes/rawoutput.php';
include "../../00-Includes/footer.php";

*/
?>

            
            
            
            
						


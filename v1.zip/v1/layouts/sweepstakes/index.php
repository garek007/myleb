<?php 


$pageTitle = "Sweepstakes Email Builder"; 
$date = date('md');

 include "../../00-Includes/header.php"; 
?>

<div class="first-row row">
<h2><?php echo $pageTitle; ?></h2>
<img class="left" src="/images/sweepstakes.jpg" />
</div>


<form title="tttdform" name="tttdform" action="make-layout.php" method="post">






<div class="row">
<div class="first-col cols_12-6 column">
	<label for="medium">ExactTarget Email Name<span class="required">*</span></label>
  <input name="et_email_name" type="text" size="30" value="SWEEPSTAKES <Enter identifier><?php echo $date; ?>">
</div>



<div class="cols_12-6 column">
	<label for="medium">ExactTarget Email Subject<span class="required">*</span></label>
  <input name="et_subject" type="text" size="30" value="">
</div>
<div class="cols_12-4"></div>


</div>

<div class="row">
	<div class="first-col cols_12-4 column">    

    <label for="medium">Destination URL<span class="required">*</span></label>
  	<input name="dest_url" type="text" size="30">
  </div>
  <div class="cols_12-4 column">

	</div>
</div>
</div>



<div class="row">
  <div class="first-col cols_12-6 column">
  <label for="medium">Image URL (must be precropped to 600 pixels wide)</label>
          <input class="text drop-area" name="image_url" type="text" size="25">
  </div>
</div>

<div class="row">
<input style="clear:both;float:none;" type="submit" value="Generate HTML" class="submit">
</div>



</form>
<?php include "../../00-Includes/footer.php"; ?>
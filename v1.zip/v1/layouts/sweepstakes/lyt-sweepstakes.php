<?php
ob_start();
include '../../00-Includes/corp_template_start.html';
$htmlstart = ob_get_contents();
ob_end_clean();

ob_start();
include '../../00-Includes/corp_template_end.html';
$htmlend = ob_get_contents();
ob_end_clean();




$html = <<<EOT
{$htmlstart}
<a href="$dest_url"><img src="$image_url" border="0" /></a>
$htmlend;
EOT;

?>
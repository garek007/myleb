



<div class="first-row row">
<h2>Free Range HTML Inserter</h2>

</div>


<form class="moduleform" title="tttdform" name="tttdform" action="layouts/freeform/make-layout.php" method="post">




<div class="row">
<div class="first-col cols_12-11">

<textarea id="pastedCode" cols="200" rows="28" name="pastedCode"></textarea>



</div>

<input type="submit" value="Paste HTML" class="submit">
</div>





</form>

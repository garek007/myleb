<?php

ini_set('display_errors', 0);
//loop to see how many fields are filled out






//check for content
try {
			$pastedCode = $_POST['pastedCode'];
				
		}catch(Exception $e){
			echo 'ERROR: You must have content for the left side';			
		} 
	
/*



echo '<div class="contentarea_container" data-module="freeform">'.$pastedCode.'<div class="remove"></div><div class="edit"></div><div class="drag"></div>
</div>';

*/


echo $pastedCode;

?>

            
            
            
            
						


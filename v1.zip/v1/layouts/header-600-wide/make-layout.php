<?php

//ini_set('display_errors', 0);
//loop to see how many fields are filled out


$headline = isset($_POST['headline']) ? strtoupper($_POST['headline']) : '';
$description = nl2br(trim(stripslashes($_POST["description"])));
$dest_url = $_POST['dest_url'];
$image_url = $_POST['image_url'];



if(isset($_POST['add_ga_tags'])){
	if($_POST['utm_campaign']== 'custom'){
		$utm_campaign = $_POST['custom_campaign_name'];
	}else{
		$utm_campaign = trim($_POST[str_replace(' ','%20','utm_campaign')]);
	}
	
	$utm_term = 'header';
	$utm_source = $_POST['utm_source'];
	$utm_medium = $_POST['utm_medium'];
	
	$dest_url.= '?utm_campaign='.$utm_campaign.'&utm_source='.$utm_source.'&utm_medium='.$utm_medium.'&utm_term='.$utm_term;
	
}

//style
//$fontSize = '27px';
$font_size = $_POST['font_size'].'px';
$sponsored = isset($_POST['sponsored']) ? 'SPONSORED CONTENT' : '';
$bgcolor =  isset($_POST['bgcolor']) ? 'bgcolor="#dbe7ef"' : '';
$top_padding =  isset($_POST['top_padding']) ? '0' : '20px';
$divider =  isset($_POST['divider']) ? '0' : 'border-top-width: 1px; border-top-style: solid; border-top-color: #dfe0e0;';
$section_title_color = 'color: #005f86;';//434448 is the grey


include 'lyt-600-header.php';
echo $html;

?>
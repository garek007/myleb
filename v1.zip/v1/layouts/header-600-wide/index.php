
<div class="first-row row"> 
<h2>600 Wide Header Builder</h2>

</div>
<form class="moduleform" title="tttdform" name="tttdform" action="layouts/<?php echo $_GET['module'] ?>/make-layout.php" method="post">



 <?php include '../../00-Includes/ga-fields.html'; ?>







<div class="row">
<label for="fontsize">Font Size</label>
<input class="text" name="font_size" type="text" size="25" value="29">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tbody>
    <tr>
      <td>Image URL</td>
      <td>
        <input class="text drop-area" name="image_url" type="text" size="25">
      </td>
    </tr>
    <tr>
      <td>Headline</td>
      <td><input class="text header-600-wide" name="headline" type="text" size="25" id="headline"></td>
    </tr>
    <tr>
      <td>Description</td>
      <td>
<textarea name="description"  cols="65" rows="3"></textarea>
      
      
      </td>
    </tr>
    <tr>
      <td>Destination URL</td>
      <td><input class="text" name="dest_url" type="text" id="textfield2" size="25"></td>
    </tr>
  </tbody>
</table>
<input type="submit" value="Generate HTML" class="submit">
</div>




</form>



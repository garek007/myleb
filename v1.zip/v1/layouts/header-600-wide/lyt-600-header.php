<div class="contentarea_container blockme" data-module="header-600-wide">
<table class="contentarea" width="100%" border="0" cellspacing="0" cellpadding="0">
	<tbody>
		<tr>
			<td><a class="dest_url" href="#"><img class="fullwidth editableImage drop-area" data-width="600" data-height="300" src="/images/imagePlaceholder.jpg" border="0" style="display: block; height: auto !important;" /></a></td>
		</tr>
		<tr>
			<td class="fullpad" bgcolor="#005f86" style="padding: 15px 30px;" background="http://image.exct.net/lib/fe6e15707166047a7715/m/1/sdta_nl_small_texture_blue.jpg">
			<table width="100%" border="0" cellspacing="0" cellpadding="0">
				<tbody>
					<tr>
						<td class="headline" align="left" valign="top" style="font-size: 29px; line-height: 31px; letter-spacing: 0.3px;">
            
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tbody>
    <tr>
      <td style="font-size: 29px; line-height: 31px; letter-spacing: 0.3px;"><a class="dest_url" href="#" style="color: #ffffff; text-decoration: none;">
			  <font style="font-family: 'Arial Narrow', Helvetica, sans-serif;"> 
				<!--[if (!mso 14)&(!mso 15)]><!--> 
				<font style="font-family: Oswald, 'Arial Narrow', Helvetica, Arial, sans-serif;"> 
				<!--<![endif]--> 
				<span class="editable maintitle unedited">MAIN TITLE OR HEADLINE</span>      
				<!--[if (!mso 14)&(!mso 15)]><!--> 
				</font> 
				<!--<![endif]-->
				</font>

			</a></td>
      <td align="right" valign="top"><a class="dest_url" href="#" style="text-decoration: none;">
   
      <img src="http://image.updates.sandiego.org/lib/fe9e15707566017871/m/2/spacer-13.gif" width="15" border="0" /><img class="link" src="http://image.exct.net/lib/fe6e15707166047a7715/m/1/sdta_nl_arrow_white.png" vspace="6" align="bottom" style="vertical-align: bottom;" border="0" /></a></td>
    </tr>
  </tbody>
</table>
</td>
					</tr>
					<tr>
						<td class="subheadline" align="justify" style="font-size: 18px; color: #80b8cb; letter-spacing: 0.3px; padding-top: 5px; text-align: justify;"><font style="font-family: 'Arial Narrow', Helvetica, sans-serif;"> 
						<!--[if (!mso 14)&(!mso 15)]><!--> 
						<font style="font-family: Oswald, 'Arial Narrow', Helvetica, Arial, sans-serif;"> 
						<!--<![endif]--> 
	<span class="editable textarea unedited">Description goes here, click here to type. Suggested maximum for this module is 300 characters.</span>
						<!--[if (!mso 14)&(!mso 15)]><!--> 
						</font> 
						<!--<![endif]--></font></td>
					</tr>
				</tbody>
			</table>
			</td>
		</tr>
	</tbody>
</table>
<?php include "controls.html"; ?>

</div>

<?php $pageTitle = "Full Email Builder"; ?>

<div class="first-row row">
<h2><?php echo $pageTitle; ?></h2>
<img class="left" src="images/fullemail.jpg" />
</div>

<form title="tttdform" name="tttdform" action="layouts/<?php echo $_GET['module'] ?>/make-layout.php" method="post">



<div id="load">
<div id="loadContent"></div>
</div>



<div class="row style">

Add new module.....

<a href="http://www.enjoysandiego.com/mylittleemailbuilder/layouts/600wide-header/index.php" id="header-600" class="fullhtml">600 Wide Header</a>
<a href=#" id="http://www.enjoysandiego.com/mylittleemailbuilder/layouts/540wide-header/index.php" class="fullhtml">540 Wide Header</a>
<a href=#" id="events" class="fullhtml">Events</a>
<a href=#" id="image2up" class="fullhtml">2 Up Image</a>
<a href=#" id="image1up" class="fullhtml">1 Up Image</a>



<br>
<label for="sponsored">
<input type="checkbox" name="sponsored">&nbsp;Sponsored content?</label><br>

<label for="backgroundcolor">
<input type="checkbox" name="bgcolor">&nbsp;Background color?</label><br>


<label for="top_padding">
<input type="checkbox" name="top_padding">&nbsp;Remove Top Padding?</label>

<label for="divider">
<input type="checkbox" name="divider">&nbsp;Add Separating Divider Line? (Not recommended if you have a background color)</label>




</div>





<div class="row">
<label for="section_title">Section Title</label>
<input class="text" name="section_title" type="text" size="50" value="INSIDE SCOOP">
<label for="font_size">Font Size</label>
<input class="text" name="font_size" type="text" size="25" value="29">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tbody>
    <tr>
      <td>Image URL</td>
      <td>
        <input class="text drop-area" name="image_url" type="text" size="25">
      </td>
    </tr>
    <tr>
      <td>Headline</td>
      <td><input class="text" name="headline" type="text" size="25"></td>
    </tr>
    <tr>
      <td>Description</td>
      <td>
<textarea name="description"  cols="65" rows="3"></textarea>
      
      
      </td>
    </tr>
    <tr>
      <td>Destination URL</td>
      <td><input class="text" name="dest_url" type="text" id="textfield2" size="25"></td>
    </tr>
  </tbody>
</table>
<input type="submit" value="Generate HTML" class="submit">
</div>




</form>
